package com.dirgham.code

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.app.ActivityCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.util.Locale

class MainActivity : FlutterActivity() {

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale("ar"))
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
            }
        }
    }

    private fun svc(action: String, fill: (Intent) -> Unit = {}) {
        val i = Intent(this, AgentService::class.java).setAction(action)
        fill(i)
        startForegroundService(i)
    }

    override fun configureFlutterEngine(engine: FlutterEngine) {
        super.configureFlutterEngine(engine)
        val messenger = engine.dartExecutor.binaryMessenger

        EventChannel(messenger, "dirgham/agent_events").setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(args: Any?, sink: EventChannel.EventSink) { Bus.sink = sink }
            override fun onCancel(args: Any?) { Bus.sink = null }
        })

        MethodChannel(messenger, "dirgham/agent").setMethodCallHandler { call, res ->
            try {
                handle(call.method, call, res)
            } catch (e: Exception) {
                res.error("native", e.message, null)
            }
        }
    }

    private fun handle(method: String, call: io.flutter.plugin.common.MethodCall, res: MethodChannel.Result) {
        when (method) {
            "startService" -> {
                startForegroundService(Intent(this, AgentService::class.java))
                res.success(null)
            }
            "submitTask" -> {
                val p = call.argument<String>("prompt")
                svc(AgentService.ACTION_SUBMIT) { it.putExtra("prompt", p) }
                res.success(null)
            }
            "cancel" -> { svc(AgentService.ACTION_CANCEL); res.success(null) }
            "newChat" -> { svc(AgentService.ACTION_NEWCHAT); res.success(null) }

            "download" -> {
                val url = call.argument<String>("url")
                val name = call.argument<String>("name")
                svc(AgentService.ACTION_DOWNLOAD) { it.putExtra("url", url).putExtra("name", name) }
                res.success(null)
            }
            "cancelDownload" -> {
                val name = call.argument<String>("name")
                svc(AgentService.ACTION_DL_CANCEL) { it.putExtra("name", name) }
                res.success(null)
            }
            "downloadStates" -> res.success(Downloads.snapshot())

            "listModels" -> {
                val active = LlamaEngine.activeModel(this)?.name
                val list = LlamaEngine.listModels(this).map {
                    mapOf("name" to it.name, "size" to it.length(), "active" to (it.name == active))
                }
                res.success(list)
            }
            "setActiveModel" -> {
                Settings.setActiveModel(this, call.argument<String>("name").orEmpty())
                res.success(null)
            }
            "deleteModel" -> {
                val n = call.argument<String>("name").orEmpty()
                if (n.contains("/") || n.contains("..")) {
                    res.error("bad", "اسم غير صالح", null)
                } else {
                    File(LlamaEngine.modelsDir(this), n).delete()
                    File(LlamaEngine.modelsDir(this), "$n.part").delete()
                    Downloads.states.remove(n)
                    res.success(null)
                }
            }
            "modelsDir" -> res.success(LlamaEngine.modelsDir(this).absolutePath)
            "nativeOk" -> res.success(LlamaEngine.nativeOk)

            "getThinking" -> res.success(Settings.thinking(this))
            "setThinking" -> {
                Settings.setThinking(this, call.argument<Boolean>("on") == true)
                res.success(null)
            }

            "confirmResult" -> {
                Confirm.answer(call.argument<String>("id").orEmpty(), call.argument<Boolean>("ok") == true)
                res.success(null)
            }

            "startListening" -> { startListening(); res.success(null) }
            "stopListening" -> { recognizer?.stopListening(); res.success(null) }
            "speak" -> {
                if (ttsReady) tts?.speak(call.argument<String>("text").orEmpty(), TextToSpeech.QUEUE_FLUSH, null, "dg")
                res.success(ttsReady)
            }
            "stopSpeak" -> { tts?.stop(); res.success(null) }

            "bridgeCommand" -> {
                LocalBridge.start(47611, Settings.bridgeToken(this))
                res.success(LocalBridge.installCommand())
            }
            "bridgeConnected" -> res.success(LocalBridge.connected())
            "termuxInstalled" -> res.success(TermuxBridge.isInstalled(this))
            "termuxPermissionGranted" -> res.success(TermuxBridge.hasPermission(this))
            "requestTermuxPermission" -> {
                if (!TermuxBridge.isInstalled(this)) {
                    Bus.emit("status", "Termux غير مثبّت.")
                } else if (TermuxBridge.hasPermission(this)) {
                    Bus.emit("status", "الإذن ممنوح مسبقًا.")
                } else {
                    ActivityCompat.requestPermissions(this, arrayOf(TermuxBridge.PERMISSION), 77)
                }
                res.success(null)
            }
            "openAppSettings" -> {
                val i = Intent(AndroidSettings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
                res.success(null)
            }
            "termuxTest" -> { svc(AgentService.ACTION_TERMUX_TEST); res.success(null) }
            "openApp" -> res.success(TermuxBridge.openApp(this, call.argument<String>("pkg").orEmpty()))
            "openPreview" -> {
                startActivity(Intent(this, PreviewActivity::class.java).putExtra("path", call.argument<String>("path")))
                res.success(null)
            }
            else -> res.notImplemented()
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Bus.emit("error", "خدمة التعرف على الصوت غير متاحة على هذا الجهاز")
            Bus.emit("voice_end")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rms: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, p: Bundle?) {}
                override fun onError(error: Int) { Bus.emit("voice_end") }
                override fun onPartialResults(b: Bundle?) {
                    b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                        ?.let { Bus.emit("transcript", it) }
                }
                override fun onResults(b: Bundle?) {
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrBlank()) Bus.emit("voice_end") else Bus.emit("final", t)
                }
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }
        recognizer?.startListening(i)
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 77) {
            val ok = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            Bus.emit(
                "status",
                if (ok) "تم منح إذن Termux."
                else "لم يُمنح الإذن. إن لم تظهر نافذة طلب فالسبب أن Termux ثُبّت بعد التطبيق: " +
                    "احذف ضرغام كود ثم ثبّته ثانية (بعد وجود Termux)، أو امنح الإذن من " +
                    "إعدادات التطبيق ← الأذونات ← أذونات إضافية ← Run commands in Termux environment."
            )
        }
    }
}
