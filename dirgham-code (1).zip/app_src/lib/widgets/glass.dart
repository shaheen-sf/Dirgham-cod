import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import '../theme.dart';

/// زجاج سائل على نهج iOS 27: ضبابية خلفية + حافة لامعة بزاويتين (ضوء علوي أيسر/سفلي أيمن)
/// + ظل داخلي رقيق + لمعة علوية. بلا اعتماديات خارجية، ويعمل على Skia وImpeller.
class GlassPanel extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final double radius;
  final Color? glow;
  const GlassPanel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.radius = 22,
    this.glow,
  });

  @override
  Widget build(BuildContext context) {
    final r = BorderRadius.circular(radius);
    return Container(
      decoration: BoxDecoration(
        borderRadius: r,
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.38),
              blurRadius: 16,
              offset: const Offset(0, 6)),
          // إضاءة حادة ضيقة تحيط بالحافة (بلا مبالغة)
          if (glow != null)
            BoxShadow(
                color: glow!.withOpacity(0.5), blurRadius: 9, spreadRadius: 0.6),
        ],
      ),
      child: ClipRRect(
        borderRadius: r,
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
          child: CustomPaint(
            foregroundPainter: _RimPainter(radius: radius, tint: glow),
            child: Container(
              padding: padding,
              decoration: BoxDecoration(
                borderRadius: r,
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Colors.white.withOpacity(0.17),
                    Colors.white.withOpacity(0.05),
                    Colors.white.withOpacity(0.09),
                  ],
                  stops: const [0.0, 0.55, 1.0],
                ),
              ),
              child: child,
            ),
          ),
        ),
      ),
    );
  }
}

/// حافة زجاج: لمعتان على الزاويتين المتقابلتين وبينهما حد خافت، مع لمعة داخلية رقيقة.
class _RimPainter extends CustomPainter {
  final double radius;
  final Color? tint;
  const _RimPainter({required this.radius, this.tint});

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;
    final rr = RRect.fromRectAndRadius(
        (Offset.zero & size).deflate(0.7),
        Radius.circular(math.min(radius, math.min(size.width, size.height) / 2)));
    final base = tint ?? Colors.white;

    // الحافة الخارجية: لمعة قوية عند الزاويتين، وخافتة بينهما
    final rim = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = tint != null ? 1.3 : 1.15
      ..shader = LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          Colors.white.withOpacity(0.85),
          base.withOpacity(tint != null ? 0.55 : 0.14),
          base.withOpacity(tint != null ? 0.55 : 0.14),
          Colors.white.withOpacity(0.6),
        ],
        stops: const [0.0, 0.3, 0.7, 1.0],
      ).createShader(Offset.zero & size);
    canvas.drawRRect(rr, rim);

    // ظل داخلي رقيق أسفل اليمين يعطي سماكة للزجاج
    final inner = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.2
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2.0)
      ..shader = LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          Colors.white.withOpacity(0.0),
          Colors.black.withOpacity(0.0),
          Colors.black.withOpacity(0.28),
        ],
      ).createShader(Offset.zero & size);
    canvas.drawRRect(rr.deflate(1.6), inner);

    // لمعة علوية: قوس أبيض باهت قرب الحافة العلوية
    final glint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Colors.white.withOpacity(0.30), Colors.white.withOpacity(0.0)],
        stops: const [0.0, 0.5],
      ).createShader(Offset.zero & size);
    canvas.drawRRect(rr.deflate(2.2), glint);
  }

  @override
  bool shouldRepaint(covariant _RimPainter old) =>
      old.radius != radius || old.tint != tint;
}

class GlassButton extends StatelessWidget {
  final IconData icon;
  final String? label;
  final VoidCallback onTap;
  final Color color;
  final bool big;
  const GlassButton({
    super.key,
    required this.icon,
    required this.onTap,
    this.label,
    this.color = DG.text,
    this.big = false,
  });

  @override
  Widget build(BuildContext context) {
    final s = big ? 64.0 : 46.0;
    return GestureDetector(
      onTap: onTap,
      child: GlassPanel(
        radius: s,
        glow: color == DG.text ? null : color,
        padding: EdgeInsets.symmetric(
            horizontal: label == null ? (s - 22) / 2 : 16, vertical: (s - 22) / 2),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, color: color, size: big ? 28 : 22),
          if (label != null) ...[
            const SizedBox(width: 8),
            Text(label!, style: TextStyle(color: color, fontSize: 14)),
          ],
        ]),
      ),
    );
  }
}
