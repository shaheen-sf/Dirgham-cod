package com.dirgham.code

import android.content.Context

object Settings {
    private fun p(c: Context) = c.getSharedPreferences("dirgham", Context.MODE_PRIVATE)

    fun activeModel(c: Context): String = p(c).getString("model", "") ?: ""
    fun setActiveModel(c: Context, v: String) { p(c).edit().putString("model", v).apply() }

    fun thinking(c: Context): Boolean = p(c).getBoolean("thinking", false)
    fun setThinking(c: Context, v: Boolean) { p(c).edit().putBoolean("thinking", v).apply() }

    // ملف التشغيل المختار بالفحص الذاتي (فارغ = لم يُفحص بعد). يرتبط برقم البناء كي يُعاد الفحص بعد كل تحديث.
    fun profile(c: Context): String = p(c).getString("profile", "") ?: ""
    fun setProfile(c: Context, v: String) { p(c).edit().putString("profile", v).apply() }
}
