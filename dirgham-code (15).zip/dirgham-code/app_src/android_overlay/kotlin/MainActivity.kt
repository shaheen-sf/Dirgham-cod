package com.dirgham.code

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.app.ActivityCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.util.Locale

class MainActivity : FlutterActivity() {

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    companion object {
        @Volatile var visible = false
    }

    override fun onStart() { super.onStart(); visible = true; try { Confirm.replay() } catch (_: Exception) {} }
    override fun onStop() { visible = false; super.onStop() }

    override fun onCreate(savedInstanceState: Bundle?) {
        Crash.init(this)
        super.onCreate(savedInstanceState)
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 78)
        }
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale("ar"))
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
            }
        }
    }

    private fun startSvc(i: Intent) {
        try { startForegroundService(i) } catch (e: Exception) {
            try { startService(i) } catch (e2: Exception) {
                Bus.emit("error", "تعذّر تشغيل الخدمة: " + (e2.message ?: ""))
            }
        }
    }

    private fun svc(action: String, fill: (Intent) -> Unit = {}) {
        val i = Intent(this, AgentService::class.java).setAction(action)
        fill(i)
        startSvc(i)
    }

    override fun configureFlutterEngine(engine: FlutterEngine) {
        super.configureFlutterEngine(engine)
        val messenger = engine.dartExecutor.binaryMessenger

        EventChannel(messenger, "dirgham/agent_events").setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(args: Any?, sink: EventChannel.EventSink) { Bus.sink = sink }
            override fun onCancel(args: Any?) { Bus.sink = null }
        })

        MethodChannel(messenger, "dirgham/agent").setMethodCallHandler { call, res ->
            try {
                handle(call.method, call, res)
            } catch (e: Exception) {
                res.error("native", e.message, null)
            }
        }
    }

    private fun handle(method: String, call: io.flutter.plugin.common.MethodCall, res: MethodChannel.Result) {
        when (method) {
            "startService" -> {
                startSvc(Intent(this, AgentService::class.java))
                res.success(null)
            }
            "submitTask" -> {
                val p = call.argument<String>("prompt")
                svc(AgentService.ACTION_SUBMIT) { it.putExtra("prompt", p) }
                res.success(null)
            }
            "cancel" -> { svc(AgentService.ACTION_CANCEL); res.success(null) }
            "newChat" -> { svc(AgentService.ACTION_NEWCHAT); res.success(null) }
            "restoreChat" -> {
                val j = call.argument<String>("json").orEmpty()
                svc(AgentService.ACTION_RESTORE) { it.putExtra("json", j) }
                res.success(null)
            }

            "download" -> {
                val url = call.argument<String>("url")
                val name = call.argument<String>("name")
                svc(AgentService.ACTION_DOWNLOAD) { it.putExtra("url", url).putExtra("name", name) }
                res.success(null)
            }
            "cancelDownload" -> {
                val name = call.argument<String>("name")
                svc(AgentService.ACTION_DL_CANCEL) { it.putExtra("name", name) }
                res.success(null)
            }
            "downloadStates" -> res.success(Downloads.snapshot())

            "listModels" -> {
                val active = LlamaEngine.activeModel(this)?.name
                val list = LlamaEngine.listModels(this).map {
                    mapOf("name" to it.name, "size" to it.length(), "active" to (it.name == active))
                }
                res.success(list)
            }
            "setActiveModel" -> {
                Settings.setActiveModel(this, call.argument<String>("name").orEmpty())
                res.success(null)
            }
            "deleteModel" -> {
                val n = call.argument<String>("name").orEmpty()
                if (n.contains("/") || n.contains("..")) {
                    res.error("bad", "اسم غير صالح", null)
                } else {
                    File(LlamaEngine.modelsDir(this), n).delete()
                    File(LlamaEngine.modelsDir(this), "$n.part").delete()
                    Downloads.states.remove(n)
                    res.success(null)
                }
            }
            "modelsDir" -> res.success(LlamaEngine.modelsDir(this).absolutePath)
            "nativeOk" -> res.success(LlamaEngine.nativeOk)

            "getThinking" -> res.success(Settings.thinking(this))
            "setThinking" -> {
                Settings.setThinking(this, call.argument<Boolean>("on") == true)
                res.success(null)
            }

            "confirmResult" -> {
                Confirm.answer(call.argument<String>("id").orEmpty(), call.argument<Boolean>("ok") == true)
                res.success(null)
            }

            "startListening" -> { startListening(); res.success(null) }
            "stopListening" -> { recognizer?.stopListening(); res.success(null) }
            "speak" -> {
                if (ttsReady) tts?.speak(call.argument<String>("text").orEmpty(), TextToSpeech.QUEUE_FLUSH, null, "dg")
                res.success(ttsReady)
            }
            "stopSpeak" -> { tts?.stop(); res.success(null) }

            "bridgeCommand" -> {
                LocalBridge.start(47611, Settings.bridgeToken(this))
                res.success(LocalBridge.installCommand())
            }
            "setGithubToken" -> { Settings.setGithubToken(this, call.argument<String>("token").orEmpty()); res.success(null) }
            "hasGithubToken" -> res.success(Settings.githubToken(this).isNotBlank())
            "setMediaSettings" -> {
                val ek = call.argument<String>("elevenKey").orEmpty()
                Settings.setEleven(this, if (ek == "__keep__") Settings.elevenKey(this) else ek, call.argument<String>("elevenVoice").orEmpty())
                Settings.setIdleMinutes(this, call.argument<Int>("idleMin") ?: 5)
                Settings.setFastModel(this, call.argument<String>("fastModel").orEmpty())
                val th = call.argument<Int>("threads") ?: 0
                Settings.setThreads(this, th); LlamaEngine.shared(this).setThreads(th)
                val gk = call.argument<String>("geminiKey").orEmpty()
                if (gk != "__keep__") Settings.setGeminiKey(this, gk)
                res.success(null)
            }
            "lastCrash" -> res.success(Crash.report())
            "setLocalCmds" -> { Settings.setLocalCmds(this, call.argument<String>("tts").orEmpty(), call.argument<String>("img").orEmpty()); res.success(null) }
            "getLocalCmds" -> res.success(mapOf("tts" to Settings.ttsCmd(this), "img" to Settings.imgCmd(this)))
            "getMediaSettings" -> res.success(mapOf(
                "hasEleven" to Settings.elevenKey(this).isNotBlank(),
                "elevenVoice" to Settings.elevenVoice(this),
                "idleMin" to Settings.idleMinutes(this),
                "fastModel" to Settings.fastModel(this),
                "threads" to Settings.threads(this),
                "hasGemini" to Settings.geminiKey(this).isNotBlank(),
                "cores" to Runtime.getRuntime().availableProcessors()))
            "bridgeConnected" -> res.success(LocalBridge.connected())
            "termuxInstalled" -> res.success(TermuxBridge.isInstalled(this))
            "termuxPermissionGranted" -> res.success(TermuxBridge.hasPermission(this))
            "requestTermuxPermission" -> {
                if (!TermuxBridge.isInstalled(this)) {
                    Bus.emit("status", "Termux غير مثبّت.")
                } else if (TermuxBridge.hasPermission(this)) {
                    Bus.emit("status", "الإذن ممنوح مسبقًا.")
                } else {
                    ActivityCompat.requestPermissions(this, arrayOf(TermuxBridge.PERMISSION), 77)
                }
                res.success(null)
            }
            "openAppSettings" -> {
                val i = Intent(AndroidSettings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
                res.success(null)
            }
            "termuxTest" -> { svc(AgentService.ACTION_TERMUX_TEST); res.success(null) }
            "openApp" -> res.success(TermuxBridge.openApp(this, call.argument<String>("pkg").orEmpty()))
            "saveFile" -> {
                val src = java.io.File(call.argument<String>("path").orEmpty())
                val nm = call.argument<String>("name").orEmpty()
                val mime = call.argument<String>("mime") ?: "application/octet-stream"
                Thread {
                    val r = try { if (src.isFile) Deliver.saveToDownloads(this, src, nm, mime) else "" } catch (_: Exception) { "" }
                    runOnUiThread { res.success(r) }
                }.start()
            }
            "listSkills" -> {
                val arr = org.json.JSONArray()
                for (n in Skills.names(this)) arr.put(org.json.JSONObject().put("name", n).put("desc", Skills.description(this, n)).put("builtin", Skills.isBuiltin(n)))
                res.success(arr.toString())
            }
            "readSkill" -> res.success(Skills.read(this, call.argument<String>("name").orEmpty()) ?: "")
            "deleteSkill" -> res.success(Skills.delete(this, call.argument<String>("name").orEmpty()))
            "importFile" -> {
                val src = call.argument<String>("path").orEmpty()
                val nm = call.argument<String>("name").orEmpty()
                Thread {
                    val r = try { Inputs.import(this, src, nm) } catch (e: Exception) { "[attached: $nm] تعذّر الاستيراد: ${e.message}" }
                    runOnUiThread { res.success(r) }
                }.start()
            }
            "openUri" -> {
                val u = android.net.Uri.parse(call.argument<String>("uri").orEmpty())
                val mime = call.argument<String>("mime") ?: "*/*"
                val share = call.argument<Boolean>("share") == true
                try {
                    val i = if (share)
                        Intent.createChooser(Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), null)
                    else
                        Intent(Intent.ACTION_VIEW).setDataAndType(u, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    startActivity(i)
                    res.success(true)
                } catch (e: Exception) { res.success(false) }
            }
            "openPreview" -> {
                startActivity(Intent(this, PreviewActivity::class.java).putExtra("path", call.argument<String>("path")))
                res.success(null)
            }
            else -> res.notImplemented()
        }
    }

    private fun speechIntent() = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA")
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-SA")
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(RecognizerIntent.EXTRA_PROMPT, "تحدّث الآن")
    }

    private fun errText(e: Int): String = when (e) {
        SpeechRecognizer.ERROR_AUDIO -> "تعذّر التقاط الصوت من الميكروفون"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "إذن الميكروفون غير ممنوح (إعدادات التطبيق ← الأذونات ← الميكروفون)"
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "التعرف على الصوت يحتاج إنترنت (أو حزمة عربية دون اتصال في خدمات Google)"
        SpeechRecognizer.ERROR_NO_MATCH -> "لم أفهم الكلام، حاول ثانية بصوت أوضح"
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "لم أسمع صوتًا"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "خدمة التعرف مشغولة، حاول بعد لحظة"
        11, 12, 13 -> "اللغة العربية غير متاحة في خدمة التعرف على هذا الجهاز"
        else -> "خطأ في التعرف على الصوت (رمز $e)"
    }

    private fun startListening() {
        if (android.os.Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.RECORD_AUDIO), 79)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            // لا خدمة مدمجة: نفتح نافذة التعرف الصوتي القياسية إن وُجدت
            try { startActivityForResult(speechIntent(), 80); return } catch (_: Exception) {}
            Bus.emit("error", "لا توجد خدمة تعرف على الصوت على الجهاز. ثبّت/فعّل «خدمات Google للكلام» أو تطبيق Google.")
            Bus.emit("voice_end")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { Bus.emit("status", "🎙 أسمعك… تحدّث الآن") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rms: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, p: Bundle?) {}
                override fun onError(error: Int) {
                    Bus.emit("status", "🎙 " + errText(error))
                    Bus.emit("voice_end")
                }
                override fun onPartialResults(b: Bundle?) {
                    b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                        ?.let { Bus.emit("transcript", it) }
                }
                override fun onResults(b: Bundle?) {
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrBlank()) Bus.emit("voice_end") else Bus.emit("final", t)
                }
            })
        }
        recognizer?.startListening(speechIntent())
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 80) {
            val t = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (resultCode == RESULT_OK && !t.isNullOrBlank()) Bus.emit("final", t) else Bus.emit("voice_end")
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 79) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startListening()
            else { Bus.emit("status", "🎙 لم يُمنح إذن الميكروفون. امنحه من إعدادات التطبيق ← الأذونات."); Bus.emit("voice_end") }
        }
        if (requestCode == 77) {
            val ok = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            Bus.emit(
                "status",
                if (ok) "تم منح إذن Termux."
                else "لم يُمنح الإذن. إن لم تظهر نافذة طلب فالسبب أن Termux ثُبّت بعد التطبيق: " +
                    "احذف ضرغام كود ثم ثبّته ثانية (بعد وجود Termux)، أو امنح الإذن من " +
                    "إعدادات التطبيق ← الأذونات ← أذونات إضافية ← Run commands in Termux environment."
            )
        }
    }
}
