import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';

/// رسالة محفوظة: النوع (فهرس MsgKind) ونصها.
class SavedMsg {
  final int kind;
  final String text;
  const SavedMsg(this.kind, this.text);
  Map<String, dynamic> toJson() => {'k': kind, 't': text};
  static SavedMsg fromJson(Map<String, dynamic> j) => SavedMsg((j['k'] as num?)?.toInt() ?? 0, (j['t'] as String?) ?? '');
}

class SavedChat {
  final String id;
  String title;
  int ts;
  List<SavedMsg> msgs;
  SavedChat(this.id, this.title, this.ts, this.msgs);
  Map<String, dynamic> toJson() => {'id': id, 'title': title, 'ts': ts, 'msgs': msgs.map((m) => m.toJson()).toList()};
  static SavedChat fromJson(Map<String, dynamic> j) => SavedChat(
        j['id'] as String,
        (j['title'] as String?) ?? 'محادثة',
        (j['ts'] as num?)?.toInt() ?? 0,
        ((j['msgs'] as List?) ?? const []).map((e) => SavedMsg.fromJson(Map<String, dynamic>.from(e as Map))).toList(),
      );
}

/// تخزين المحادثات في ملف JSON داخل مجلد التطبيق (يبقى بعد التحديث).
class ChatStore {
  static List<SavedChat>? _cache;

  static Future<File> _file() async {
    final d = await getApplicationDocumentsDirectory();
    return File('${d.path}/chats.json');
  }

  static Future<List<SavedChat>> all() async {
    if (_cache != null) return _cache!;
    try {
      final f = await _file();
      if (await f.exists()) {
        final l = jsonDecode(await f.readAsString()) as List<dynamic>;
        _cache = l.map((e) => SavedChat.fromJson(Map<String, dynamic>.from(e as Map))).toList();
      }
    } catch (_) {}
    _cache ??= [];
    _cache!.sort((a, b) => b.ts.compareTo(a.ts));
    return _cache!;
  }

  static Future<void> _flush() async {
    try {
      final f = await _file();
      await f.writeAsString(jsonEncode(_cache!.map((c) => c.toJson()).toList()));
    } catch (_) {}
  }

  static Future<void> save(SavedChat c) async {
    final l = await all();
    l.removeWhere((x) => x.id == c.id);
    c.ts = DateTime.now().millisecondsSinceEpoch;
    l.insert(0, c);
    while (l.length > 60) {
      l.removeLast();
    }
    await _flush();
  }

  static Future<void> delete(String id) async {
    final l = await all();
    l.removeWhere((x) => x.id == id);
    await _flush();
  }
}
