import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../theme.dart';

/// زجاج سائل على نهج iOS 27: ضبابية خلفية + حافة لامعة بزاويتين (ضوء علوي أيسر/سفلي أيمن)
/// + ظل داخلي رقيق + لمعة علوية. بلا اعتماديات خارجية، ويعمل على Skia وImpeller.
class GlassPanel extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final double radius;
  final Color? glow;
  const GlassPanel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.radius = 22,
    this.glow,
  });

  @override
  Widget build(BuildContext context) {
    final r = BorderRadius.circular(radius);
    return Container(
      decoration: BoxDecoration(
        borderRadius: r,
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.38),
              blurRadius: 16,
              offset: const Offset(0, 6)),
          // إضاءة حادة ضيقة تحيط بالحافة (بلا مبالغة)
          if (glow != null)
            BoxShadow(
                color: glow!.withOpacity(0.5), blurRadius: 9, spreadRadius: 0.6),
        ],
      ),
      child: ClipRRect(
        borderRadius: r,
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
          child: CustomPaint(
            foregroundPainter: _RimPainter(radius: radius, tint: glow),
            child: Container(
              padding: padding,
              decoration: BoxDecoration(
                borderRadius: r,
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Colors.white.withOpacity(0.17),
                    Colors.white.withOpacity(0.05),
                    Colors.white.withOpacity(0.09),
                  ],
                  stops: const [0.0, 0.55, 1.0],
                ),
              ),
              child: child,
            ),
          ),
        ),
      ),
    );
  }
}

/// حافة زجاج: لمعتان على الزاويتين المتقابلتين وبينهما حد خافت، مع لمعة داخلية رقيقة.
class _RimPainter extends CustomPainter {
  final double radius;
  final Color? tint;
  const _RimPainter({required this.radius, this.tint});

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;
    final rr = RRect.fromRectAndRadius(
        (Offset.zero & size).deflate(0.7),
        Radius.circular(math.min(radius, math.min(size.width, size.height) / 2)));
    final base = tint ?? Colors.white;

    // الحافة الخارجية: لمعة قوية عند الزاويتين، وخافتة بينهما
    final rim = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = tint != null ? 1.3 : 1.15
      ..shader = LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          Colors.white.withOpacity(0.85),
          base.withOpacity(tint != null ? 0.55 : 0.14),
          base.withOpacity(tint != null ? 0.55 : 0.14),
          Colors.white.withOpacity(0.6),
        ],
        stops: const [0.0, 0.3, 0.7, 1.0],
      ).createShader(Offset.zero & size);
    canvas.drawRRect(rr, rim);

    // ظل داخلي رقيق أسفل اليمين يعطي سماكة للزجاج
    final inner = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.2
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2.0)
      ..shader = LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          Colors.white.withOpacity(0.0),
          Colors.black.withOpacity(0.0),
          Colors.black.withOpacity(0.28),
        ],
      ).createShader(Offset.zero & size);
    canvas.drawRRect(rr.deflate(1.6), inner);

    // لمعة علوية: قوس أبيض باهت قرب الحافة العلوية
    final glint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Colors.white.withOpacity(0.30), Colors.white.withOpacity(0.0)],
        stops: const [0.0, 0.5],
      ).createShader(Offset.zero & size);
    canvas.drawRRect(rr.deflate(2.2), glint);
  }

  @override
  bool shouldRepaint(covariant _RimPainter old) =>
      old.radius != radius || old.tint != tint;
}

/// ضغط حيّ: انكماش نابض + وميض + اهتزاز خفيف.
class Pressable extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final Color glow;
  const Pressable({super.key, required this.child, this.onTap, this.glow = DG.fire});
  @override
  State<Pressable> createState() => _PressableState();
}

class _PressableState extends State<Pressable> {
  bool _down = false;
  @override
  Widget build(BuildContext context) => GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapDown: (_) => setState(() => _down = true),
        onTapCancel: () => setState(() => _down = false),
        onTapUp: (_) => setState(() => _down = false),
        onTap: () {
          HapticFeedback.selectionClick();
          widget.onTap?.call();
        },
        child: AnimatedScale(
          scale: _down ? 0.90 : 1.0,
          duration: Duration(milliseconds: _down ? 90 : 320),
          curve: _down ? Curves.easeOut : Curves.elasticOut,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 160),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(64),
              boxShadow: _down ? [BoxShadow(color: widget.glow.withOpacity(0.45), blurRadius: 18)] : const [],
            ),
            child: widget.child,
          ),
        ),
      );
}

/// ظهور سينمائي: تلاشٍ + صعود + تكبير خفيف، مع تأخير اختياري للتتابع.
class Reveal extends StatefulWidget {
  final Widget child;
  final int delayMs;
  const Reveal({super.key, required this.child, this.delayMs = 0});
  @override
  State<Reveal> createState() => _RevealState();
}

class _RevealState extends State<Reveal> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 520));
  late final Animation<double> _a = CurvedAnimation(parent: _c, curve: Curves.easeOutCubic);

  @override
  void initState() {
    super.initState();
    if (widget.delayMs == 0) {
      _c.forward();
    } else {
      Future.delayed(Duration(milliseconds: widget.delayMs), () {
        if (mounted) _c.forward();
      });
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: _a,
        builder: (_, child) => Opacity(
          opacity: _a.value,
          child: Transform.translate(
            offset: Offset(0, 18 * (1 - _a.value)),
            child: Transform.scale(scale: 0.96 + 0.04 * _a.value, child: child),
          ),
        ),
        child: widget.child,
      );
}

/// انتقال صفحات سينمائي: تلاشٍ + انزلاق + تكبير.
Route<T> dgRoute<T>(Widget page) => PageRouteBuilder<T>(
      transitionDuration: const Duration(milliseconds: 420),
      reverseTransitionDuration: const Duration(milliseconds: 320),
      pageBuilder: (_, __, ___) => page,
      transitionsBuilder: (_, a, __, child) {
        final c = CurvedAnimation(parent: a, curve: Curves.easeOutCubic, reverseCurve: Curves.easeInCubic);
        return FadeTransition(
          opacity: c,
          child: SlideTransition(
            position: Tween<Offset>(begin: const Offset(0, 0.06), end: Offset.zero).animate(c),
            child: ScaleTransition(scale: Tween<double>(begin: 0.96, end: 1.0).animate(c), child: child),
          ),
        );
      },
    );

class GlassButton extends StatelessWidget {
  final IconData icon;
  final String? label;
  final VoidCallback onTap;
  final Color color;
  final bool big;
  const GlassButton({
    super.key,
    required this.icon,
    required this.onTap,
    this.label,
    this.color = DG.text,
    this.big = false,
  });

  @override
  Widget build(BuildContext context) {
    final s = big ? 64.0 : 46.0;
    return Pressable(
      onTap: onTap,
      glow: color == DG.text ? DG.fire : color,
      child: GlassPanel(
        radius: s,
        glow: color == DG.text ? null : color,
        padding: EdgeInsets.symmetric(
            horizontal: label == null ? (s - 22) / 2 : 16, vertical: (s - 22) / 2),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, color: color, size: big ? 28 : 22),
          if (label != null) ...[
            const SizedBox(width: 8),
            Text(label!, style: TextStyle(color: color, fontSize: 14)),
          ],
        ]),
      ),
    );
  }
}
