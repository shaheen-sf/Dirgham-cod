#include <jni.h>
#include <android/log.h>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>
#include "llama.h"
#include "compute_check.h"

#define TAG "DirghamLlama"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

struct Handle {
    llama_model * model = nullptr;
    int n_ctx = 4096;
    int n_threads = 4;
    bool kv_f32 = false;   // مخبأ K/V بدقة كاملة بدل f16
    int n_batch = 512;     // حجم دفعة المعالجة
    // سياق مُعاد استعماله بين الاستدعاءات: نحتفظ بمخبأ K/V لبادئة الموجّه المشتركة فلا تُعاد معالجتها
    llama_context * ctx = nullptr;
    std::vector<llama_token> cached;
    int ctx_key_threads = 0, ctx_key_batch = 0, ctx_key_ctx = 0;
    bool ctx_key_f32 = false;
};

static void drop_ctx(Handle * H) {
    if (H->ctx) { llama_free(H->ctx); H->ctx = nullptr; }
    H->cached.clear();
}

static bool g_backend_ready = false;

// ---- تكيّف مع تغيّر واجهة تحميل النموذج بين إصدارات llama.cpp ----
// الإصدارات الحديثة: load_mode (0 = NONE = قراءة كاملة بلا mmap). القديمة: use_mmap.
template <class P> static auto set_load(P & p, int) -> decltype((void) p.load_mode, void()) {
    p.load_mode = (decltype(p.load_mode)) 0;
}
template <class P> static auto set_load(P & p, long) -> decltype((void) p.use_mmap, void()) {
    p.use_mmap = false;
}
template <class P> static void set_load(P &, ...) {}

// llama_sampler_init_penalties: خمسة معاملات (مع n_vocab) في نسخ، وأربعة في أخرى
template <class T = float> static auto make_penalties(int nv, int last, float r, float f, T p, int)
    -> decltype(llama_sampler_init_penalties(nv, last, r, f, p)) {
    return llama_sampler_init_penalties(nv, last, r, f, p);
}
template <class T = float> static auto make_penalties(int, int last, float r, float f, T p, long)
    -> decltype(llama_sampler_init_penalties(last, r, f, p)) {
    return llama_sampler_init_penalties(last, r, f, p);
}

// تعطيل Flash Attention على المعالج (مسار أحدث وأقل اختبارًا على أندرويد)
template <class P> static auto set_fa(P & p, int) -> decltype((void) p.flash_attn_type, void()) {
    p.flash_attn_type = (decltype(p.flash_attn_type)) 0; // DISABLED
}
template <class P> static auto set_fa(P & p, long) -> decltype((void) p.flash_attn, void()) {
    p.flash_attn = false;
}
template <class P> static void set_fa(P &, ...) {}

static std::string jstr(JNIEnv * env, jstring s) {
    if (!s) return "";
    const char * p = env->GetStringUTFChars(s, nullptr);
    std::string r(p);
    env->ReleaseStringUTFChars(s, p);
    return r;
}

// يفكّ أكبر عدد ممكن من تسلسلات UTF-8 الكاملة إلى UTF-16 ويُبقي الذيل الناقص في pend
static std::u16string drain_utf16(std::string & pend) {
    std::u16string out;
    size_t i = 0, n = pend.size();
    while (i < n) {
        unsigned char c = (unsigned char) pend[i];
        uint32_t cp;
        size_t len;
        if (c < 0x80)              { cp = c;        len = 1; }
        else if ((c >> 5) == 0x6)  { cp = c & 0x1F; len = 2; }
        else if ((c >> 4) == 0xE)  { cp = c & 0x0F; len = 3; }
        else if ((c >> 3) == 0x1E) { cp = c & 0x07; len = 4; }
        else { i++; continue; }
        if (i + len > n) break;
        bool ok = true;
        for (size_t k = 1; k < len; k++) {
            unsigned char cc = (unsigned char) pend[i + k];
            if ((cc & 0xC0) != 0x80) { ok = false; break; }
            cp = (cp << 6) | (cc & 0x3F);
        }
        if (!ok) { i++; continue; }
        if (cp >= 0x10000) {
            cp -= 0x10000;
            out.push_back((char16_t) (0xD800 + (cp >> 10)));
            out.push_back((char16_t) (0xDC00 + (cp & 0x3FF)));
        } else {
            out.push_back((char16_t) cp);
        }
        i += len;
    }
    pend.erase(0, i);
    return out;
}

static jstring to_jstring(JNIEnv * env, const std::string & s) {
    std::string tmp = s;
    std::u16string u = drain_utf16(tmp);
    return env->NewString(reinterpret_cast<const jchar *>(u.data()), (jsize) u.size());
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_dirgham_code_LlamaEngine_nativeLoad(JNIEnv * env, jobject, jstring jpath, jint nCtx, jint nThreads) {
    if (!g_backend_ready) {
        llama_backend_init();
        g_backend_ready = true;
    }
    std::string path = jstr(env, jpath);

    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;
    set_load(mp, 0);
    llama_model * model = llama_model_load_from_file(path.c_str(), mp);
    if (!model) {
        LOGE("failed to load model: %s", path.c_str());
        return 0;
    }
    Handle * h = new Handle();
    h->model = model;
    int train = llama_model_n_ctx_train(model);
    h->n_ctx = (train > 0 && train < nCtx) ? train : nCtx;
    h->n_threads = nThreads;
    return reinterpret_cast<jlong>(h);
}

// تطبيق قالب المحادثة المضمّن في النموذج. يعيد null إن لم يكن للنموذج قالب.
extern "C" JNIEXPORT jstring JNICALL
Java_com_dirgham_code_LlamaEngine_nativeTemplate(JNIEnv * env, jobject, jlong handle, jobjectArray roles,
                                                 jobjectArray contents, jboolean addAss) {
    Handle * H = reinterpret_cast<Handle *>(handle);
    if (!H || !H->model) return nullptr;
    const char * tmpl = llama_model_chat_template(H->model, nullptr);
    if (!tmpl) return nullptr;

    jsize n = env->GetArrayLength(roles);
    std::vector<std::string> r(n), c(n);
    for (jsize i = 0; i < n; i++) {
        jstring a = (jstring) env->GetObjectArrayElement(roles, i);
        jstring b = (jstring) env->GetObjectArrayElement(contents, i);
        r[i] = jstr(env, a);
        c[i] = jstr(env, b);
        env->DeleteLocalRef(a);
        env->DeleteLocalRef(b);
    }
    std::vector<llama_chat_message> msgs(n);
    for (jsize i = 0; i < n; i++) {
        msgs[i].role = r[i].c_str();
        msgs[i].content = c[i].c_str();
    }
    size_t total = 0;
    for (jsize i = 0; i < n; i++) total += r[i].size() + c[i].size() + 32;
    std::vector<char> buf(total * 2 + 1024);
    int32_t len = llama_chat_apply_template(tmpl, msgs.data(), (size_t) n, addAss == JNI_TRUE, buf.data(), (int32_t) buf.size());
    if (len < 0) return nullptr;
    if ((size_t) len > buf.size()) {
        buf.resize((size_t) len + 1);
        len = llama_chat_apply_template(tmpl, msgs.data(), (size_t) n, addAss == JNI_TRUE, buf.data(), (int32_t) buf.size());
        if (len < 0) return nullptr;
    }
    return to_jstring(env, std::string(buf.data(), (size_t) len));
}

// ملف تشغيل (يختاره الفحص الذاتي): عدد الخيوط، دقة المخبأ، حجم الدفعة
extern "C" JNIEXPORT void JNICALL
Java_com_dirgham_code_LlamaEngine_nativeSetProfile(JNIEnv *, jobject, jlong handle, jint threads, jboolean kvF32, jint nBatch) {
    Handle * H = reinterpret_cast<Handle *>(handle);
    if (!H) return;
    H->n_threads = threads < 1 ? 1 : threads;
    H->kv_f32 = kvF32 == JNI_TRUE;
    H->n_batch = nBatch < 1 ? 1 : (nBatch > 2048 ? 2048 : nBatch);
    drop_ctx(H);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_dirgham_code_LlamaEngine_nativeInfo(JNIEnv * env, jobject, jlong handle) {
    std::string s;
    Handle * H = reinterpret_cast<Handle *>(handle);
    if (H && H->model) {
        char desc[256] = {0};
        llama_model_desc(H->model, desc, sizeof(desc));
        s += "النموذج: ";
        s += desc;
        s += "\nالمعاملات: " + std::to_string((long long) (llama_model_n_params(H->model) / 1000000ULL)) + " مليون";
        s += "\nسياق التدريب: " + std::to_string(llama_model_n_ctx_train(H->model));
        s += "\nسياق التشغيل: " + std::to_string(H->n_ctx);
        s += std::string("\nقالب مضمّن: ") + (llama_model_chat_template(H->model, nullptr) ? "نعم" : "لا (سيُستعمل ChatML)");
        s += "\n";
    }
    const char * si = llama_print_system_info();
    s += "النظام: ";
    s += si ? si : "";
    return to_jstring(env, s);
}

extern "C" JNIEXPORT jint JNICALL
Java_com_dirgham_code_LlamaEngine_nativeGenerate(JNIEnv * env, jobject, jlong handle, jstring jprompt,
                                                  jint maxTokens, jfloat temp, jobject cb) {
    Handle * H = reinterpret_cast<Handle *>(handle);
    if (!H || !H->model) return -1;

    jclass cls = env->GetObjectClass(cb);
    jmethodID mid = env->GetMethodID(cls, "onToken", "(Ljava/lang/String;)Z");
    if (!mid) return -2;

    std::string prompt = jstr(env, jprompt);

    const llama_vocab * vocab = llama_model_get_vocab(H->model);

    // تجنّب BOS مزدوج: إن بدأ النص بـ BOS أصلًا (من القالب) فلا نضيف آخر
    bool add_special = llama_vocab_get_add_bos(vocab);
    if (add_special) {
        llama_token bos = llama_vocab_bos(vocab);
        if (bos >= 0) {
            const char * bt = llama_vocab_get_text(vocab, bos);
            if (bt && *bt && prompt.compare(0, strlen(bt), bt) == 0) add_special = false;
        }
    }

    int n = -llama_tokenize(vocab, prompt.c_str(), (int32_t) prompt.size(), nullptr, 0, add_special, true);
    if (n <= 0) return -3;
    std::vector<llama_token> toks(n);
    if (llama_tokenize(vocab, prompt.c_str(), (int32_t) prompt.size(), toks.data(), (int32_t) toks.size(), add_special, true) < 0)
        return -3;

    int allowed = H->n_ctx - (int) maxTokens - 8;
    if (allowed < 64) return -4;
    if ((int) toks.size() > allowed) {
        // نُبقي أحدث الرموز فقط (البداية تُقصّ)
        toks.erase(toks.begin(), toks.begin() + ((int) toks.size() - allowed));
    }

    if (H->ctx && (H->ctx_key_threads != H->n_threads || H->ctx_key_batch != H->n_batch ||
                   H->ctx_key_ctx != H->n_ctx || H->ctx_key_f32 != H->kv_f32)) drop_ctx(H);
    if (!H->ctx) {
        llama_context_params cp = llama_context_default_params();
        cp.n_ctx = H->n_ctx;
        cp.n_batch = H->n_batch;
        cp.n_ubatch = H->n_batch;
        if (H->kv_f32) { cp.type_k = GGML_TYPE_F32; cp.type_v = GGML_TYPE_F32; }
        cp.n_threads = H->n_threads;
        cp.n_threads_batch = H->n_threads;
        set_fa(cp, 0);
        H->ctx = llama_init_from_model(H->model, cp);
        if (!H->ctx) return -5;
        H->ctx_key_threads = H->n_threads; H->ctx_key_batch = H->n_batch;
        H->ctx_key_ctx = H->n_ctx; H->ctx_key_f32 = H->kv_f32;
        H->cached.clear();
    }
    llama_context * ctx = H->ctx;

    // أطول بادئة مشتركة مع ما في المخبأ (نترك رمزًا واحدًا على الأقل ليُعالَج)
    size_t common = 0;
    while (common < H->cached.size() && common < toks.size() && H->cached[common] == toks[common]) common++;
    if (common >= toks.size()) common = toks.size() - 1;
    if (!llama_memory_seq_rm(llama_get_memory(ctx), 0, (llama_pos) common, -1)) {
        llama_memory_clear(llama_get_memory(ctx), true);
        common = 0;
    }
    H->cached.resize(common);

    llama_sampler * smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(smpl, make_penalties(llama_vocab_n_tokens(vocab), 64, 1.1f, 0.0f, 0.0f, 0));
    if (temp <= 0.01f) {
        llama_sampler_chain_add(smpl, llama_sampler_init_greedy());
    } else {
        llama_sampler_chain_add(smpl, llama_sampler_init_top_k(40));
        llama_sampler_chain_add(smpl, llama_sampler_init_top_p(0.9f, 1));
        llama_sampler_chain_add(smpl, llama_sampler_init_temp(temp));
        llama_sampler_chain_add(smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
    }

    int rc = 0;
    const size_t chunk = (size_t) H->n_batch;
    for (size_t i = common; i < toks.size(); i += chunk) {
        int cnt = (int) std::min<size_t>(chunk, toks.size() - i);
        llama_batch b = llama_batch_get_one(toks.data() + i, cnt);
        if (llama_decode(ctx, b) != 0) { rc = -6; break; }
        H->cached.insert(H->cached.end(), toks.begin() + i, toks.begin() + i + cnt);
    }
    if (rc != 0) drop_ctx(H);

    int gen = 0;
    std::string pend;
    while (rc == 0 && gen < maxTokens) {
        llama_token tok = llama_sampler_sample(smpl, ctx, -1);
        if (llama_vocab_is_eog(vocab, tok)) break;

        char buf[256];
        int len = llama_token_to_piece(vocab, tok, buf, sizeof(buf), 0, true);
        if (len > 0) pend.append(buf, (size_t) len);

        std::u16string u = drain_utf16(pend);
        if (!u.empty()) {
            jstring js = env->NewString(reinterpret_cast<const jchar *>(u.data()), (jsize) u.size());
            jboolean cont = env->CallBooleanMethod(cb, mid, js);
            env->DeleteLocalRef(js);
            if (env->ExceptionCheck()) { env->ExceptionClear(); break; }
            if (!cont) break;
        }

        llama_batch b = llama_batch_get_one(&tok, 1);
        if (llama_decode(ctx, b) != 0) { rc = -7; break; }
        H->cached.push_back(tok);
        gen++;
    }
    if (rc != 0) drop_ctx(H);

    llama_sampler_free(smpl);
    return rc != 0 ? rc : gen;
}

// اختبار حسابي مستقل عن النموذج (ggml_mul_mat مقابل مرجع)
extern "C" JNIEXPORT jstring JNICALL
Java_com_dirgham_code_LlamaEngine_nativeComputeCheck(JNIEnv * env, jobject, jint threads) {
    return to_jstring(env, dg_compute_check(threads < 1 ? 1 : threads));
}

// فحص الرموز: معرّفات الرموز، إعادة التركيب، وأفضل 5 احتمالات للرمز التالي
extern "C" JNIEXPORT jstring JNICALL
Java_com_dirgham_code_LlamaEngine_nativeProbe(JNIEnv * env, jobject, jlong handle, jstring jtext) {
    Handle * H = reinterpret_cast<Handle *>(handle);
    if (!H || !H->model) return to_jstring(env, "لا نموذج");
    std::string text = jstr(env, jtext);
    const llama_vocab * vocab = llama_model_get_vocab(H->model);
    std::string out;

    int n = -llama_tokenize(vocab, text.c_str(), (int32_t) text.size(), nullptr, 0, llama_vocab_get_add_bos(vocab), true);
    if (n <= 0) return to_jstring(env, "فشل tokenize");
    std::vector<llama_token> toks(n);
    llama_tokenize(vocab, text.c_str(), (int32_t) text.size(), toks.data(), n, llama_vocab_get_add_bos(vocab), true);

    out += "الرموز: ";
    std::string round;
    for (int i = 0; i < n; i++) {
        char b[128];
        int l = llama_token_to_piece(vocab, toks[i], b, sizeof(b), 0, true);
        if (l > 0) round.append(b, (size_t) l);
        out += std::to_string(toks[i]) + (i + 1 < n ? "," : "");
    }
    out += "\nإعادة التركيب: [" + round + "]\n";

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = 512; cp.n_batch = 512; cp.n_ubatch = 512;
    cp.n_threads = H->n_threads; cp.n_threads_batch = H->n_threads;
    llama_context * ctx = llama_init_from_model(H->model, cp);
    if (!ctx) return to_jstring(env, out + "فشل إنشاء السياق");
    llama_batch b = llama_batch_get_one(toks.data(), n);
    if (llama_decode(ctx, b) != 0) { llama_free(ctx); return to_jstring(env, out + "فشل decode"); }

    const float * lg = llama_get_logits_ith(ctx, -1);
    int nv = llama_vocab_n_tokens(vocab);
    std::vector<int> idx(nv);
    for (int i = 0; i < nv; i++) idx[i] = i;
    std::partial_sort(idx.begin(), idx.begin() + 5, idx.end(), [&](int a2, int b2) { return lg[a2] > lg[b2]; });
    float mx = lg[idx[0]];
    double sum = 0;
    for (int i = 0; i < nv; i++) sum += std::exp((double) (lg[i] - mx));
    out += "أفضل 5 احتمالات للرمز التالي:\n";
    for (int k = 0; k < 5; k++) {
        char pb[128];
        int l = llama_token_to_piece(vocab, idx[k], pb, sizeof(pb), 0, true);
        std::string piece = l > 0 ? std::string(pb, (size_t) l) : "?";
        char line[256];
        snprintf(line, sizeof(line), "  %d [%s] %.1f%%\n", idx[k], piece.c_str(), 100.0 * std::exp((double) (lg[idx[k]] - mx)) / sum);
        out += line;
    }
    llama_free(ctx);
    return to_jstring(env, out);
}

extern "C" JNIEXPORT void JNICALL
Java_com_dirgham_code_LlamaEngine_nativeFree(JNIEnv *, jobject, jlong handle) {
    Handle * H = reinterpret_cast<Handle *>(handle);
    if (!H) return;
    drop_ctx(H);
    if (H->model) llama_model_free(H->model);
    delete H;
}
