import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../theme.dart';

/// خلفية فحمية/كحلية بنقوش حضرمية (معينات ومثلثات) ونقاط خط المسند، خافتة جدًا.
class PatternBackground extends StatelessWidget {
  final Widget child;
  const PatternBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) => Stack(children: [
        const Positioned.fill(child: CustomPaint(painter: _PatternPainter())),
        child,
      ]);
}

class _PatternPainter extends CustomPainter {
  const _PatternPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [DG.navy, DG.charcoal],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, bg);

    final line = Paint()
      ..color = DG.gold.withOpacity(0.045)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8;
    final dot = Paint()..color = DG.text.withOpacity(0.05);

    const cell = 56.0;
    for (double y = 0; y < size.height + cell; y += cell) {
      for (double x = 0; x < size.width + cell; x += cell) {
        final c = Offset(x, y);
        // معيّن حضرمي مزدوج
        final p = Path()
          ..moveTo(c.dx, c.dy - 18)
          ..lineTo(c.dx + 18, c.dy)
          ..lineTo(c.dx, c.dy + 18)
          ..lineTo(c.dx - 18, c.dy)
          ..close();
        canvas.drawPath(p, line);
        canvas.drawCircle(c, 2.2, dot);
        // نقاط على نمط المسند بين المعينات
        final k = ((x ~/ cell) + (y ~/ cell)) % 3;
        for (int i = 0; i <= k; i++) {
          canvas.drawCircle(c + Offset(cell / 2, cell / 2 + i * 6), 1.2, dot);
        }
        // مثلثات الحواف
        if ((x ~/ cell + y ~/ cell).isEven) {
          final t = Path()
            ..moveTo(c.dx + cell / 2 - 5, c.dy + cell / 2 - 14)
            ..lineTo(c.dx + cell / 2 + 5, c.dy + cell / 2 - 14)
            ..lineTo(c.dx + cell / 2, c.dy + cell / 2 - 14 - 8 * math.sqrt(0.75));
          canvas.drawPath(t, line);
        }
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}
