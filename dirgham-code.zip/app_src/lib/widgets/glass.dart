import 'dart:ui';
import 'package:flutter/material.dart';
import '../theme.dart';

/// طبقة زجاج سائل: ضبابية خلفية + حد لامع + توهج خفيف اختياري.
class GlassPanel extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final double radius;
  final Color? glow;
  const GlassPanel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.radius = 22,
    this.glow,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        boxShadow: [
          BoxShadow(
              color: (glow ?? Colors.black).withOpacity(glow == null ? 0.35 : 0.22),
              blurRadius: glow == null ? 18 : 22,
              offset: const Offset(0, 6)),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(radius),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
          child: Container(
            padding: padding,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(radius),
              gradient: LinearGradient(
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
                colors: [
                  Colors.white.withOpacity(0.13),
                  Colors.white.withOpacity(0.04),
                ],
              ),
              border: Border.all(color: Colors.white.withOpacity(0.16), width: 0.8),
            ),
            child: child,
          ),
        ),
      ),
    );
  }
}

class GlassButton extends StatelessWidget {
  final IconData icon;
  final String? label;
  final VoidCallback onTap;
  final Color color;
  final bool big;
  const GlassButton({
    super.key,
    required this.icon,
    required this.onTap,
    this.label,
    this.color = DG.text,
    this.big = false,
  });

  @override
  Widget build(BuildContext context) {
    final s = big ? 64.0 : 46.0;
    return GestureDetector(
      onTap: onTap,
      child: GlassPanel(
        radius: s,
        glow: color == DG.text ? null : color,
        padding: EdgeInsets.symmetric(
            horizontal: label == null ? (s - 22) / 2 : 16, vertical: (s - 22) / 2),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, color: color, size: big ? 28 : 22),
          if (label != null) ...[
            const SizedBox(width: 8),
            Text(label!, style: TextStyle(color: color, fontSize: 14)),
          ],
        ]),
      ),
    );
  }
}
