package com.dirgham.code

import android.content.Context
import java.io.File

/** المهارات: ملفات SKILL.md يقرؤها الوكيل عند الحاجة. تُثبَّت من رابط أو نص، وتُحفظ في التخزين الداخلي. */
object Skills {
    fun dir(c: Context): File = File(c.filesDir, "skills").also { it.mkdirs() }

    fun ensureBuiltins(c: Context) {
        for ((name, text) in BUILTIN) {
            val d = File(dir(c), name)
            d.mkdirs()
            File(d, "SKILL.md").writeText(text)
        }
    }

    fun names(c: Context): List<String> =
        (dir(c).listFiles() ?: emptyArray()).filter { File(it, "SKILL.md").exists() }.map { it.name }.sorted()

    fun read(c: Context, name: String): String? {
        val f = File(File(dir(c), name), "SKILL.md")
        return if (f.exists()) f.readText() else null
    }

    fun description(text: String): String {
        val m = Regex("(?m)^description:\\s*(.+)$").find(text)
        return m?.groupValues?.get(1)?.trim() ?: text.lineSequence().firstOrNull { it.isNotBlank() }?.take(100) ?: ""
    }

    fun save(c: Context, name: String, text: String) {
        val d = File(dir(c), name)
        d.mkdirs()
        File(d, "SKILL.md").writeText(text)
    }

    private val BUILTIN: Map<String, String> = mapOf(
        "motion-graphics" to """---
name: motion-graphics
description: صناعة موشن جرافيك متحرك (نصوص، أشكال، انتقالات) كصفحة HTML تُعرض داخل التطبيق، مع طريقة اختيارية لتصديره فيديو عبر Termux.
---
# موشن جرافيك

## المسار الأساسي (يعمل مباشرة)
1. اكتب ملف HTML واحدًا مستقلًا بأداة write_file في المسار motion/اسم.html.
2. استعمل CSS animations أو canvas مع requestAnimationFrame. أبعاد المسرح 1280x720 داخل عنصر ثابت.
3. اجعل الحركة تتكرر (loop) وبمدة 5 إلى 10 ثوانٍ، مع ألوان واضحة وخط عربي مثل Cairo عبر نظام الخطوط الافتراضي.
4. استدع الأداة preview بالمسار نفسه ليراها المستخدم.
5. عدّل الملف عند طلب تغيير وأعد preview.

## تصدير فيديو (اختياري، يحتاج Termux)
1. shell: pkg install -y python ffmpeg imagemagick
2. احفظ سكربت بايثون بأداة termux_save يولّد إطارات PNG (حزمة Pillow) في مجلد frames.
3. shell: ffmpeg -y -framerate 30 -i frames/f%04d.png -c:v libx264 -pix_fmt yuv420p out.mp4
4. أخبر المستخدم أن الملف في مجلد Termux الرئيسي، واقترح فتح CapCut للمونتاج النهائي.

## ملاحظات
- لا تعد بنتيجة سينمائية؛ الحركات البسيطة (ظهور، انزلاق، تكبير، تدرج لوني) هي الأنسب لنموذج صغير.
- اكتب الكود كاملًا في ملف واحد ولا تقتطعه.
""",
        "termux-setup" to """---
name: termux-setup
description: تجهيز Termux بأدوات التطوير الشائعة وحل مشاكل الصلاحيات والتثبيت.
---
# تجهيز Termux

- تحديث: pkg update -y && pkg upgrade -y
- أدوات شائعة: pkg install -y python git nodejs clang make ffmpeg
- تثبيت حزمة بايثون: pip install اسم_الحزمة
- إذا فشل pkg بسبب المرآة: termux-change-repo
- لا تنفّذ أوامر حذف أو تعديل خارج مجلد المشروع دون إذن صريح من المستخدم.
- بعد كل أمر اقرأ exit= في النتيجة؛ إن لم يكن 0 فاقرأ stderr وأصلح الأمر ثم أعد المحاولة مرة واحدة.
""",
        "code-writer" to """---
name: code-writer
description: قواعد كتابة الكود وحفظه واختباره بشكل منظم.
---
# كتابة الكود

1. افهم المطلوب في جملة، ثم اكتب الملفات بأداة write_file في مجلد باسم المشروع.
2. ملفات صغيرة ومسمّاة بوضوح، وتعليقات قصيرة.
3. للتجربة: انقل الملف إلى Termux بـ termux_save ثم شغّله بـ shell (مثال: python3 مجلد/main.py).
4. إن ظهر خطأ فاقرأه وأصلح السبب الجذري ولا تخمّن.
5. اختم بملخص عربي من سطرين: ما الذي كتبته وأين وكيف يشغّله المستخدم.
""",
        "skill-creator" to """---
name: skill-creator
description: كتابة مهارة جديدة وتثبيتها ليستعملها الوكيل لاحقًا.
---
# إنشاء مهارة

صيغة الملف:
---
name: اسم-بحروف-لاتينية-صغيرة
description: جملة واحدة تقول متى تُستعمل المهارة
---
ثم تعليمات مرقّمة قصيرة وواضحة.

للتثبيت استعمل install_skill بالاسم والنص (content)، أو بالرابط (url) إن طلب المستخدم ذلك.
لا تثبّت مهارة من رابط دون أن يوافق المستخدم على الرابط.
"""
    )
}
