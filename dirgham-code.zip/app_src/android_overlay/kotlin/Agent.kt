package com.dirgham.code

import android.content.Context
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import org.json.JSONObject

/**
 * حلقة الوكيل: يولّد النموذج، فإن طلب أداة نفّذناها وأعدنا النتيجة إليه، ونكرر حتى يُنهي.
 * يعمل مع أي نموذج GGUF لأن القالب يُؤخذ من النموذج نفسه.
 */
class Agent(private val ctx: Context, private val llm: LlamaEngine) {

    private val tools = Tools(ctx)
    private val history = ArrayList<Pair<String, String>>() // (role, content) بلا رسالة النظام

    companion object {
        const val MAX_STEPS = 8
        const val MAX_NEW_TOKENS = 900
        const val HISTORY_CHARS = 5500
        private val CALL_RE = Regex("<tool_call>\\s*([\\s\\S]*?)\\s*(?:</tool_call>|\\z)")
    }

    private var modelName: String = ""

    fun clear() { history.clear() }

    private fun systemPrompt(): String {
        val skills = Skills.names(ctx).joinToString("\n") { n ->
            "- $n: " + Skills.description(Skills.read(ctx, n) ?: "")
        }
        return """أنت «ضرغام كود»، وكيل برمجة محلي يعمل على هاتف أندرويد. تتحدث العربية بإيجاز، وتنجز المهام باستعمال الأدوات.
القواعد:
- استعمل أداة فقط عند الحاجة. لا تخترع نتائج؛ انتظر نتيجة الأداة.
- لاستدعاء أداة اكتب في سطر مستقل بالضبط: <tool_call>{"name":"اسم_الأداة","arguments":{...}}</tool_call> ثم توقف. استدعاء واحد في كل رد.
- بعد وصول <tool_response> تابع العمل، وعند الانتهاء اكتب جوابًا نهائيًا قصيرًا بالعربية بلا استدعاء.
- قبل مهمة متخصصة (موشن جرافيك، تجهيز Termux، كتابة مهارة) اقرأ المهارة المناسبة بـ use_skill.
الأدوات:
- list_files {"path":"."} : عرض ملفات مساحة العمل
- read_file {"path":"a.txt"} : قراءة ملف
- write_file {"path":"dir/a.py","content":"..."} : كتابة ملف كامل
- delete_file {"path":"a.txt"}
- shell {"cmd":"python3 a.py"} : تنفيذ أمر في Termux ويرجع الإخراج (يطلب موافقة المستخدم)
- termux_save {"path":"proj/a.py","content":"..."} : حفظ ملف داخل Termux تحت ~/dirgham
- web_fetch {"url":"https://..."} : قراءة نص صفحة
- preview {"path":"motion/a.html"} : عرض صفحة HTML للمستخدم
- open_app {"name":"capcut"} : فتح تطبيق
- list_skills {} ، use_skill {"name":"motion-graphics"} ، install_skill {"name":"x","content":"..."}
المهارات المثبّتة:
$skills"""
    }

    private fun buildPrompt(noThinkSuffix: Boolean): String {
        // نقتطع من الأقدم حتى تصغر الحصيلة، ونضمن أن تبدأ بدور user
        var start = 0
        var total = history.sumOf { it.second.length }
        while (total > HISTORY_CHARS && start < history.size - 1) {
            total -= history[start].second.length
            start++
        }
        while (start < history.size - 1 && history[start].first != "user") start++
        val msgs = ArrayList<Pair<String, String>>()
        msgs.add("system" to systemPrompt())
        for (i in start until history.size) {
            val (r, c) = history[i]
            val isLastUser = (i == history.size - 1) && r == "user"
            msgs.add(r to (if (isLastUser && noThinkSuffix && modelName.contains("qwen3", ignoreCase = true)) "$c /no_think" else c))
        }
        return llm.applyTemplate(msgs) ?: chatml(msgs)
    }

    private fun chatml(msgs: List<Pair<String, String>>): String {
        val sb = StringBuilder()
        for ((r, c) in msgs) sb.append("<|im_start|>").append(r).append('\n').append(c).append("<|im_end|>\n")
        sb.append("<|im_start|>assistant\n")
        return sb.toString()
    }

    private fun parseCall(text: String): Pair<String, JSONObject>? {
        val m = CALL_RE.find(text) ?: return null
        val body = m.groupValues[1].trim()
        val s = body.indexOf('{')
        val e = body.lastIndexOf('}')
        if (s < 0 || e <= s) return null
        return try {
            val j = JSONObject(body.substring(s, e + 1))
            val name = j.optString("name")
            if (name.isEmpty()) null
            else Pair(name, j.optJSONObject("arguments") ?: j.optJSONObject("parameters") ?: JSONObject())
        } catch (_: Exception) { null }
    }

    /** يولّد ردًّا واحدًا ببث الرموز للواجهة. يعيد النص المرئي (بلا تفكير) كاملًا. */
    private suspend fun generateOnce(prompt: String, temp: Float): String {
        val splitter = ThinkSplitter()
        val gate = ToolGate()
        val raw = StringBuilder()
        val co = currentCoroutineContext()

        fun handle(segs: List<Seg>) {
            for (seg in segs) {
                if (seg.think) {
                    Bus.emit("think", seg.text)
                } else {
                    raw.append(seg.text)
                    val vis = gate.feed(seg.text)
                    if (vis.isNotEmpty()) Bus.emit("token", vis)
                }
            }
        }

        llm.generate(prompt, MAX_NEW_TOKENS, temp) { piece ->
            handle(splitter.feed(piece))
            co.isActive
        }
        handle(splitter.flush())
        val tail = gate.flush()
        if (tail.isNotEmpty()) Bus.emit("token", tail)
        return raw.toString().trim()
    }

    suspend fun run(userText: String, thinking: Boolean) {
        val model = LlamaEngine.activeModel(ctx)
            ?: throw IllegalStateException("لا يوجد نموذج. افتح «الأدوات» ونزّل نموذجًا أو أضفه برابط.")
        Bus.emit("status", "تحميل ${model.name}…")
        llm.ensureLoaded(model)
        modelName = model.name

        history.add("user" to userText)
        var steps = 0
        var badFormat = 0
        while (steps < MAX_STEPS && currentCoroutineContext().isActive) {
            steps++
            val answer = generateOnce(buildPrompt(!thinking), 0.6f)
            history.add("assistant" to answer)
            if (!answer.contains("<tool_call>")) break

            val call = parseCall(answer)
            if (call == null) {
                badFormat++
                if (badFormat > 1) { Bus.emit("status", "تعذّر فهم استدعاء الأداة"); break }
                history.add("user" to "<tool_response>صيغة الاستدعاء غير صحيحة. الصيغة: <tool_call>{\"name\":\"...\",\"arguments\":{...}}</tool_call></tool_response>")
                continue
            }
            val (name, args) = call
            Bus.emit("tool", "$name " + Tools.clip(args.toString(), 140))
            val result = tools.execute(name, args)
            history.add("user" to "<tool_response>\n${Tools.clip(result)}\n</tool_response>")
        }
        if (steps >= MAX_STEPS) Bus.emit("status", "بلغتُ حدّ الخطوات ($MAX_STEPS). اكتب «تابع» للمواصلة.")

        // لا نُبقي سجلًّا طويلًا جدًا
        while (history.size > 24) history.removeAt(0)
    }

    /** فحص ذاتي: معلومات النموذج والنظام + توليد قصير بلا عشوائية. */
    suspend fun diagnose() {
        val model = LlamaEngine.activeModel(ctx)
            ?: throw IllegalStateException("لا يوجد نموذج للفحص.")
        Bus.emit("status", "تحميل ${model.name}…")
        llm.ensureLoaded(model)
        Bus.emit("tool", "فحص: ${model.name} (${model.length() / 1048576} MB)")
        Bus.emit("token", llm.info() + "\n\n")
        val msgs = listOf("user" to "قل: مرحبا بك. ثم اكتب 2+2=")
        val prompt = llm.applyTemplate(msgs) ?: chatml(msgs)
        Bus.emit("token", "اختبار (بلا عشوائية):\n")
        llm.generate(prompt, 40, 0f) { Bus.emit("token", it); true }
    }
}
