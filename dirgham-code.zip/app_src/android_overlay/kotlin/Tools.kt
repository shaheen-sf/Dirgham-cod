package com.dirgham.code

import android.content.Context
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** أدوات الوكيل. كل أداة تعيد نصًا قصيرًا يُعاد للنموذج كنتيجة. */
class Tools(private val ctx: Context) {

    private val root: File = File(ctx.filesDir, "workspace").also { it.mkdirs() }

    companion object {
        const val MAX_OUT = 2500

        val APPS = mapOf(
            "termux" to "com.termux",
            "capcut" to "com.lemon.lvoverseas",
            "كاب كات" to "com.lemon.lvoverseas",
            "elevenlabs" to "io.elevenlabs.app",
            "ايليفن لابز" to "io.elevenlabs.app"
        )

        fun clip(s: String, n: Int = MAX_OUT): String =
            if (s.length <= n) s else s.substring(0, n) + "\n…(قُصّ الإخراج، الطول الكلي ${s.length})"
    }

    private fun resolve(rel: String): File? {
        val clean = rel.trim().trimStart('/')
        val f = File(root, clean).canonicalFile
        val base = root.canonicalPath
        return if (f.path == base || f.path.startsWith(base + File.separator)) f else null
    }

    private fun str(a: JSONObject, k: String): String = a.optString(k, "")

    suspend fun execute(name: String, a: JSONObject): String {
        return try {
            when (name) {
                "list_files" -> listFiles(str(a, "path"))
                "read_file" -> readFile(str(a, "path"))
                "write_file" -> writeFile(str(a, "path"), str(a, "content"))
                "delete_file" -> deleteFile(str(a, "path"))
                "shell" -> shell(str(a, "cmd"))
                "termux_save" -> termuxSave(str(a, "path"), str(a, "content"))
                "web_fetch" -> webFetch(str(a, "url"))
                "list_skills" -> listSkills()
                "use_skill" -> useSkill(str(a, "name"))
                "install_skill" -> installSkill(str(a, "name"), str(a, "url"), str(a, "content"))
                "preview" -> preview(str(a, "path"))
                "open_app" -> openApp(str(a, "name"))
                else -> "أداة غير معروفة: $name. الأدوات: list_files, read_file, write_file, delete_file, shell, termux_save, web_fetch, list_skills, use_skill, install_skill, preview, open_app"
            }
        } catch (e: SecurityException) {
            "خطأ صلاحيات: امنح التطبيق إذن تشغيل الأوامر في Termux (شاشة الأدوات)."
        } catch (e: Exception) {
            "خطأ: ${e.message}"
        }
    }

    private fun listFiles(path: String): String {
        val d = resolve(path.ifBlank { "." }) ?: return "مسار غير مسموح"
        if (!d.exists()) return "غير موجود: $path"
        if (d.isFile) return "ملف: ${d.name} (${d.length()} بايت)"
        val items = (d.listFiles() ?: emptyArray()).sortedBy { it.name }
            .joinToString("\n") { (if (it.isDirectory) "[مجلد] " else "") + it.name + (if (it.isFile) " (${it.length()} بايت)" else "") }
        return if (items.isEmpty()) "(فارغ)" else clip(items)
    }

    private fun readFile(path: String): String {
        val f = resolve(path) ?: return "مسار غير مسموح"
        if (!f.isFile) return "الملف غير موجود: $path"
        return clip(f.readText())
    }

    private fun writeFile(path: String, content: String): String {
        if (path.isBlank()) return "حدّد path"
        val f = resolve(path) ?: return "مسار غير مسموح"
        if (content.length > 200_000) return "المحتوى أكبر من 200 ألف حرف"
        f.parentFile?.mkdirs()
        f.writeText(content)
        Bus.emit("tool", "كُتب: $path (${content.length} حرف)")
        return "تم حفظ $path (${content.length} حرف)"
    }

    private fun deleteFile(path: String): String {
        val f = resolve(path) ?: return "مسار غير مسموح"
        if (f == root) return "لا يمكن حذف المجلد الجذر"
        return if (f.exists() && f.deleteRecursively()) "حُذف $path" else "تعذّر الحذف أو غير موجود"
    }

    private suspend fun shell(cmd: String): String {
        if (cmd.isBlank()) return "حدّد cmd"
        if (!TermuxBridge.isInstalled(ctx)) return "Termux غير مثبّت. ثبّته من F-Droid."
        if (!TermuxBridge.hasPermission(ctx)) return "لم يُمنح إذن Termux. افتح شاشة الأدوات واضغط منح الإذن."
        val ok = Confirm.ask("تنفيذ أمر في Termux", cmd)
        if (!ok) return "رفض المستخدم تنفيذ الأمر."
        Bus.emit("tool", "$ " + clip(cmd, 160))
        return clip(TermuxBridge.runCapture(ctx, cmd))
    }

    private suspend fun termuxSave(path: String, content: String): String {
        if (path.isBlank() || path.contains("..") || path.startsWith("/")) return "مسار غير صالح، استعمل مسارًا نسبيًا بلا .."
        if (!Regex("^[A-Za-z0-9._/-]{1,120}$").matches(path)) return "الأحرف المسموحة في المسار: حروف لاتينية وأرقام ._/-"
        if (content.length > 100_000) return "المحتوى كبير جدًا"
        if (!TermuxBridge.isInstalled(ctx)) return "Termux غير مثبّت."
        if (!TermuxBridge.hasPermission(ctx)) return "لم يُمنح إذن Termux."
        val ok = Confirm.ask("حفظ ملف في Termux", "~/dirgham/$path (${content.length} حرف)")
        if (!ok) return "رفض المستخدم."
        val b64 = Base64.encodeToString(content.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        val full = "dirgham/$path"
        val script = "mkdir -p \"\$(dirname '$full')\" && echo '$b64' | base64 -d > '$full' && echo saved:$full"
        Bus.emit("tool", "termux_save → ~/$full")
        return clip(TermuxBridge.runCapture(ctx, script, 60_000L))
    }

    private suspend fun webFetch(url: String): String = withContext(Dispatchers.IO) {
        if (!url.startsWith("https://")) return@withContext "يُسمح بروابط https فقط"
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.setRequestProperty("User-Agent", "DirghamCode/0.3")
        val code = c.responseCode
        if (code != 200) return@withContext "رد الخادم $code"
        val bytes = c.inputStream.use { it.readNBytesCompat(60_000) }
        var t = String(bytes, Charsets.UTF_8)
        if (t.contains("<html", ignoreCase = true)) {
            t = t.replace(Regex("(?is)<(script|style)[^>]*>.*?</\\1>"), " ")
                .replace(Regex("<[^>]+>"), " ")
                .replace(Regex("\\s+"), " ")
        }
        Bus.emit("tool", "web_fetch → $url")
        clip(t.trim())
    }

    private fun java.io.InputStream.readNBytesCompat(max: Int): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        val buf = ByteArray(8192)
        while (out.size() < max) {
            val n = read(buf)
            if (n < 0) break
            out.write(buf, 0, n)
        }
        return out.toByteArray()
    }

    private fun listSkills(): String {
        val names = Skills.names(ctx)
        if (names.isEmpty()) return "(لا توجد مهارات)"
        return names.joinToString("\n") { n -> "- $n: " + Skills.description(Skills.read(ctx, n) ?: "") }
    }

    private fun useSkill(name: String): String {
        val t = Skills.read(ctx, name.trim()) ?: return "لا توجد مهارة بهذا الاسم. استعمل list_skills."
        Bus.emit("tool", "مهارة: $name")
        return clip(t, 5000)
    }

    private suspend fun installSkill(name: String, url: String, content: String): String {
        if (!Regex("^[a-z0-9_-]{1,40}$").matches(name)) return "اسم المهارة: حروف لاتينية صغيرة وأرقام و - و _ فقط"
        var text = content
        if (text.isBlank() && url.isNotBlank()) {
            if (!url.startsWith("https://")) return "يُسمح بروابط https فقط"
            val ok = Confirm.ask("تثبيت مهارة من رابط", url)
            if (!ok) return "رفض المستخدم."
            text = withContext(Dispatchers.IO) {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 15000
                c.readTimeout = 20000
                c.setRequestProperty("User-Agent", "DirghamCode/0.3")
                if (c.responseCode != 200) "" else String(c.inputStream.use { it.readNBytesCompat(100_000) }, Charsets.UTF_8)
            }
            if (text.isBlank()) return "تعذّر تنزيل المهارة من الرابط"
        } else if (text.isNotBlank()) {
            val ok = Confirm.ask("تثبيت مهارة جديدة: $name", clip(text, 400))
            if (!ok) return "رفض المستخدم."
        } else {
            return "حدّد content أو url"
        }
        Skills.save(ctx, name, text)
        Bus.emit("tool", "ثُبّتت المهارة: $name")
        return "ثُبّتت المهارة $name"
    }

    private fun preview(path: String): String {
        val f = resolve(path) ?: return "مسار غير مسموح"
        if (!f.isFile) return "الملف غير موجود: $path"
        Bus.emit("preview", path.trim().trimStart('/'))
        return "فُتحت المعاينة للمستخدم."
    }

    private fun openApp(name: String): String {
        val key = name.trim().lowercase()
        val pkg = APPS.entries.firstOrNull { key.contains(it.key) }?.value ?: key
        Bus.emit("openapp", pkg)
        return "طُلب فتح التطبيق $pkg"
    }
}
