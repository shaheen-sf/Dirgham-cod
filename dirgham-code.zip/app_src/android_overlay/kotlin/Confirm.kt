package com.dirgham.code

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

/** طلب موافقة من المستخدم قبل أي عمل حساس. تُعرض نافذة في الواجهة ويُنتظر الرد. */
object Confirm {
    private val pending = ConcurrentHashMap<String, CompletableDeferred<Boolean>>()

    suspend fun ask(title: String, detail: String): Boolean {
        val id = System.nanoTime().toString()
        val d = CompletableDeferred<Boolean>()
        pending[id] = d
        Bus.emit("confirm", JSONObject().put("id", id).put("title", title).put("detail", detail).toString())
        val r = withTimeoutOrNull(180_000L) { d.await() } ?: false
        pending.remove(id)
        return r
    }

    fun answer(id: String, ok: Boolean) {
        pending[id]?.complete(ok)
    }
}
