package com.dirgham.code

class Seg(val think: Boolean, val text: String)

/** يفصل كتل <think>…</think> عن النص العادي أثناء البث، حتى لو تقطّعت الوسوم بين الرموز. */
class ThinkSplitter {
    private val open = "<think>"
    private val close = "</think>"
    private var inThink = false
    private val buf = StringBuilder()

    fun feed(s: String): List<Seg> {
        buf.append(s)
        val out = ArrayList<Seg>()
        while (true) {
            val tag = if (inThink) close else open
            val i = buf.indexOf(tag)
            if (i >= 0) {
                if (i > 0) out.add(Seg(inThink, buf.substring(0, i)))
                buf.delete(0, i + tag.length)
                inThink = !inThink
                continue
            }
            val keep = tag.length - 1
            if (buf.length > keep) {
                out.add(Seg(inThink, buf.substring(0, buf.length - keep)))
                buf.delete(0, buf.length - keep)
            }
            break
        }
        return out
    }

    fun flush(): List<Seg> {
        val o = ArrayList<Seg>()
        if (buf.isNotEmpty()) o.add(Seg(inThink, buf.toString()))
        buf.setLength(0)
        return o
    }
}

/** يمنع عرض نص استدعاء الأداة للمستخدم: يمرّر النص حتى يظهر <tool_call> ثم يتوقف. */
class ToolGate {
    private val tag = "<tool_call>"
    private val buf = StringBuilder()
    private var stopped = false

    fun feed(s: String): String {
        if (stopped) return ""
        buf.append(s)
        val i = buf.indexOf(tag)
        if (i >= 0) {
            val out = buf.substring(0, i)
            buf.setLength(0)
            stopped = true
            return out
        }
        val keep = tag.length - 1
        if (buf.length <= keep) return ""
        val out = buf.substring(0, buf.length - keep)
        buf.delete(0, buf.length - keep)
        return out
    }

    fun flush(): String {
        if (stopped) return ""
        val o = buf.toString()
        buf.setLength(0)
        return o
    }
}
