package com.dirgham.code

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull

/**
 * تكامل Termux عبر RUN_COMMAND مع التقاط الإخراج (stdout/stderr/exitCode).
 * الشروط: Termux من F-Droid أو GitHub، و allow-external-apps=true في ~/.termux/termux.properties،
 * ومنح تطبيقنا إذن «Run commands in Termux environment».
 */
object TermuxBridge {
    private const val PKG = "com.termux"
    private const val SVC = "com.termux.app.RunCommandService"
    private const val HOME = "/data/data/com.termux/files/home"
    private const val BASH = "/data/data/com.termux/files/usr/bin/bash"

    const val PERMISSION = "com.termux.permission.RUN_COMMAND"

    fun isInstalled(ctx: Context): Boolean = try {
        ctx.packageManager.getPackageInfo(PKG, 0); true
    } catch (_: Exception) { false }

    fun hasPermission(ctx: Context): Boolean =
        ctx.checkSelfPermission(PERMISSION) == PackageManager.PERMISSION_GRANTED

    private fun baseIntent(script: String, background: Boolean): Intent = Intent().apply {
        component = ComponentName(PKG, SVC)
        action = "com.termux.RUN_COMMAND"
        putExtra("com.termux.RUN_COMMAND_PATH", BASH)
        putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-lc", script))
        putExtra("com.termux.RUN_COMMAND_WORKDIR", HOME)
        putExtra("com.termux.RUN_COMMAND_BACKGROUND", background)
    }

    private fun start(ctx: Context, i: Intent) {
        if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
    }

    /** يشغّل الأمر ويعيد الإخراج كنص. يرمي SecurityException إن لم يُمنح الإذن. */
    suspend fun runCapture(ctx: Context, script: String, timeoutMs: Long = 180_000L): String {
        val action = "com.dirgham.code.TERMUX_RESULT." + System.nanoTime()
        val d = CompletableDeferred<String>()
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val b = i.getBundleExtra("result")
                if (b == null) {
                    d.complete("(لم يرجع Termux أي نتيجة)")
                    return
                }
                val out = b.getString("stdout").orEmpty()
                val err = b.getString("stderr").orEmpty()
                val code = b.getInt("exitCode", -1)
                val errmsg = b.getString("errmsg").orEmpty()
                val sb = StringBuilder()
                sb.append("exit=").append(code).append('\n')
                if (out.isNotEmpty()) sb.append(out)
                if (err.isNotEmpty()) sb.append("\n[stderr]\n").append(err)
                if (errmsg.isNotEmpty()) sb.append("\n[error] ").append(errmsg)
                d.complete(sb.toString())
            }
        }
        ContextCompat.registerReceiver(ctx, receiver, IntentFilter(action), ContextCompat.RECEIVER_NOT_EXPORTED)
        try {
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            val pi = PendingIntent.getBroadcast(
                ctx, (System.nanoTime() % 100000L).toInt(),
                Intent(action).setPackage(ctx.packageName), flags
            )
            val i = baseIntent(script, true)
            i.putExtra("com.termux.RUN_COMMAND_PENDING_INTENT", pi)
            start(ctx, i)
            return withTimeoutOrNull(timeoutMs) { d.await() }
                ?: "(انتهت المهلة بلا رد. غالبًا allow-external-apps غير مفعّل في Termux)"
        } finally {
            try { ctx.unregisterReceiver(receiver) } catch (_: Exception) {}
        }
    }

    fun openApp(ctx: Context, pkg: String): Boolean {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return true
    }
}
