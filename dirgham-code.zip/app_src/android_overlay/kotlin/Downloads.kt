package com.dirgham.code

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

/**
 * تنزيل النماذج داخل الخدمة الأمامية (يستمر والشاشة مطفأة)، مع استئناف تلقائي وإعادة محاولة.
 */
object Downloads {
    class State(val name: String) {
        @Volatile var got: Long = 0
        @Volatile var total: Long = -1
        @Volatile var status: String = "running" // running | done | error | paused
        @Volatile var msg: String = ""
    }

    val states = ConcurrentHashMap<String, State>()
    private val jobs = ConcurrentHashMap<String, Job>()

    /** تستدعيها الخدمة لتحديث نص الإشعار. */
    @Volatile var notify: ((String) -> Unit)? = null

    fun json(st: State): String = JSONObject()
        .put("name", st.name).put("got", st.got).put("total", st.total)
        .put("status", st.status).put("msg", st.msg).toString()

    fun snapshot(): String {
        val a = JSONArray()
        for (s in states.values) a.put(JSONObject(json(s)))
        return a.toString()
    }

    fun start(ctx: Context, scope: CoroutineScope, url: String, rawName: String) {
        val name = rawName.replace(Regex("[^A-Za-z0-9._-]"), "_")
        if (!name.endsWith(".gguf", ignoreCase = true)) {
            Bus.emit("error", "اسم الملف يجب أن ينتهي بـ .gguf")
            return
        }
        if (!url.startsWith("https://")) {
            Bus.emit("error", "الرابط يجب أن يبدأ بـ https://")
            return
        }
        jobs[name]?.cancel()
        val st = State(name)
        states[name] = st
        jobs[name] = scope.launch(Dispatchers.IO) {
            try {
                doDownload(ctx.applicationContext, url, name, st)
            } catch (e: CancellationException) {
                st.status = "paused"
                Bus.emit("dl", json(st))
            }
        }
    }

    fun cancel(name: String) {
        jobs[name]?.cancel()
        states[name]?.let { it.status = "paused"; Bus.emit("dl", json(it)) }
    }

    fun remove(ctx: Context, name: String) {
        cancel(name)
        states.remove(name)
        File(LlamaEngine.modelsDir(ctx), "$name.part").delete()
    }

    private fun connect(url0: String, from: Long): HttpURLConnection {
        var url = url0
        repeat(6) {
            val c = URL(url).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 20000
            c.readTimeout = 30000
            c.setRequestProperty("User-Agent", "DirghamCode/0.3")
            if (from > 0) c.setRequestProperty("Range", "bytes=$from-")
            val code = c.responseCode
            if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                val loc = c.getHeaderField("Location") ?: throw IOException("تحويل بلا Location")
                url = URL(URL(url), loc).toString()
                c.disconnect()
            } else {
                return c
            }
        }
        throw IOException("تحويلات كثيرة")
    }

    private suspend fun doDownload(ctx: Context, url: String, name: String, st: State) = withContext(Dispatchers.IO) {
        val dir = LlamaEngine.modelsDir(ctx)
        val part = File(dir, "$name.part")
        val dest = File(dir, name)
        var attempt = 0
        while (true) {
            ensureActive()
            try {
                val have = if (part.exists()) part.length() else 0L
                val conn = connect(url, have)
                val code = conn.responseCode
                if (code == 416 && have > 0) {
                    // الملف مكتمل مسبقًا
                    part.renameTo(dest)
                    st.status = "done"
                    Bus.emit("dl", json(st))
                    return@withContext
                }
                if (code != 200 && code != 206) throw IOException("رد الخادم $code")
                val resumed = code == 206 && have > 0
                val start = if (resumed) have else 0L
                val len = conn.contentLengthLong
                st.total = if (len > 0) len + start else -1
                st.got = start
                st.status = "running"
                st.msg = ""
                var lastTick = 0L
                conn.inputStream.use { ins ->
                    FileOutputStream(part, resumed).use { out ->
                        val buf = ByteArray(256 * 1024)
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            st.got += n
                            val now = System.currentTimeMillis()
                            if (now - lastTick > 600) {
                                lastTick = now
                                Bus.emit("dl", json(st))
                                val pct = if (st.total > 0) (st.got * 100 / st.total).toInt() else 0
                                notify?.invoke("تنزيل ${st.name}: $pct%")
                            }
                            ensureActive()
                        }
                    }
                }
                if (st.total > 0 && st.got < st.total) throw IOException("انقطع الاتصال قبل اكتمال الملف")
                if (!LlamaEngine.isGguf(part)) {
                    part.delete()
                    throw IOException("الملف المنزَّل ليس GGUF صالحًا")
                }
                if (dest.exists()) dest.delete()
                part.renameTo(dest)
                st.status = "done"
                Bus.emit("dl", json(st))
                notify?.invoke("اكتمل تنزيل ${st.name}")
                return@withContext
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                attempt++
                if (attempt > 40) {
                    st.status = "error"
                    st.msg = e.message ?: "فشل التنزيل"
                    Bus.emit("dl", json(st))
                    return@withContext
                }
                st.msg = "إعادة المحاولة $attempt: ${e.message}"
                Bus.emit("dl", json(st))
                delay(minOf(2000L * attempt, 15000L))
            }
        }
    }
}
