package com.dirgham.code

import android.content.Context
import androidx.annotation.Keep
import java.io.File

@Keep
fun interface TokenCallback {
    fun onToken(piece: String): Boolean // false = إيقاف التوليد
}

/**
 * غلاف llama.cpp يعمل مع أي نموذج GGUF ويستخدم قالب المحادثة المضمّن في النموذج.
 * نموذج واحد فقط في الذاكرة في كل مرة. الملفات في التخزين الداخلي للتطبيق (أسرع وأسلم من mmap على التخزين المشترك).
 */
@Keep
class LlamaEngine private constructor(private val ctx: Context) {

    companion object {
        val nativeOk: Boolean = try {
            System.loadLibrary("llama_jni"); true
        } catch (_: UnsatisfiedLinkError) { false }

        @Volatile
        private var inst: LlamaEngine? = null

        fun shared(c: Context): LlamaEngine =
            inst ?: synchronized(this) { inst ?: LlamaEngine(c.applicationContext).also { inst = it } }

        fun modelsDir(c: Context): File = File(c.filesDir, "models").also { it.mkdirs() }

        fun listModels(c: Context): List<File> =
            (modelsDir(c).listFiles() ?: emptyArray())
                .filter { it.isFile && it.name.endsWith(".gguf", ignoreCase = true) }
                .sortedBy { it.name.lowercase() }

        fun activeModel(c: Context): File? {
            val want = Settings.activeModel(c)
            val all = listModels(c)
            return all.firstOrNull { it.name == want } ?: all.firstOrNull()
        }

        /** نسخ ما نُزِّل بالإصدار السابق من المجلد الخارجي إلى الداخلي مرة واحدة. */
        fun migrateOld(c: Context) {
            val old = File(c.getExternalFilesDir(null), "models")
            if (!old.isDirectory) return
            val dst = modelsDir(c)
            old.listFiles()?.forEach { f ->
                if (f.isFile && f.name.endsWith(".gguf", ignoreCase = true)) {
                    val t = File(dst, f.name)
                    if (!t.exists()) {
                        try { f.copyTo(t); f.delete() } catch (_: Exception) { t.delete() }
                    }
                }
            }
        }

        fun isGguf(f: File): Boolean = try {
            f.inputStream().use { s ->
                val b = ByteArray(4)
                s.read(b) == 4 && String(b, Charsets.ISO_8859_1) == "GGUF"
            }
        } catch (_: Exception) { false }
    }

    private var loadedPath: String? = null
    private var handle: Long = 0L

    private external fun nativeLoad(path: String, nCtx: Int, nThreads: Int): Long
    private external fun nativeTemplate(h: Long, roles: Array<String>, contents: Array<String>, addAss: Boolean): String?
    private external fun nativeInfo(h: Long): String
    private external fun nativeGenerate(h: Long, prompt: String, maxTokens: Int, temp: Float, cb: TokenCallback): Int
    private external fun nativeFree(h: Long)

    @Synchronized
    fun ensureLoaded(file: File, nCtx: Int = 4096) {
        check(nativeOk) { "المكتبة الأصلية llama_jni غير موجودة في هذا الـ APK" }
        require(file.exists()) { "النموذج غير موجود: ${file.name}" }
        require(isGguf(file)) { "الملف ليس GGUF صالحًا (ربما تنزيل ناقص): ${file.name}" }
        if (loadedPath == file.absolutePath && handle != 0L) return
        unload()
        val threads = (Runtime.getRuntime().availableProcessors() - 2).coerceIn(2, 6)
        handle = nativeLoad(file.absolutePath, nCtx, threads)
        check(handle != 0L) { "فشل تحميل النموذج (الذاكرة غير كافية أو بنية غير مدعومة)" }
        loadedPath = file.absolutePath
    }

    /** يطبّق قالب المحادثة المضمّن في النموذج. null إن لم يوجد قالب. */
    @Synchronized
    fun applyTemplate(messages: List<Pair<String, String>>): String? {
        if (handle == 0L) return null
        val roles = Array(messages.size) { messages[it].first }
        val contents = Array(messages.size) { messages[it].second }
        return nativeTemplate(handle, roles, contents, true)
    }

    @Synchronized
    fun info(): String = nativeInfo(handle)

    fun isLoaded(): Boolean = handle != 0L

    fun generate(prompt: String, maxTokens: Int, temp: Float, onToken: (String) -> Boolean): Int {
        check(handle != 0L) { "لا يوجد نموذج محمّل" }
        return nativeGenerate(handle, prompt, maxTokens, temp, TokenCallback { onToken(it) })
    }

    @Synchronized
    fun unload() {
        if (handle != 0L) nativeFree(handle)
        handle = 0L
        loadedPath = null
    }
}
