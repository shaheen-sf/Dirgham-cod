import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../services/agent_bridge.dart';
import '../services/model_store.dart';
import '../theme.dart';
import '../widgets/glass.dart';
import '../widgets/pattern_background.dart';

class ModelsScreen extends StatefulWidget {
  final AgentBridge bridge;
  const ModelsScreen({super.key, required this.bridge});
  @override
  State<ModelsScreen> createState() => _ModelsScreenState();
}

class _ModelsScreenState extends State<ModelsScreen> {
  ModelStore? _store;
  String _dir = '';
  bool _native = true, _termux = false, _termuxPerm = false;
  final Map<String, double?> _progress = {};
  final Map<String, String> _errors = {};

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final path = await widget.bridge.modelsDir();
    final n = await widget.bridge.nativeOk();
    final t = await widget.bridge.termuxInstalled();
    final p = await widget.bridge.termuxPermissionGranted();
    if (!mounted) return;
    setState(() {
      _dir = path;
      _store = ModelStore(Directory(path));
      _native = n;
      _termux = t;
      _termuxPerm = p;
    });
  }

  Future<void> _download(ModelInfo m) async {
    final s = _store;
    if (s == null) return;
    setState(() {
      _progress[m.file] = 0;
      _errors.remove(m.file);
    });
    try {
      await s.download(m, (p, bytes) {
        if (mounted) setState(() => _progress[m.file] = p ?? 0);
      });
    } catch (e) {
      _errors[m.file] = '$e';
    }
    if (mounted) setState(() => _progress.remove(m.file));
  }

  Future<void> _import(ModelInfo m) async {
    final s = _store;
    if (s == null) return;
    final r = await FilePicker.platform.pickFiles(type: FileType.any);
    final path = r?.files.single.path;
    if (path == null) return;
    setState(() => _progress[m.file] = null);
    try {
      await s.importFrom(path, m.file);
    } catch (e) {
      _errors[m.file] = '$e';
    }
    if (mounted) setState(() => _progress.remove(m.file));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PatternBackground(
        child: SafeArea(
          child: ListView(padding: const EdgeInsets.all(16), children: [
            Row(children: [
              GlassButton(icon: Icons.arrow_forward_rounded, onTap: () => Navigator.pop(context)),
              const SizedBox(width: 12),
              const Text('الأدوات والنماذج',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: DG.text)),
            ]),
            const SizedBox(height: 14),
            if (!_native)
              _note(DG.gold, 'المكتبة الأصلية llama_jni غير موجودة في هذا الـ APK. أعد البناء عبر سير عمل GitHub.'),
            for (final m in kModels) _modelCard(m),
            const SizedBox(height: 6),
            GlassPanel(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Termux', style: TextStyle(color: DG.fire, fontWeight: FontWeight.w800, fontSize: 16)),
                const SizedBox(height: 8),
                _row('التثبيت', _termux),
                _row('إذن تشغيل الأوامر', _termuxPerm),
                const SizedBox(height: 8),
                const Text(
                  'في Termux نفّذ مرة واحدة:\nmkdir -p ~/.termux && echo "allow-external-apps=true" >> ~/.termux/termux.properties\nثم أغلق Termux وافتحه.',
                  textDirection: TextDirection.ltr,
                  style: TextStyle(color: DG.gold, fontFamily: 'monospace', fontSize: 11.5, height: 1.5),
                ),
                const SizedBox(height: 10),
                Row(children: [
                  GlassButton(
                    icon: Icons.verified_user_outlined,
                    label: 'منح الإذن',
                    color: DG.ok,
                    onTap: () async {
                      await widget.bridge.requestTermuxPermission();
                      await Future.delayed(const Duration(seconds: 2));
                      _init();
                    },
                  ),
                  const SizedBox(width: 8),
                  GlassButton(icon: Icons.refresh_rounded, label: 'تحديث', onTap: _init),
                ]),
              ]),
            ),
            const SizedBox(height: 12),
            GlassPanel(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('مجلد النماذج', style: TextStyle(color: DG.text, fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                SelectableText(_dir,
                    textDirection: TextDirection.ltr,
                    style: const TextStyle(color: DG.textDim, fontSize: 11.5, fontFamily: 'monospace')),
                const SizedBox(height: 6),
                const Text(
                  'لإضافة نموذج من جهازك استخدم زر «استيراد» (ينسخه إلى هذا المجلد). في أندرويد 11+ لا يظهر هذا المجلد في تطبيق الملفات.',
                  style: TextStyle(color: DG.textDim, fontSize: 12, height: 1.6),
                ),
              ]),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _note(Color c, String t) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: GlassPanel(glow: c, child: Text(t, style: TextStyle(color: c, fontSize: 13, height: 1.6))),
      );

  Widget _row(String k, bool ok) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(children: [
          Icon(ok ? Icons.check_circle_rounded : Icons.cancel_rounded, size: 18, color: ok ? DG.ok : DG.textDim),
          const SizedBox(width: 8),
          Text(k, style: const TextStyle(color: DG.text, fontSize: 13)),
        ]),
      );

  Widget _modelCard(ModelInfo m) {
    final s = _store;
    final ready = s != null && s.exists(m);
    final busy = _progress.containsKey(m.file);
    final p = _progress[m.file];
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: GlassPanel(
        glow: ready ? DG.ok : null,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(
              child: Text(m.title, style: const TextStyle(color: DG.text, fontWeight: FontWeight.w800, fontSize: 16)),
            ),
            Text(ready ? 'جاهز' : 'غير موجود',
                style: TextStyle(color: ready ? DG.ok : DG.textDim, fontSize: 12.5)),
          ]),
          const SizedBox(height: 4),
          Text('${m.role} · ${m.sizeLabel}', style: const TextStyle(color: DG.textDim, fontSize: 12.5)),
          const SizedBox(height: 2),
          Text(m.file,
              textDirection: TextDirection.ltr,
              style: const TextStyle(color: DG.gold, fontSize: 11, fontFamily: 'monospace')),
          if (busy) ...[
            const SizedBox(height: 10),
            LinearProgressIndicator(value: p == 0 ? null : p, color: DG.fire, backgroundColor: Colors.white12),
          ],
          if (_errors[m.file] != null) ...[
            const SizedBox(height: 8),
            Text(_errors[m.file]!, style: const TextStyle(color: DG.gold, fontSize: 12)),
          ],
          const SizedBox(height: 10),
          Wrap(spacing: 8, runSpacing: 8, children: [
            if (!busy && !ready)
              GlassButton(icon: Icons.download_rounded, label: 'تنزيل', color: DG.fire, onTap: () => _download(m)),
            if (busy) GlassButton(icon: Icons.stop_rounded, label: 'إيقاف', color: DG.gold, onTap: () => s?.cancel()),
            if (!busy) GlassButton(icon: Icons.folder_open_rounded, label: 'استيراد', onTap: () => _import(m)),
            if (!busy && ready)
              GlassButton(
                icon: Icons.delete_outline_rounded,
                label: 'حذف',
                onTap: () async {
                  await s!.delete(m);
                  setState(() {});
                },
              ),
          ]),
        ]),
      ),
    );
  }
}
