import 'dart:io';

class ModelInfo {
  final String file;
  final String title;
  final String role;
  final String sizeLabel;
  final String url;
  const ModelInfo(this.file, this.title, this.role, this.sizeLabel, this.url);
}

const kModels = <ModelInfo>[
  ModelInfo(
    'Qwen3-1.7B-Q4_K_M.gguf',
    'Qwen3 1.7B',
    'الحوار العام (أساسي)',
    '≈ 1.1 جيجا',
    'https://huggingface.co/unsloth/Qwen3-1.7B-GGUF/resolve/main/Qwen3-1.7B-Q4_K_M.gguf',
  ),
  ModelInfo(
    'qwen2.5-coder-1.5b-instruct-q4_k_m.gguf',
    'Qwen2.5 Coder 1.5B',
    'كتابة الأكواد',
    '≈ 1.1 جيجا',
    'https://huggingface.co/Qwen/Qwen2.5-Coder-1.5B-Instruct-GGUF/resolve/main/qwen2.5-coder-1.5b-instruct-q4_k_m.gguf',
  ),
];

/// تنزيل مع استئناف، يحفظ في .part ثم يعيد التسمية عند الاكتمال.
class ModelStore {
  final Directory dir;
  bool _cancel = false;
  ModelStore(this.dir);

  File file(ModelInfo m) => File('${dir.path}/${m.file}');
  bool exists(ModelInfo m) => file(m).existsSync() && file(m).lengthSync() > 1000000;
  void cancel() => _cancel = true;

  Future<void> download(ModelInfo m, void Function(double? p, int bytes) onProgress) async {
    _cancel = false;
    await dir.create(recursive: true);
    final part = File('${dir.path}/${m.file}.part');
    int start = await part.exists() ? await part.length() : 0;

    final client = HttpClient()..connectionTimeout = const Duration(seconds: 20);
    try {
      final req = await client.getUrl(Uri.parse(m.url));
      if (start > 0) req.headers.set(HttpHeaders.rangeHeader, 'bytes=$start-');
      final res = await req.close();
      if (res.statusCode != 200 && res.statusCode != 206) {
        throw HttpException('رد الخادم ${res.statusCode}');
      }
      final resumed = res.statusCode == 206;
      if (!resumed) start = 0;
      final total = res.contentLength > 0 ? res.contentLength + start : -1;
      final sink = part.openWrite(mode: resumed ? FileMode.append : FileMode.write);
      int got = start;
      try {
        await for (final chunk in res) {
          if (_cancel) throw const HttpException('أُوقف التنزيل');
          sink.add(chunk);
          got += chunk.length;
          onProgress(total > 0 ? got / total : null, got);
        }
      } finally {
        await sink.flush();
        await sink.close();
      }
      await part.rename(file(m).path);
    } finally {
      client.close(force: true);
    }
  }

  Future<void> delete(ModelInfo m) async {
    if (await file(m).exists()) await file(m).delete();
    final part = File('${file(m).path}.part');
    if (await part.exists()) await part.delete();
  }

  Future<void> importFrom(String srcPath, String destName) async {
    await dir.create(recursive: true);
    final dest = File('${dir.path}/$destName');
    await File(srcPath).copy(dest.path);
  }
}
