import 'dart:async';
import 'package:flutter/services.dart';

/// جسر Flutter ⇄ Kotlin. كل العمل الثقيل يجري في خدمة أندرويد الأمامية.
class AgentBridge {
  static const _cmd = MethodChannel('dirgham/agent');
  static const _events = EventChannel('dirgham/agent_events');

  /// أحداث الوكيل: token | tool | status | confirm | transcript | final | voice_end | done | error
  Stream<Map<dynamic, dynamic>> get events =>
      _events.receiveBroadcastStream().cast<Map<dynamic, dynamic>>();

  Future<void> startService() => _cmd.invokeMethod('startService');
  Future<void> submitTask(String prompt) =>
      _cmd.invokeMethod('submitTask', {'prompt': prompt});
  Future<void> cancel() => _cmd.invokeMethod('cancel');
  Future<void> startListening() => _cmd.invokeMethod('startListening');
  Future<void> stopListening() => _cmd.invokeMethod('stopListening');
  Future<void> speak(String text) => _cmd.invokeMethod('speak', {'text': text});
  Future<void> stopSpeak() => _cmd.invokeMethod('stopSpeak');
  Future<void> runShell(String cmd) => _cmd.invokeMethod('runShell', {'cmd': cmd});
  Future<bool> termuxInstalled() async => (await _cmd.invokeMethod('termuxInstalled')) == true;
  Future<bool> termuxPermissionGranted() async =>
      (await _cmd.invokeMethod('termuxPermissionGranted')) == true;
  Future<void> requestTermuxPermission() => _cmd.invokeMethod('requestTermuxPermission');
  Future<String> modelsDir() async => (await _cmd.invokeMethod('modelsDir')) as String;
  Future<bool> nativeOk() async => (await _cmd.invokeMethod('nativeOk')) == true;
}
