import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:permission_handler/permission_handler.dart';
import 'screens/models_screen.dart';
import 'services/agent_bridge.dart';
import 'theme.dart';
import 'widgets/glass.dart';
import 'widgets/pattern_background.dart';

void main() => runApp(const DirghamApp());

class DirghamApp extends StatelessWidget {
  const DirghamApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'ضرغام كود',
        debugShowCheckedModeBanner: false,
        theme: DG.theme(),
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        home: const HomeScreen(),
      );
}

enum MsgKind { user, assistant, tool, status }

class Msg {
  final MsgKind kind;
  String text;
  Msg(this.kind, this.text);
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _bridge = AgentBridge();
  final _ctrl = TextEditingController();
  final _scroll = ScrollController();
  final List<Msg> _msgs = [
    Msg(MsgKind.assistant,
        'أهلًا بك في ضرغام كود. اكتب مهمتك أو تحدّث بصوتك، وأنا أختار الأداة المناسبة وأنفّذ.\nإن لم تنزّل النماذج بعد فافتح «الأدوات» من الأعلى.'),
  ];
  StreamSubscription? _sub;
  bool _listening = false;
  bool _busy = false;
  bool _streaming = false;
  bool _speak = false;

  @override
  void initState() {
    super.initState();
    _boot();
  }

  Future<void> _boot() async {
    await [Permission.microphone, Permission.notification].request();
    _sub = _bridge.events.listen(_onEvent, onError: (_) {});
    try {
      await _bridge.startService();
    } catch (_) {}
  }

  void _onEvent(Map e) {
    final type = e['type'] as String? ?? '';
    final text = e['text'] as String? ?? '';
    switch (type) {
      case 'token':
        setState(() {
          if (!_streaming) {
            _msgs.add(Msg(MsgKind.assistant, ''));
            _streaming = true;
          }
          _msgs.last.text += text;
        });
        break;
      case 'tool':
        setState(() {
          _streaming = false;
          _msgs.add(Msg(MsgKind.tool, text));
        });
        break;
      case 'status':
        setState(() {
          _streaming = false;
          _msgs.add(Msg(MsgKind.status, text));
        });
        break;
      case 'transcript':
        setState(() => _ctrl.text = text);
        break;
      case 'final':
        setState(() {
          _listening = false;
          _ctrl.text = text;
        });
        _send();
        break;
      case 'voice_end':
        setState(() => _listening = false);
        break;
      case 'confirm':
        _confirmRun(text);
        break;
      case 'done':
        final last = _msgs.isNotEmpty ? _msgs.last : null;
        setState(() {
          _busy = false;
          _streaming = false;
        });
        if (_speak && last != null && last.kind == MsgKind.assistant && last.text.isNotEmpty) {
          final clean = last.text.replaceAll(RegExp(r'```[\s\S]*?```'), ' كود ');
          _bridge.speak(clean);
        }
        break;
      case 'error':
        setState(() {
          _busy = false;
          _streaming = false;
          _msgs.add(Msg(MsgKind.status, text));
        });
        break;
    }
    _toBottom();
  }

  Future<void> _confirmRun(String cmd) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: GlassPanel(
          glow: DG.gold,
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('تأكيد تنفيذ أمر في Termux',
                style: TextStyle(color: DG.fire, fontWeight: FontWeight.w800, fontSize: 16)),
            const SizedBox(height: 10),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(color: Colors.black38, borderRadius: BorderRadius.circular(12)),
              child: SelectableText(cmd,
                  textDirection: TextDirection.ltr,
                  style: const TextStyle(color: DG.gold, fontFamily: 'monospace', fontSize: 13)),
            ),
            const SizedBox(height: 14),
            Row(children: [
              GlassButton(icon: Icons.play_arrow_rounded, label: 'نفّذ', color: DG.ok, onTap: () => Navigator.pop(ctx, true)),
              const SizedBox(width: 10),
              GlassButton(icon: Icons.close_rounded, label: 'إلغاء', onTap: () => Navigator.pop(ctx, false)),
            ]),
          ]),
        ),
      ),
    );
    if (ok == true) {
      try {
        await _bridge.runShell(cmd);
        setState(() => _msgs.add(Msg(MsgKind.status, 'أُرسل الأمر إلى Termux. تابع الإخراج هناك.')));
      } catch (e) {
        setState(() => _msgs.add(Msg(MsgKind.status, 'تعذّر التنفيذ: $e')));
      }
    } else {
      setState(() => _msgs.add(Msg(MsgKind.status, 'أُلغي الأمر')));
    }
    _toBottom();
  }

  void _toBottom() => WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_scroll.hasClients) {
          _scroll.animateTo(_scroll.position.maxScrollExtent,
              duration: const Duration(milliseconds: 220), curve: Curves.easeOut);
        }
      });

  Future<void> _send() async {
    final t = _ctrl.text.trim();
    if (t.isEmpty || _busy) return;
    await _bridge.stopSpeak();
    setState(() {
      _msgs.add(Msg(MsgKind.user, t));
      _busy = true;
      _streaming = false;
      _ctrl.clear();
    });
    _toBottom();
    try {
      await _bridge.submitTask(t);
    } catch (_) {
      setState(() => _busy = false);
    }
  }

  Future<void> _toggleMic() async {
    if (_busy) return;
    final next = !_listening;
    setState(() => _listening = next);
    try {
      next ? await _bridge.startListening() : await _bridge.stopListening();
    } catch (_) {
      setState(() => _listening = false);
    }
  }

  @override
  void dispose() {
    _sub?.cancel();
    _ctrl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PatternBackground(
        child: SafeArea(
          child: Column(children: [
            _header(),
            Expanded(child: _list()),
            _composer(),
          ]),
        ),
      ),
    );
  }

  Widget _header() => Padding(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
        child: GlassPanel(
          glow: DG.fire,
          child: Row(children: [
            Container(
              width: 10,
              height: 10,
              decoration: BoxDecoration(
                color: _busy ? DG.gold : DG.ok,
                shape: BoxShape.circle,
                boxShadow: [BoxShadow(color: (_busy ? DG.gold : DG.ok).withOpacity(0.7), blurRadius: 8)],
              ),
            ),
            const SizedBox(width: 10),
            const Text('ضرغام', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: DG.text)),
            const Text(' كود', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: DG.fire)),
            const Spacer(),
            GestureDetector(
              onTap: () => setState(() => _speak = !_speak),
              child: Icon(_speak ? Icons.volume_up_rounded : Icons.volume_off_rounded,
                  color: _speak ? DG.ok : DG.textDim),
            ),
            const SizedBox(width: 14),
            GestureDetector(
              onTap: () =>
                  Navigator.push(context, MaterialPageRoute(builder: (_) => ModelsScreen(bridge: _bridge))),
              child: const Icon(Icons.tune_rounded, color: DG.gold),
            ),
            if (_busy) ...[
              const SizedBox(width: 14),
              GestureDetector(
                onTap: () => _bridge.cancel(),
                child: const Icon(Icons.stop_circle_outlined, color: DG.fire),
              ),
            ],
          ]),
        ),
      );

  Widget _list() => ListView.builder(
        controller: _scroll,
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
        itemCount: _msgs.length + ((_busy && !_streaming) ? 1 : 0),
        itemBuilder: (_, i) => i >= _msgs.length ? _typing() : _bubble(_msgs[i]),
      );

  Widget _typing() => const Align(
        alignment: Alignment.centerLeft,
        child: Padding(
          padding: EdgeInsets.symmetric(vertical: 6),
          child: GlassPanel(
            radius: 18,
            child: Text('يفكّر…', style: TextStyle(color: DG.gold, fontSize: 13)),
          ),
        ),
      );

  Widget _bubble(Msg m) {
    final maxW = MediaQuery.of(context).size.width;
    switch (m.kind) {
      case MsgKind.user:
        return Align(
          alignment: Alignment.centerRight,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 5),
            child: ConstrainedBox(
              constraints: BoxConstraints(maxWidth: maxW * .82),
              child: GlassPanel(
                glow: DG.fire,
                child: Text(m.text, style: const TextStyle(color: DG.text, fontSize: 15, height: 1.6)),
              ),
            ),
          ),
        );
      case MsgKind.tool:
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 5),
          child: GlassPanel(
            radius: 16,
            child: Row(children: [
              const Icon(Icons.terminal_rounded, color: DG.gold, size: 18),
              const SizedBox(width: 8),
              Expanded(
                child: Text(m.text,
                    textDirection: TextDirection.ltr,
                    style: const TextStyle(color: DG.gold, fontFamily: 'monospace', fontSize: 12.5)),
              ),
            ]),
          ),
        );
      case MsgKind.status:
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Center(child: Text(m.text, style: const TextStyle(color: DG.textDim, fontSize: 12))),
        );
      case MsgKind.assistant:
        return Align(
          alignment: Alignment.centerLeft,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 5),
            child: ConstrainedBox(
              constraints: BoxConstraints(maxWidth: maxW * .9),
              child: GlassPanel(
                child: SelectableText(m.text.isEmpty ? '…' : m.text,
                    style: const TextStyle(color: DG.text, fontSize: 15, height: 1.7)),
              ),
            ),
          ),
        );
    }
  }

  Widget _composer() => Padding(
        padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
        child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          GlassButton(
              icon: _listening ? Icons.graphic_eq_rounded : Icons.mic_rounded,
              color: _listening ? DG.ok : DG.text,
              big: true,
              onTap: _toggleMic),
          const SizedBox(width: 10),
          Expanded(
            child: GlassPanel(
              radius: 28,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: TextField(
                controller: _ctrl,
                minLines: 1,
                maxLines: 4,
                style: const TextStyle(color: DG.text),
                decoration: InputDecoration(
                  hintText: _listening ? 'أسمعك… تحدّث الآن' : 'اكتب مهمتك…',
                  hintStyle: const TextStyle(color: DG.textDim),
                  border: InputBorder.none,
                ),
                onSubmitted: (_) => _send(),
              ),
            ),
          ),
          const SizedBox(width: 10),
          GlassButton(icon: Icons.arrow_upward_rounded, color: DG.fire, big: true, onTap: _send),
        ]),
      );
}
