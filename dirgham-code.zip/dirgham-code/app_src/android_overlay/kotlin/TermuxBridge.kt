package com.dirgham.code

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File

/**
 * تكامل Termux عبر RUN_COMMAND. شروطه:
 *  1) Termux مثبّت من F-Droid أو GitHub (وليس نسخة Play القديمة).
 *  2) في Termux: allow-external-apps=true داخل ~/.termux/termux.properties ثم إعادة تشغيله.
 *  3) منح تطبيقنا إذن «تشغيل الأوامر في Termux» من إعدادات أندرويد.
 */
object TermuxBridge {
    private const val PKG = "com.termux"
    private const val SVC = "com.termux.app.RunCommandService"
    private const val HOME = "/data/data/com.termux/files/home"
    private const val BASH = "/data/data/com.termux/files/usr/bin/bash"

    const val PERMISSION = "com.termux.permission.RUN_COMMAND"

    fun isInstalled(ctx: Context) = try {
        ctx.packageManager.getPackageInfo(PKG, 0); true
    } catch (_: Exception) { false }

    /** يفتح جلسة Termux ظاهرة ليرى المستخدم الإخراج. */
    fun run(ctx: Context, script: String) {
        val i = Intent().apply {
            component = ComponentName(PKG, SVC)
            action = "com.termux.RUN_COMMAND"
            putExtra("com.termux.RUN_COMMAND_PATH", BASH)
            putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-lc", script))
            putExtra("com.termux.RUN_COMMAND_WORKDIR", HOME)
            putExtra("com.termux.RUN_COMMAND_BACKGROUND", false)
            putExtra("com.termux.RUN_COMMAND_SESSION_ACTION", "0")
        }
        ctx.startService(i)
    }

    fun install(ctx: Context, pkg: String) {
        require(Regex("^[a-z0-9+._-]{1,64}$").matches(pkg)) { "اسم حزمة غير صالح" }
        run(ctx, "pkg install -y $pkg")
    }

    fun openApp(ctx: Context, pkg: String): Boolean {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return true
    }

    /** تسليم ملف لتطبيق خارجي (CapCut / ElevenLabs …). */
    fun shareFile(ctx: Context, file: File, mime: String, pkg: String) {
        val uri: Uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", file)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = mime
            setPackage(pkg)
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(i)
    }
}
