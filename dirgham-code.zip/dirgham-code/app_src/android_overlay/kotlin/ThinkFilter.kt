package com.dirgham.code

/** يحذف كتلة <think>…</think> التي يبدأ بها Qwen3 أحيانًا، أثناء البث. */
class ThinkFilter {
    private val buf = StringBuilder()
    private var state = 0 // 0 غير محسوم، 1 داخل think، 2 تمرير

    fun feed(s: String): String {
        if (state == 2) return s
        buf.append(s)
        if (state == 0) {
            val t = buf.toString().trimStart()
            if (t.isEmpty()) return ""
            if ("<think>".startsWith(t) && t.length < 7) return ""
            if (t.startsWith("<think>")) {
                state = 1
            } else {
                state = 2
                val out = buf.toString()
                buf.clear()
                return out
            }
        }
        if (state == 1) {
            val i = buf.indexOf("</think>")
            if (i < 0) return ""
            val rest = buf.substring(i + 8).trimStart()
            buf.clear()
            state = 2
            return rest
        }
        return ""
    }

    fun flush(): String {
        val o = if (state == 0) buf.toString() else ""
        buf.clear()
        return o
    }
}
