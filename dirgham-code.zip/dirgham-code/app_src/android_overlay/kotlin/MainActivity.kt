package com.dirgham.code

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.app.ActivityCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel
import java.util.Locale

class MainActivity : FlutterActivity() {

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale("ar"))
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
            }
        }
    }

    override fun configureFlutterEngine(engine: FlutterEngine) {
        super.configureFlutterEngine(engine)
        val messenger = engine.dartExecutor.binaryMessenger

        EventChannel(messenger, "dirgham/agent_events").setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(args: Any?, sink: EventChannel.EventSink) { Bus.sink = sink }
            override fun onCancel(args: Any?) { Bus.sink = null }
        })

        MethodChannel(messenger, "dirgham/agent").setMethodCallHandler { call, res ->
            when (call.method) {
                "startService" -> {
                    startForegroundService(Intent(this, AgentService::class.java))
                    res.success(null)
                }
                "submitTask" -> {
                    startForegroundService(
                        Intent(this, AgentService::class.java)
                            .setAction(AgentService.ACTION_SUBMIT)
                            .putExtra("prompt", call.argument<String>("prompt"))
                    )
                    res.success(null)
                }
                "cancel" -> {
                    startService(Intent(this, AgentService::class.java).setAction(AgentService.ACTION_CANCEL))
                    res.success(null)
                }
                "startListening" -> { startListening(); res.success(null) }
                "stopListening" -> { recognizer?.stopListening(); res.success(null) }
                "speak" -> {
                    if (ttsReady) tts?.speak(call.argument<String>("text").orEmpty(), TextToSpeech.QUEUE_FLUSH, null, "dg")
                    res.success(ttsReady)
                }
                "stopSpeak" -> { tts?.stop(); res.success(null) }
                "runShell" -> {
                    try {
                        TermuxBridge.run(this, call.argument<String>("cmd").orEmpty())
                        res.success(null)
                    } catch (e: SecurityException) {
                        res.error("perm", "امنح التطبيق إذن تشغيل الأوامر في Termux", null)
                    } catch (e: Exception) {
                        res.error("run", e.message, null)
                    }
                }
                "termuxInstalled" -> res.success(TermuxBridge.isInstalled(this))
                "termuxPermissionGranted" ->
                    res.success(checkSelfPermission(TermuxBridge.PERMISSION) == PackageManager.PERMISSION_GRANTED)
                "requestTermuxPermission" -> {
                    ActivityCompat.requestPermissions(this, arrayOf(TermuxBridge.PERMISSION), 77)
                    res.success(null)
                }
                "modelsDir" -> res.success(LlamaEngine.modelsDir(this).absolutePath)
                "nativeOk" -> res.success(LlamaEngine.nativeOk)
                else -> res.notImplemented()
            }
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Bus.emit("error", "خدمة التعرف على الصوت غير متاحة على هذا الجهاز")
            Bus.emit("voice_end")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rms: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, p: Bundle?) {}
                override fun onError(error: Int) { Bus.emit("voice_end") }
                override fun onPartialResults(b: Bundle?) {
                    b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                        ?.let { Bus.emit("transcript", it) }
                }
                override fun onResults(b: Bundle?) {
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrBlank()) Bus.emit("voice_end") else Bus.emit("final", t)
                }
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }
        recognizer?.startListening(i)
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
