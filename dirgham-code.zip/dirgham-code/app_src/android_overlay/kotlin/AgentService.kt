package com.dirgham.code

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import kotlinx.coroutines.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * خدمة أمامية تُبقي الوكيل شغالًا في الخلفية.
 * WakeLock جزئي أثناء المهمة فقط، ويُحرَّر فور انتهائها.
 */
class AgentService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private lateinit var llm: LlamaEngine
    private val history = ArrayDeque<Pair<String, String>>()

    companion object {
        const val CH = "dirgham_agent"
        const val ACTION_SUBMIT = "dirgham.SUBMIT"
        const val ACTION_CANCEL = "dirgham.CANCEL"
        private val APPS = mapOf(
            "termux" to "com.termux",
            "capcut" to "com.lemon.lvoverseas",
            "كاب كات" to "com.lemon.lvoverseas",
            "elevenlabs" to "io.elevenlabs.app",
            "ايليفن لابز" to "io.elevenlabs.app",
        )
    }

    override fun onCreate() {
        super.onCreate()
        llm = LlamaEngine(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "ضرغام كود", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, CH)
            .setContentTitle("ضرغام كود يعمل")
            .setContentText("الوكيل المحلي جاهز")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(1, n)
        }
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        when (i?.action) {
            ACTION_SUBMIT -> runTask(i.getStringExtra("prompt").orEmpty())
            ACTION_CANCEL -> job?.cancel()
        }
        return START_STICKY
    }

    private fun runTask(prompt: String) {
        job?.cancel()
        job = scope.launch {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "dirgham:task")
            wake.acquire(30 * 60 * 1000L)
            try {
                val r = ToolRouter.route(prompt)
                Bus.emit("tool", "route → ${r.tool}")
                when (r.tool) {
                    "termux_install" -> {
                        if (!TermuxBridge.isInstalled(this@AgentService)) {
                            Bus.emit("token", "Termux غير مثبّت. ثبّته من F-Droid أولًا.")
                        } else {
                            Bus.emit("confirm", "pkg install -y ${r.arg}")
                            Bus.emit("token", "بانتظار موافقتك على أمر التثبيت.")
                        }
                    }
                    "termux_run" -> {
                        if (!TermuxBridge.isInstalled(this@AgentService)) {
                            Bus.emit("token", "Termux غير مثبّت. ثبّته من F-Droid أولًا.")
                        } else {
                            Bus.emit("confirm", r.arg)
                            Bus.emit("token", "بانتظار موافقتك على تنفيذ الأمر.")
                        }
                    }
                    "openapp" -> {
                        val pkg = APPS.entries.firstOrNull { r.arg.contains(it.key) }?.value
                        val ok = pkg != null && TermuxBridge.openApp(this@AgentService, pkg)
                        Bus.emit("token", if (ok) "فتحت التطبيق." else "لم أجد التطبيق. تأكد أنه مثبّت.")
                    }
                    "video" -> Bus.emit(
                        "token",
                        "المونتاج المحلي الكامل غير متاح في هذا الإصدار. الطريقة العملية: " +
                            "قل «ثبّت ffmpeg» لتجهيز Termux، ثم جهّز الصور والصوت وأكمل في CapCut (قل: افتح capcut)."
                    )
                    "vision", "imagegen" -> Bus.emit(
                        "token",
                        "تحليل الصور وتوليدها غير متاحين في هذا الإصدار. هما مخططان للإصدار القادم."
                    )
                    else -> chat(prompt, r)
                }
                Bus.emit("done")
            } catch (e: CancellationException) {
                Bus.emit("status", "أُلغيت المهمة")
                Bus.emit("done")
            } catch (e: Throwable) {
                Bus.emit("error", e.message ?: "خطأ غير معروف")
            } finally {
                if (wake.isHeld) wake.release()
            }
        }
    }

    private suspend fun chat(prompt: String, r: Route) {
        val model = r.model ?: Models.CHAT
        Bus.emit("status", "تحميل النموذج…")
        llm.ensureLoaded(model)
        val noThink = model.startsWith("Qwen3")
        val ctxHistory = if (r.tool == "chat") history.toList() else emptyList()
        val full = ToolRouter.chatml(ToolRouter.systemPrompt(r.tool), ctxHistory, prompt, noThink)

        val filter = ThinkFilter()
        val answer = StringBuilder()
        val coCtx = currentCoroutineContext()
        llm.generate(full) { piece ->
            val out = filter.feed(piece)
            if (out.isNotEmpty()) {
                answer.append(out)
                Bus.emit("token", out)
            }
            coCtx.isActive
        }
        val tail = filter.flush()
        if (tail.isNotEmpty()) { answer.append(tail); Bus.emit("token", tail) }

        if (r.tool == "chat") {
            history.addLast(prompt to answer.toString())
            while (history.size > 3) history.removeFirst()
        }
        if (r.tool == "code") saveCode(answer.toString())
    }

    private fun saveCode(text: String) {
        val m = Regex("```(\\w*)\\s*\\n([\\s\\S]*?)```").find(text) ?: return
        val lang = m.groupValues[1].lowercase()
        val ext = mapOf(
            "python" to "py", "py" to "py", "kotlin" to "kt", "dart" to "dart", "javascript" to "js",
            "js" to "js", "bash" to "sh", "sh" to "sh", "html" to "html", "java" to "java",
            "c" to "c", "cpp" to "cpp", "json" to "json"
        )[lang] ?: "txt"
        val dir = File(getExternalFilesDir(null), "projects").also { it.mkdirs() }
        val name = "code_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + "." + ext
        File(dir, name).writeText(m.groupValues[2])
        Bus.emit("tool", "حُفظ: projects/$name")
    }

    override fun onDestroy() {
        scope.cancel()
        llm.unload()
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null
}
