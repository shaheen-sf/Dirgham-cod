package com.dirgham.code

data class Route(
    val tool: String,
    val model: String? = null,
    val arg: String = "",
)

object Models {
    const val CHAT = "Qwen3-1.7B-Q4_K_M.gguf"
    const val CODE = "qwen2.5-coder-1.5b-instruct-q4_k_m.gguf"
}

/**
 * يختار الأداة بقواعد رخيصة (كلمات مفتاحية) دون استدعاء النموذج، لتوفير الذاكرة والبطارية.
 */
object ToolRouter {

    /** إزالة التشكيل وتوحيد الألف والياء والتاء المربوطة لمطابقة أسهل. */
    fun norm(s: String): String = s.lowercase()
        .replace(Regex("[\\u064B-\\u0652\\u0640]"), "")
        .replace(Regex("[أإآ]"), "ا")
        .replace('ى', 'ي')
        .replace('ة', 'ه')

    private fun has(p: String, vararg k: String) = k.any { p.contains(norm(it)) }

    fun route(prompt: String): Route {
        val p = norm(prompt.trim())

        Regex("^(?:ثبت|نزل|install)\\s+([a-z0-9+._-]{1,64})").find(p)?.let {
            return Route("termux_install", arg = it.groupValues[1])
        }
        val plain = prompt.trim().replace(Regex("[\\u064B-\\u0652]"), "")
        Regex("^(?:نفذ|شغل|run|\\$)\\s+(.+)$", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
            .find(plain)?.let {
                return Route("termux_run", arg = it.groupValues[1].trim())
            }
        if (p.startsWith("افتح")) return Route("openapp", arg = p.removePrefix("افتح").trim())

        return when {
            has(p, "ولد صوره", "انتج صوره", "ارسم", "صمم صوره") -> Route("imagegen")
            has(p, "حلل") && has(p, "صوره", "الصوره") -> Route("vision")
            has(p, "فيديو", "مونتاج") -> Route("video")
            has(p, "اكتب كود", "برمج", "دالة", "سكربت", "script", "function", "صحح الكود", "bug", "كود") ->
                Route("code", Models.CODE)
            else -> Route("chat", Models.CHAT)
        }
    }

    fun systemPrompt(tool: String) = when (tool) {
        "code" -> "أنت مبرمج محترف. اكتب كودًا قصيرًا وصحيحًا داخل كتلة ``` مع اسم اللغة، ثم اشرح بالعربية في سطرين."
        else -> "أنت ضرغام كود، مساعد ذكي محلي يتحدث العربية الفصحى المبسطة. أجب باختصار ووضوح."
    }

    /** قالب ChatML المستخدم في Qwen. history = أزواج (سؤال، جواب) الأقدم أولًا. */
    fun chatml(system: String, history: List<Pair<String, String>>, user: String, noThink: Boolean): String {
        val sb = StringBuilder()
        sb.append("<|im_start|>system\n").append(system).append("<|im_end|>\n")
        for ((u, a) in history) {
            sb.append("<|im_start|>user\n").append(u).append("<|im_end|>\n")
            sb.append("<|im_start|>assistant\n").append(a).append("<|im_end|>\n")
        }
        sb.append("<|im_start|>user\n").append(user)
        if (noThink) sb.append(" /no_think")
        sb.append("<|im_end|>\n<|im_start|>assistant\n")
        return sb.toString()
    }
}
