package com.dirgham.code

import android.content.Context
import androidx.annotation.Keep
import java.io.File

@Keep
fun interface TokenCallback {
    fun onToken(piece: String): Boolean // false = إيقاف التوليد
}

/**
 * غلاف llama.cpp. نموذج واحد فقط في الذاكرة في كل مرة (توفير للذاكرة).
 * ملفات النماذج في: <ExternalFiles>/models  (نفس المجلد الذي تستخدمه شاشة النماذج).
 */
@Keep
class LlamaEngine(private val ctx: Context) {

    companion object {
        val nativeOk: Boolean = try {
            System.loadLibrary("llama_jni"); true
        } catch (_: UnsatisfiedLinkError) { false }

        fun modelsDir(ctx: Context): File =
            File(ctx.getExternalFilesDir(null), "models").also { it.mkdirs() }
    }

    private var loadedPath: String? = null
    private var handle: Long = 0L

    private external fun nativeLoad(path: String, nCtx: Int, nThreads: Int): Long
    private external fun nativeGenerate(h: Long, prompt: String, maxTokens: Int, cb: TokenCallback): Int
    private external fun nativeFree(h: Long)

    fun modelFile(name: String) = File(modelsDir(ctx), name)
    fun hasModel(name: String) = modelFile(name).let { it.exists() && it.length() > 1_000_000 }

    @Synchronized
    fun ensureLoaded(fileName: String, nCtx: Int = 3072) {
        check(nativeOk) { "المكتبة الأصلية llama_jni غير موجودة في هذا الـ APK" }
        val f = modelFile(fileName)
        require(f.exists()) { "النموذج غير موجود: $fileName. نزّله من شاشة النماذج." }
        if (loadedPath == f.absolutePath && handle != 0L) return
        unload()
        val threads = (Runtime.getRuntime().availableProcessors() - 2).coerceIn(2, 6)
        handle = nativeLoad(f.absolutePath, nCtx, threads)
        check(handle != 0L) { "فشل تحميل النموذج (الذاكرة غير كافية أو الملف تالف)" }
        loadedPath = f.absolutePath
    }

    fun generate(prompt: String, maxTokens: Int = 768, onToken: (String) -> Boolean): Int {
        check(handle != 0L) { "لا يوجد نموذج محمّل" }
        return nativeGenerate(handle, prompt, maxTokens, TokenCallback { onToken(it) })
    }

    @Synchronized
    fun unload() {
        if (handle != 0L) nativeFree(handle)
        handle = 0L
        loadedPath = null
    }
}
