#include <jni.h>
#include <android/log.h>
#include <algorithm>
#include <cstdint>
#include <string>
#include <vector>
#include "llama.h"

#define TAG "DirghamLlama"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

struct Handle {
    llama_model * model = nullptr;
    int n_ctx = 3072;
    int n_threads = 4;
};

static bool g_backend_ready = false;

// يفكّ أكبر عدد ممكن من تسلسلات UTF-8 الكاملة إلى UTF-16 ويُبقي الذيل الناقص في pend
static std::u16string drain_utf16(std::string & pend) {
    std::u16string out;
    size_t i = 0, n = pend.size();
    while (i < n) {
        unsigned char c = (unsigned char) pend[i];
        uint32_t cp;
        size_t len;
        if (c < 0x80)              { cp = c;        len = 1; }
        else if ((c >> 5) == 0x6)  { cp = c & 0x1F; len = 2; }
        else if ((c >> 4) == 0xE)  { cp = c & 0x0F; len = 3; }
        else if ((c >> 3) == 0x1E) { cp = c & 0x07; len = 4; }
        else { i++; continue; }
        if (i + len > n) break;
        bool ok = true;
        for (size_t k = 1; k < len; k++) {
            unsigned char cc = (unsigned char) pend[i + k];
            if ((cc & 0xC0) != 0x80) { ok = false; break; }
            cp = (cp << 6) | (cc & 0x3F);
        }
        if (!ok) { i++; continue; }
        if (cp >= 0x10000) {
            cp -= 0x10000;
            out.push_back((char16_t) (0xD800 + (cp >> 10)));
            out.push_back((char16_t) (0xDC00 + (cp & 0x3FF)));
        } else {
            out.push_back((char16_t) cp);
        }
        i += len;
    }
    pend.erase(0, i);
    return out;
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_dirgham_code_LlamaEngine_nativeLoad(JNIEnv * env, jobject, jstring jpath, jint nCtx, jint nThreads) {
    if (!g_backend_ready) {
        llama_backend_init();
        g_backend_ready = true;
    }
    const char * p = env->GetStringUTFChars(jpath, nullptr);
    std::string path(p);
    env->ReleaseStringUTFChars(jpath, p);

    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;
    mp.use_mmap = true;
    llama_model * model = llama_model_load_from_file(path.c_str(), mp);
    if (!model) {
        LOGE("failed to load model: %s", path.c_str());
        return 0;
    }
    Handle * h = new Handle();
    h->model = model;
    h->n_ctx = nCtx;
    h->n_threads = nThreads;
    return reinterpret_cast<jlong>(h);
}

extern "C" JNIEXPORT jint JNICALL
Java_com_dirgham_code_LlamaEngine_nativeGenerate(JNIEnv * env, jobject, jlong handle, jstring jprompt,
                                                  jint maxTokens, jobject cb) {
    Handle * H = reinterpret_cast<Handle *>(handle);
    if (!H || !H->model) return -1;

    jclass cls = env->GetObjectClass(cb);
    jmethodID mid = env->GetMethodID(cls, "onToken", "(Ljava/lang/String;)Z");
    if (!mid) return -2;

    const char * p = env->GetStringUTFChars(jprompt, nullptr);
    std::string prompt(p);
    env->ReleaseStringUTFChars(jprompt, p);

    const llama_vocab * vocab = llama_model_get_vocab(H->model);
    int n = -llama_tokenize(vocab, prompt.c_str(), (int32_t) prompt.size(), nullptr, 0, true, true);
    if (n <= 0) return -3;
    std::vector<llama_token> toks(n);
    if (llama_tokenize(vocab, prompt.c_str(), (int32_t) prompt.size(), toks.data(), (int32_t) toks.size(), true, true) < 0)
        return -3;

    int allowed = H->n_ctx - (int) maxTokens - 8;
    if (allowed < 64) return -4;
    if ((int) toks.size() > allowed) {
        toks.erase(toks.begin(), toks.begin() + ((int) toks.size() - allowed));
    }

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = H->n_ctx;
    cp.n_batch = 512;
    cp.n_ubatch = 512;
    cp.n_threads = H->n_threads;
    cp.n_threads_batch = H->n_threads;
    llama_context * ctx = llama_init_from_model(H->model, cp);
    if (!ctx) return -5;

    llama_sampler * smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(smpl, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(smpl, llama_sampler_init_top_p(0.9f, 1));
    llama_sampler_chain_add(smpl, llama_sampler_init_temp(0.6f));
    llama_sampler_chain_add(smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    int rc = 0;
    for (size_t i = 0; i < toks.size(); i += 512) {
        int cnt = (int) std::min<size_t>(512, toks.size() - i);
        llama_batch b = llama_batch_get_one(toks.data() + i, cnt);
        if (llama_decode(ctx, b) != 0) { rc = -6; break; }
    }

    int gen = 0;
    std::string pend;
    while (rc == 0 && gen < maxTokens) {
        llama_token tok = llama_sampler_sample(smpl, ctx, -1);
        if (llama_vocab_is_eog(vocab, tok)) break;

        char buf[256];
        int len = llama_token_to_piece(vocab, tok, buf, sizeof(buf), 0, true);
        if (len > 0) pend.append(buf, (size_t) len);

        std::u16string u = drain_utf16(pend);
        if (!u.empty()) {
            jstring js = env->NewString(reinterpret_cast<const jchar *>(u.data()), (jsize) u.size());
            jboolean cont = env->CallBooleanMethod(cb, mid, js);
            env->DeleteLocalRef(js);
            if (env->ExceptionCheck()) { env->ExceptionClear(); break; }
            if (!cont) break;
        }

        llama_batch b = llama_batch_get_one(&tok, 1);
        if (llama_decode(ctx, b) != 0) { rc = -7; break; }
        gen++;
    }

    llama_sampler_free(smpl);
    llama_free(ctx);
    return rc != 0 ? rc : gen;
}

extern "C" JNIEXPORT void JNICALL
Java_com_dirgham_code_LlamaEngine_nativeFree(JNIEnv *, jobject, jlong handle) {
    Handle * H = reinterpret_cast<Handle *>(handle);
    if (!H) return;
    if (H->model) llama_model_free(H->model);
    delete H;
}
