package com.dirgham.code

import android.content.Context
import java.io.File

/** المهارات: ملفات SKILL.md يقرؤها الوكيل عند الحاجة. تُثبَّت من رابط أو نص، وتُحفظ في التخزين الداخلي. */
object Skills {
    fun dir(c: Context): File = File(c.filesDir, "skills").also { it.mkdirs() }

    fun ensureBuiltins(c: Context) {
        for ((name, text) in BUILTIN) {
            val d = File(dir(c), name)
            d.mkdirs()
            File(d, "SKILL.md").writeText(text)
        }
    }

    fun description(c: Context, name: String): String {
        val txt = read(c, name) ?: return ""
        val m = Regex("(?m)^description:\\s*(.+)$").find(txt)
        return m?.groupValues?.get(1)?.trim() ?: ""
    }

    fun isBuiltin(name: String): Boolean = BUILTIN.containsKey(name)

    fun delete(c: Context, name: String): Boolean =
        !isBuiltin(name) && name.matches(Regex("[A-Za-z0-9_-]{1,60}")) && File(dir(c), name).deleteRecursively()

    fun names(c: Context): List<String> =
        (dir(c).listFiles() ?: emptyArray()).filter { File(it, "SKILL.md").exists() }.map { it.name }.sorted()

    fun read(c: Context, name: String): String? {
        if (!name.matches(Regex("[A-Za-z0-9_-]{1,60}"))) return null
        val f = File(File(dir(c), name), "SKILL.md")
        return if (f.exists()) f.readText() else null
    }

    fun description(text: String): String {
        val m = Regex("(?m)^description:\\s*(.+)$").find(text)
        return m?.groupValues?.get(1)?.trim() ?: text.lineSequence().firstOrNull { it.isNotBlank() }?.take(100) ?: ""
    }

    fun save(c: Context, name: String, text: String) {
        val d = File(dir(c), name)
        d.mkdirs()
        File(d, "SKILL.md").writeText(text)
    }

    private val BUILTIN: Map<String, String> = mapOf(
        "motion-graphics" to """---
name: motion-graphics
description: صناعة موشن جرافيك متحرك (نصوص، أشكال، شخصيات، انتقالات) كصفحة HTML كاملة، وتصديره فيديو MP4 عبر Termux عند الطلب.
---
# Motion graphics

## الصفحة المتحركة (تعمل مباشرة)
1. اكتب ملف HTML واحدًا كاملًا مستقلًا بوسم الملف: <write_file path="motion/scene.html"> ... </write_file> (لا تختصر ولا تضع «...» داخل الكود).
2. المسرح 1280x720. استعمل CSS animations أو canvas مع requestAnimationFrame، وحلقة مدتها 8 إلى 12 ثانية، مع عدة مشاهد (ظهور، حوار بفقاعات نص، انتقال).
3. الشخصيات: ارسمها بـ SVG أو CSS (رأس دائري، جسم، ذراعان تتحركان بـ keyframes)، ولكل شخصية لون مميز وفقاعة كلام تظهر بالتناوب لتبدو كأنها تتحاور.
4. سلّم الملف: send_file {"path":"motion/scene.html"} (يفتح معاينة ويحفظه في التنزيلات).

## الأسرع: أداة make_video (فيديو جاهز بلا كتابة كود)
لأي طلب فيديو فيه شخصيتان تتحاوران: استدعِ make_video بمشاهد قصيرة (speaker: A أو B أو narrator، text، sec). تنتج MP4 وتسلّمه تلقائيًا، وتعمل في دقائق لا ساعات. يلزم جسر Termux متصلًا.

## تصدير فيديو مخصص (يدويًا)
1. shell: pkg install -y python ffmpeg && pip install pillow
2. اكتب سكربت بايثون كاملًا motion/render.py بوسم الملف؛ يرسم الإطارات بـ Pillow إلى motion/frames/f0001.png… (30 إطارًا في الثانية).
3. shell: python3 motion/render.py ثم: ffmpeg -y -framerate 30 -i motion/frames/f%04d.png -c:v libx264 -pix_fmt yuv420p motion/out.mp4
4. سلّم: send_file {"path":"motion/out.mp4"}. للصوت: أضف ‎-i voice.mp3 ‎ في أمر ffmpeg.

## ملاحظات
- نفّذ العمل فعليًا بالأدوات؛ لا تقل «استخدمت المهارة» دون أن تكتب الملفات.
- الحركات البسيطة (ظهور، انزلاق، تكبير، اهتزاز) أنسب لنموذج صغير.
""",
        "termux-setup" to """---
name: termux-setup
description: تجهيز Termux بأدوات التطوير الشائعة وحل مشاكل الصلاحيات والتثبيت.
---
# تجهيز Termux

- تحديث: pkg update -y && pkg upgrade -y
- أدوات شائعة: pkg install -y python git nodejs clang make ffmpeg
- تثبيت حزمة بايثون: pip install اسم_الحزمة
- إذا فشل pkg بسبب المرآة: termux-change-repo
- لا تنفّذ أوامر حذف أو تعديل خارج مجلد المشروع دون إذن صريح من المستخدم.
- بعد كل أمر اقرأ exit= في النتيجة؛ إن لم يكن 0 فاقرأ stderr وأصلح الأمر ثم أعد المحاولة مرة واحدة.
""",
        "code-writer" to """---
name: code-writer
description: قواعد كتابة الكود وحفظه واختباره بشكل منظم.
---
# كتابة الكود

1. افهم المطلوب في جملة، ثم اكتب كل ملف كاملًا بوسم الملف <write_file path="مجلد/ملف.py"> ... </write_file> (بلا اختصار).
2. ملفات مسمّاة بوضوح، وتعليقات قصيرة.
3. للتجربة: شغّله بـ shell (مثال: python3 مجلد/main.py). وللتسليم استعمل send_file.
4. إن ظهر خطأ فاقرأه وأصلح السبب الجذري ولا تخمّن.
5. اختم بملخص عربي من سطرين: ما الذي كتبته وأين وكيف يشغّله المستخدم.
""",
        "skill-creator" to """---
name: skill-creator
description: كتابة مهارة جديدة وتثبيتها ليستعملها الوكيل لاحقًا.
---
# إنشاء مهارة

صيغة الملف:
---
name: اسم-بحروف-لاتينية-صغيرة
description: جملة واحدة تقول متى تُستعمل المهارة
---
ثم تعليمات مرقّمة قصيرة وواضحة.

للتثبيت استعمل install_skill بالاسم والنص (content)، أو بالرابط (url) إن طلب المستخدم ذلك.
لا تثبّت مهارة من رابط دون أن يوافق المستخدم على الرابط.
"""
    )
}
