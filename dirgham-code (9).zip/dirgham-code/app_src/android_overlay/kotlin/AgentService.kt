package com.dirgham.code

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * خدمة أمامية تُبقي الوكيل والتنزيلات شغّالة في الخلفية والشاشة مطفأة.
 * WakeLock جزئي أثناء المهمة والتنزيل فقط.
 */
class AgentService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private lateinit var llm: LlamaEngine
    private lateinit var agent: Agent
    private var wake: PowerManager.WakeLock? = null

    companion object {
        const val CH = "dirgham_agent"
        const val ACTION_SUBMIT = "dirgham.SUBMIT"
        const val ACTION_CANCEL = "dirgham.CANCEL"
        const val ACTION_DOWNLOAD = "dirgham.DOWNLOAD"
        const val ACTION_DL_CANCEL = "dirgham.DL_CANCEL"
        const val ACTION_NEWCHAT = "dirgham.NEWCHAT"
        const val ACTION_RESTORE = "dirgham.RESTORE"
        const val ACTION_TERMUX_TEST = "dirgham.TERMUX_TEST"
    }

    private fun note(text: String): Notification =
        Notification.Builder(this, CH)
            .setContentTitle("ضرغام كود يعمل")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()

    private fun updateNote(text: String) {
        getSystemService(NotificationManager::class.java).notify(1, note(text))
    }

    override fun onCreate() {
        super.onCreate()
        llm = LlamaEngine.shared(this)
        Confirm.notifier = { t, d -> notifyAsk(t, d) }
        agent = Agent(this, llm)
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CH, "ضرغام كود", NotificationManager.IMPORTANCE_LOW))
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("dirgham_done", "اكتمال المهام", NotificationManager.IMPORTANCE_HIGH))
        val n = note("الوكيل المحلي جاهز")
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(1, n)
        }
        LocalBridge.setDirs(java.io.File(filesDir, "workspace"))
        LocalBridge.start(47611, Settings.bridgeToken(this))
        Downloads.notify = { t -> updateNote(t) }
        scope.launch {
            try {
                Skills.ensureBuiltins(this@AgentService)
                LlamaEngine.migrateOld(this@AgentService)
            } catch (_: Exception) {}
        }
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        when (i?.action) {
            ACTION_SUBMIT -> runTask(i.getStringExtra("prompt").orEmpty())
            ACTION_CANCEL -> job?.cancel()
            ACTION_NEWCHAT -> agent.clear()
            ACTION_RESTORE -> agent.restore(i.getStringExtra("json").orEmpty())
            ACTION_DOWNLOAD -> {
                val url = i.getStringExtra("url").orEmpty()
                val name = i.getStringExtra("name").orEmpty()
                Downloads.start(this, scope, url, name)
            }
            ACTION_DL_CANCEL -> Downloads.cancel(i.getStringExtra("name").orEmpty())
            ACTION_TERMUX_TEST -> termuxTest()
        }
        return START_STICKY
    }

    private fun termuxTest() {
        scope.launch {
            if (!TermuxBridge.isInstalled(this@AgentService)) {
                Bus.emit("status", "Termux غير مثبّت.")
                return@launch
            }
            if (!TermuxBridge.available(this@AgentService)) {
                Bus.emit("status", "Termux غير موصول: شغّل أمر الجسر في Termux (من شاشة الأدوات)، أو امنح إذن «تشغيل الأوامر».")
                return@launch
            }
            Bus.emit("status", "اختبار Termux… (قد يستغرق نصف دقيقة)")
            try {
                val r = TermuxBridge.runCapture(this@AgentService, "echo termux-ok; uname -m", 30_000L)
                Bus.emit("status", "نتيجة Termux: " + Tools.clip(r, 300))
            } catch (e: SecurityException) {
                Bus.emit("status", "رُفض الإذن من أندرويد: " + (e.message ?: ""))
            } catch (e: Exception) {
                Bus.emit("status", "خطأ: " + (e.message ?: ""))
            }
        }
    }

    /** إشعار عند الانتهاء إذا كان التطبيق في الخلفية. */
    private fun notifyDone(title: String, text: String) {
        if (MainActivity.visible) return
        try {
            val pi = android.app.PendingIntent.getActivity(
                this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
                android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT)
            val n = Notification.Builder(this, "dirgham_done")
                .setContentTitle("ضرغام كود: $title")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            getSystemService(NotificationManager::class.java).notify(2, n)
        } catch (_: Exception) {}
    }

    private var idleJob: Job? = null

    /** يفرّغ النموذج من الرام بعد مدة خمول (إعداد المستخدم) كي لا يستهلك الذاكرة وهو غير مستعمل. */
    private fun scheduleIdleUnload() {
        idleJob?.cancel()
        val mins = Settings.idleMinutes(this)
        if (mins <= 0) return
        idleJob = scope.launch {
            kotlinx.coroutines.delay(mins * 60_000L)
            if (job?.isActive != true && llm.isLoaded()) {
                llm.unload()
                updateNote("النموذج مُفرَّغ من الرام (خامل). يُحمَّل تلقائيًا عند أول طلب.")
            }
        }
    }

    private fun notifyAsk(title: String, detail: String) {
        try {
            val pi = android.app.PendingIntent.getActivity(
                this, 1, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
                android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT)
            val n = Notification.Builder(this, "dirgham_done")
                .setContentTitle("ضرغام كود يحتاج موافقتك")
                .setContentText(title + ": " + detail.take(80))
                .setStyle(Notification.BigTextStyle().bigText(title + "\n" + detail.take(300)))
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentIntent(pi).setAutoCancel(true).build()
            getSystemService(NotificationManager::class.java).notify(3, n)
        } catch (_: Exception) {}
    }

    private fun runTask(prompt: String) {
        idleJob?.cancel()
        job?.cancel()
        job = scope.launch {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val w = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "dirgham:task")
            w.acquire(30 * 60 * 1000L)
            wake = w
            try {
                if (prompt.trim() == "/diag") agent.diagnose()
                else agent.run(prompt, Settings.thinking(this@AgentService))
                Bus.emit("done")
                notifyDone("اكتملت المهمة", prompt.trim().take(80))
            } catch (e: CancellationException) {
                Bus.emit("status", "أُلغيت المهمة")
                Bus.emit("done")
            } catch (e: Throwable) {
                Bus.emit("error", e.message ?: "خطأ غير معروف")
                notifyDone("تعذّرت المهمة", e.message ?: "")
            } finally {
                if (w.isHeld) w.release()
                scheduleIdleUnload()
            }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        Downloads.notify = null
        llm.unload()
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null
}
