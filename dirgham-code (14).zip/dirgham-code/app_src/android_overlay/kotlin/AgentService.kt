package com.dirgham.code

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * خدمة أمامية تُبقي الوكيل والتنزيلات شغّالة في الخلفية والشاشة مطفأة.
 * WakeLock جزئي أثناء المهمة والتنزيل فقط.
 */
class AgentService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private lateinit var llm: LlamaEngine
    private lateinit var agent: Agent
    private var wake: PowerManager.WakeLock? = null

    companion object {
        const val CH = "dirgham_agent"
        const val ACTION_SUBMIT = "dirgham.SUBMIT"
        const val ACTION_CANCEL = "dirgham.CANCEL"
        const val ACTION_DOWNLOAD = "dirgham.DOWNLOAD"
        const val ACTION_DL_CANCEL = "dirgham.DL_CANCEL"
        const val ACTION_NEWCHAT = "dirgham.NEWCHAT"
        const val ACTION_RESTORE = "dirgham.RESTORE"
        const val ACTION_TERMUX_TEST = "dirgham.TERMUX_TEST"
    }

    private fun note(text: String): Notification =
        Notification.Builder(this, CH)
            .setContentTitle("ضرغام كود يعمل")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()

    private fun updateNote(text: String) {
        getSystemService(NotificationManager::class.java).notify(1, note(text))
    }

    override fun onCreate() {
        super.onCreate()
        Crash.init(this)
        llm = LlamaEngine.shared(this)
        Confirm.notifier = { t, d -> notifyAsk(t, d) }
        agent = Agent(this, llm)
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CH, "ضرغام كود", NotificationManager.IMPORTANCE_LOW))
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("dirgham_done", "اكتمال المهام", NotificationManager.IMPORTANCE_HIGH))
        val n = note("الوكيل المحلي جاهز")
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(1, n, 0x40000000) // SPECIAL_USE: بلا حد ساعات dataSync
            } else if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            } else {
                startForeground(1, n)
            }
        } catch (e: Exception) {
            Bus.emit("status", "تعذّر تشغيل الخدمة الأمامية: " + (e.message ?: ""))
        }
        LocalBridge.setDirs(java.io.File(filesDir, "workspace"))
        LocalBridge.start(47611, Settings.bridgeToken(this))
        Downloads.notify = { t -> updateNote(t) }
        llm.threadOverride = Settings.threads(this)
        // حارس الجسر: إن انقطع وكان إذن Termux ممنوحًا نعيد تشغيله تلقائيًا
        scope.launch {
            while (true) {
                kotlinx.coroutines.delay(45_000)
                try { if (!LocalBridge.connected()) TermuxBridge.autoStart(this@AgentService) } catch (_: Exception) {}
            }
        }
        scope.launch {
            try {
                Skills.ensureBuiltins(this@AgentService)
                LlamaEngine.migrateOld(this@AgentService)
            } catch (_: Exception) {}
        }
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        when (i?.action) {
            ACTION_SUBMIT -> runTask(i.getStringExtra("prompt").orEmpty())
            ACTION_CANCEL -> { llm.abort(); job?.cancel() }
            ACTION_NEWCHAT -> agent.clear()
            ACTION_RESTORE -> agent.restore(i.getStringExtra("json").orEmpty())
            ACTION_DOWNLOAD -> {
                val url = i.getStringExtra("url").orEmpty()
                val name = i.getStringExtra("name").orEmpty()
                Downloads.start(this, scope, url, name)
            }
            ACTION_DL_CANCEL -> Downloads.cancel(i.getStringExtra("name").orEmpty())
            ACTION_TERMUX_TEST -> termuxTest()
        }
        return START_STICKY
    }

    private fun termuxTest() {
        scope.launch {
            if (!TermuxBridge.isInstalled(this@AgentService)) {
                Bus.emit("status", "Termux غير مثبّت.")
                return@launch
            }
            if (!TermuxBridge.available(this@AgentService)) {
                Bus.emit("status", "Termux غير موصول: شغّل أمر الجسر في Termux (من شاشة الأدوات)، أو امنح إذن «تشغيل الأوامر».")
                return@launch
            }
            Bus.emit("status", "اختبار Termux… (قد يستغرق نصف دقيقة)")
            try {
                val r = TermuxBridge.runCapture(this@AgentService, "echo termux-ok; uname -m", 30_000L)
                Bus.emit("status", "نتيجة Termux: " + Tools.clip(r, 300))
            } catch (e: SecurityException) {
                Bus.emit("status", "رُفض الإذن من أندرويد: " + (e.message ?: ""))
            } catch (e: Exception) {
                Bus.emit("status", "خطأ: " + (e.message ?: ""))
            }
        }
    }

    /** إشعار عند الانتهاء إذا كان التطبيق في الخلفية. */
    private fun notifyDone(title: String, text: String) {
        if (MainActivity.visible) return
        try {
            val pi = android.app.PendingIntent.getActivity(
                this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
                android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT)
            val n = Notification.Builder(this, "dirgham_done")
                .setContentTitle("ضرغام كود: $title")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            getSystemService(NotificationManager::class.java).notify(2, n)
        } catch (_: Exception) {}
    }

    private var idleJob: Job? = null

    /** ضغط ذاكرة من النظام: إن لم تكن هناك مهمة جارية نفرّغ النموذج (يعود تلقائيًا عند الحاجة). */
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW && job?.isActive != true && llm.isLoaded()) {
            llm.unload()
            updateNote("فُرّغ النموذج من الرام بسبب ضغط الذاكرة. يُحمَّل عند أول طلب.")
        }
    }
    private var statsJob: Job? = null

    /** كل ثانية أثناء المهمة: سرعة التوليد (رمز/ث) واستهلاك ذاكرة التطبيق ومعالجه. */
    private fun startStats() {
        statsJob?.cancel()
        statsJob = scope.launch {
            var lastCpu = readCpuTicks(); var lastT = System.nanoTime()
            val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
            while (true) {
                kotlinx.coroutines.delay(2000)
                val now = System.nanoTime(); val cpu = readCpuTicks()
                val pct = if (lastCpu >= 0 && cpu >= 0) ((cpu - lastCpu) * 1_000_000_000.0 / (now - lastT) / cores).toInt() else -1
                lastCpu = cpu; lastT = now
                val rss = readRssMb()
                val am = getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
                val sys = android.app.ActivityManager.MemoryInfo(); am.getMemoryInfo(sys)
                Bus.emit("stats", org.json.JSONObject().put("tps", agent.tps.toDouble()).put("ram", rss)
                    .put("free", sys.availMem / 1048576).put("cpu", pct).put("cores", cores).toString())
            }
        }
    }

    /** الذاكرة المقيمة للعملية (MB) من /proc/self/statm — رخيصة، بخلاف Debug.getMemoryInfo التي تقرأ smaps وتبطّئ الاستدلال. */
    private fun readRssMb(): Long = try {
        java.io.File("/proc/self/statm").readText().trim().split(' ')[1].toLong() * 4096L / 1048576L
    } catch (_: Exception) { -1L }

    /** مجموع زمن المعالج للعملية (utime+stime) بوحدات 10ms، أو -1. */
    private fun readCpuTicks(): Long = try {
        val f = java.io.File("/proc/self/stat").readText().substringAfterLast(')').trim().split(' ')
        f[11].toLong() + f[12].toLong()
    } catch (_: Exception) { -1L }

    /** يفرّغ النموذج من الرام بعد مدة خمول (إعداد المستخدم) كي لا يستهلك الذاكرة وهو غير مستعمل. */
    private fun scheduleIdleUnload() {
        idleJob?.cancel()
        val mins = Settings.idleMinutes(this)
        if (mins <= 0) return
        idleJob = scope.launch {
            kotlinx.coroutines.delay(mins * 60_000L)
            if (job?.isActive != true && llm.isLoaded()) {
                llm.unload()
                updateNote("النموذج مُفرَّغ من الرام (خامل). يُحمَّل تلقائيًا عند أول طلب.")
            }
        }
    }

    private fun notifyAsk(title: String, detail: String) {
        try {
            val pi = android.app.PendingIntent.getActivity(
                this, 1, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
                android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT)
            val n = Notification.Builder(this, "dirgham_done")
                .setContentTitle("ضرغام كود يحتاج موافقتك")
                .setContentText(title + ": " + detail.take(80))
                .setStyle(Notification.BigTextStyle().bigText(title + "\n" + detail.take(300)))
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentIntent(pi).setAutoCancel(true).build()
            getSystemService(NotificationManager::class.java).notify(3, n)
        } catch (_: Exception) {}
    }

    private fun runTask(prompt: String) {
        idleJob?.cancel()
        llm.abort()
        job?.cancel()
        startStats()
        job = scope.launch {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val w = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "dirgham:task")
            w.acquire(30 * 60 * 1000L)
            wake = w
            try {
                if (prompt.trim() == "/diag") agent.diagnose()
                else agent.run(prompt, Settings.thinking(this@AgentService))
                Bus.emit("done")
                notifyDone("اكتملت المهمة", prompt.trim().take(80))
            } catch (e: CancellationException) {
                Bus.emit("status", "أُلغيت المهمة")
                Bus.emit("done")
            } catch (e: Throwable) {
                Bus.emit("error", e.message ?: "خطأ غير معروف")
                notifyDone("تعذّرت المهمة", e.message ?: "")
            } finally {
                if (w.isHeld) w.release()
                statsJob?.cancel()
                Crash.mark("idle")
                scheduleIdleUnload()
            }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        Downloads.notify = null
        llm.unload()
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null
}
