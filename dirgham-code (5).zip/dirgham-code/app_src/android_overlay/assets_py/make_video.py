#!/usr/bin/env python3
# Dirgham Code - مولّد فيديو حواري بسيط: شخصيتان + فقاعات كلام + عنوان، ثم MP4 عبر ffmpeg.
# الاستعمال: make_video.py spec.json out.mp4
import json, math, os, subprocess, sys, glob
from PIL import Image, ImageDraw, ImageFont

try:
    import arabic_reshaper
    from bidi.algorithm import get_display
    def shape(s):
        return get_display(arabic_reshaper.reshape(s))
except Exception:
    def shape(s):
        return s

spec = json.load(open(sys.argv[1], encoding="utf-8"))
out = sys.argv[2]
W = int(spec.get("w", 960)); H = int(spec.get("h", 540)); FPS = int(spec.get("fps", 20))
scenes = spec.get("scenes") or []
names = spec.get("names") or {}
title = spec.get("title", "")
if not scenes:
    sys.exit("no scenes")

def find_font():
    c = ["/system/fonts/NotoNaskhArabic-Regular.ttf", "/system/fonts/NotoSansArabic-Regular.ttf",
         "/system/fonts/NotoNaskhArabicUI-Regular.ttf", "/system/fonts/DroidNaskh-Regular.ttf"]
    c += sorted(glob.glob("/system/fonts/*Arab*.ttf")) + ["/system/fonts/Roboto-Regular.ttf",
         "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"]
    for f in c:
        if os.path.exists(f):
            return f
    return None
FP = find_font()
def font(sz):
    return ImageFont.truetype(FP, sz) if FP else ImageFont.load_default()
F_TXT = font(int(H * 0.058)); F_NAME = font(int(H * 0.04)); F_TTL = font(int(H * 0.09))

# توزيع الزمن: إن وُجد صوت نمدّد المشاهد لتطابق مدته
dur = [max(1.5, float(s.get("sec", 4))) for s in scenes]
audio = spec.get("audio")
if audio and os.path.exists(os.path.expanduser(audio)):
    audio = os.path.expanduser(audio)
    try:
        d = float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                                           "-of", "csv=p=0", audio]).decode().strip())
        tot = sum(dur)
        if d > tot:
            dur = [x * d / tot for x in dur]
    except Exception:
        audio = None
else:
    audio = None

def hexrgb(h, d=(24, 32, 56)):
    try:
        h = h.lstrip("#"); return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
    except Exception:
        return d

def gradient(c1, c2):
    im = Image.new("RGB", (W, H), c1); px = ImageDraw.Draw(im)
    for y in range(H):
        t = y / H
        px.line([(0, y), (W, y)], fill=tuple(int(c1[i] * (1 - t) + c2[i] * t) for i in range(3)))
    return im

def wrap(text, f, maxw, dr):
    words, lines, cur = text.split(), [], []
    for w in words:
        t = " ".join(cur + [w])
        if cur and dr.textlength(shape(t), font=f) > maxw:
            lines.append(" ".join(cur)); cur = [w]
        else:
            cur.append(w)
    if cur: lines.append(" ".join(cur))
    return lines

COL = {"A": (255, 140, 60), "B": (60, 200, 170)}
def character(dr, cx, base, col, t, talking):
    bob = math.sin(t * 6) * (H * 0.008)
    hr = H * 0.085; by = base + bob
    dr.rounded_rectangle([cx - hr * 1.1, by - hr * 0.2, cx + hr * 1.1, by + hr * 2.0], radius=int(hr * 0.5), fill=col)
    dr.ellipse([cx - hr, by - hr * 2.2, cx + hr, by - hr * 0.2], fill=(250, 220, 190))
    for ex in (-0.38, 0.38):
        dr.ellipse([cx + ex * hr - 6, by - hr * 1.4 - 6, cx + ex * hr + 6, by - hr * 1.4 + 6], fill=(30, 30, 40))
    m = (abs(math.sin(t * 14)) * hr * 0.25 + 3) if talking else 3
    dr.ellipse([cx - hr * 0.3, by - hr * 0.8, cx + hr * 0.3, by - hr * 0.8 + m * 2], fill=(120, 40, 40))

cmd = ["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-"]
if audio: cmd += ["-i", audio]
cmd += ["-c:v", "libx264", "-preset", "veryfast", "-pix_fmt", "yuv420p"]
if audio: cmd += ["-c:a", "aac", "-shortest"]
cmd += [out]
pipe = subprocess.Popen(cmd, stdin=subprocess.PIPE)

def emit(img):
    pipe.stdin.write(img.tobytes())

if title:  # مشهد العنوان
    bg = gradient((20, 24, 44), (60, 30, 20))
    for i in range(int(FPS * 2)):
        a = min(1.0, i / (FPS * 0.8)); im = bg.copy(); dr = ImageDraw.Draw(im)
        s = shape(title); w = dr.textlength(s, font=F_TTL)
        dr.text(((W - w) / 2, H * 0.4 + (1 - a) * 30), s, font=F_TTL, fill=tuple(int(255 * a) for _ in range(3)))
        emit(im)

for sc, secs in zip(scenes, dur):
    bgc = hexrgb(sc.get("bg", "#16203a")); bg = gradient(bgc, tuple(max(0, c - 30) for c in bgc))
    sp = str(sc.get("speaker", "narrator")); text = str(sc.get("text", ""))
    n = int(secs * FPS)
    for i in range(n):
        t = i / FPS; im = bg.copy(); dr = ImageDraw.Draw(im)
        if sp in ("A", "B"):
            character(dr, W * 0.2, H * 0.62, COL["A"], t, sp == "A")
            character(dr, W * 0.8, H * 0.62, COL["B"], t, sp == "B")
            nm = names.get(sp, sp); s = shape(nm)
            dr.text((W * (0.2 if sp == "A" else 0.8) - dr.textlength(s, font=F_NAME) / 2, H * 0.9), s, font=F_NAME, fill=(240, 240, 240))
        maxw = W * (0.5 if sp in ("A", "B") else 0.8)
        lines = wrap(text, F_TXT, maxw, dr)
        lh = F_TXT.size * 1.5 if hasattr(F_TXT, "size") else 28
        bh = lh * len(lines) + 30; bw = max([dr.textlength(shape(l), font=F_TXT) for l in lines] + [40]) + 50
        a = min(1.0, t / 0.5)
        bx = (W - bw) / 2; by = H * 0.14 + (1 - a) * 25
        dr.rounded_rectangle([bx, by, bx + bw, by + bh], radius=26, fill=(255, 255, 255))
        for k, l in enumerate(lines):
            s = shape(l); w = dr.textlength(s, font=F_TXT)
            dr.text(((W - w) / 2, by + 15 + k * lh), s, font=F_TXT, fill=(25, 25, 35))
        emit(im)

pipe.stdin.close(); pipe.wait()
if pipe.returncode != 0 or not os.path.exists(out):
    sys.exit("ffmpeg failed")
print("OK", out, os.path.getsize(out))
