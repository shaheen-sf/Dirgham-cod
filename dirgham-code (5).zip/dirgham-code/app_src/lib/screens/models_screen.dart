import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/agent_bridge.dart';
import '../services/chat_store.dart';
import '../theme.dart';
import '../widgets/glass.dart';
import '../widgets/pattern_background.dart';

class _Suggested {
  final String title;
  final String note;
  final String url;
  const _Suggested(this.title, this.note, this.url);
}

const _suggested = <_Suggested>[
  _Suggested('Qwen2.5 Coder 1.5B', 'كتابة الأكواد · مجرَّب ويعمل · ≈ 1.1 جيجا',
      'https://huggingface.co/Qwen/Qwen2.5-Coder-1.5B-Instruct-GGUF/resolve/main/qwen2.5-coder-1.5b-instruct-q4_k_m.gguf'),
  _Suggested('Qwen2.5 Coder 3B', 'كود أدق · ≈ 2 جيجا',
      'https://huggingface.co/Qwen/Qwen2.5-Coder-3B-Instruct-GGUF/resolve/main/qwen2.5-coder-3b-instruct-q4_k_m.gguf'),
  _Suggested('Qwen2.5 3B Instruct', 'حوار عام وأدوات بالعربية · ≈ 2 جيجا',
      'https://huggingface.co/Qwen/Qwen2.5-3B-Instruct-GGUF/resolve/main/qwen2.5-3b-instruct-q4_k_m.gguf'),
  _Suggested('Qwen2.5 Coder 0.5B', 'الأسرع جدًا · أكواد بسيطة · ≈ 0.4 جيجا',
      'https://huggingface.co/Qwen/Qwen2.5-Coder-0.5B-Instruct-GGUF/resolve/main/qwen2.5-coder-0.5b-instruct-q4_k_m.gguf'),
  _Suggested('Qwen2.5 1.5B Instruct', 'سريع · حوار عربي خفيف · ≈ 1.1 جيجا',
      'https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf'),
  _Suggested('Llama 3.2 1B', 'خفيف وسريع · إنجليزي أفضل · ≈ 0.8 جيجا',
      'https://huggingface.co/bartowski/Llama-3.2-1B-Instruct-GGUF/resolve/main/Llama-3.2-1B-Instruct-Q4_K_M.gguf'),
  _Suggested('Llama 3.2 3B', 'متوازن · حوار عام · ≈ 2 جيجا',
      'https://huggingface.co/bartowski/Llama-3.2-3B-Instruct-GGUF/resolve/main/Llama-3.2-3B-Instruct-Q4_K_M.gguf'),
  _Suggested('Gemma 2 2B', 'كتابة وشرح جيد · ≈ 1.7 جيجا',
      'https://huggingface.co/bartowski/gemma-2-2b-it-GGUF/resolve/main/gemma-2-2b-it-Q4_K_M.gguf'),
  _Suggested('SmolLM2 1.7B', 'صغير وسريع · إنجليزي · ≈ 1.1 جيجا',
      'https://huggingface.co/bartowski/SmolLM2-1.7B-Instruct-GGUF/resolve/main/SmolLM2-1.7B-Instruct-Q4_K_M.gguf'),
  _Suggested('Phi-3.5 mini', 'استدلال ومنطق · أثقل · ≈ 2.4 جيجا',
      'https://huggingface.co/bartowski/Phi-3.5-mini-instruct-GGUF/resolve/main/Phi-3.5-mini-instruct-Q4_K_M.gguf'),
  _Suggested('DeepSeek R1 Distill 1.5B', 'يفكّر قبل الجواب (تفكير) · ≈ 1.1 جيجا',
      'https://huggingface.co/bartowski/DeepSeek-R1-Distill-Qwen-1.5B-GGUF/resolve/main/DeepSeek-R1-Distill-Qwen-1.5B-Q4_K_M.gguf'),
];

class ModelsScreen extends StatefulWidget {
  final AgentBridge bridge;
  final VoidCallback? onClose;
  final VoidCallback? onDiag;
  const ModelsScreen({super.key, required this.bridge, this.onClose, this.onDiag});
  @override
  State<ModelsScreen> createState() => _ModelsScreenState();
}

class _ModelsScreenState extends State<ModelsScreen> {
  final _url = TextEditingController();
  final _ghToken = TextEditingController();
  bool _ghOn = false;
  List<Map<String, dynamic>> _skills = [];
  String? _openSkill;
  String _skillText = '';
  StreamSubscription? _sub;
  List<Map<String, dynamic>> _models = [];
  final Map<String, Map<String, dynamic>> _dl = {};
  final Map<String, String> _urls = {};
  String _dir = '';
  bool _native = true, _termux = false, _termuxPerm = false, _importing = false, _bridgeOn = false;
  String _bridgeCmd = '';
  String? _msg;

  @override
  void initState() {
    super.initState();
    _sub = widget.bridge.events.listen(_onEvent, onError: (_) {});
    _init();
  }

  @override
  void dispose() {
    _sub?.cancel();
    _url.dispose();
    _ghToken.dispose();
    super.dispose();
  }

  Future<void> _init() async {
    try {
      final dir = await widget.bridge.modelsDir();
      final n = await widget.bridge.nativeOk();
      final t = await widget.bridge.termuxInstalled();
      final p = await widget.bridge.termuxPermissionGranted();
      final bc = await widget.bridge.bridgeCommand();
      final bo = await widget.bridge.bridgeConnected();
      final gh = await widget.bridge.hasGithubToken();
      await _loadSkills();
      final dl = jsonDecode(await widget.bridge.downloadStates()) as List<dynamic>;
      for (final e in dl) {
        final m = Map<String, dynamic>.from(e as Map);
        _dl[m['name'] as String] = m;
      }
      await _reload();
      if (!mounted) return;
      setState(() {
        _dir = dir;
        _native = n;
        _termux = t;
        _termuxPerm = p;
        _bridgeCmd = bc;
        _bridgeOn = bo;
        _ghOn = gh;
      });
    } catch (e) {
      if (mounted) setState(() => _msg = '$e');
    }
  }

  Future<void> _reload() async {
    final m = await widget.bridge.listModels();
    if (mounted) setState(() => _models = m);
  }

  void _onEvent(Map e) {
    final type = e['type'] as String? ?? '';
    final text = e['text'] as String? ?? '';
    if (type == 'dl') {
      try {
        final m = Map<String, dynamic>.from(jsonDecode(text) as Map);
        if (mounted) setState(() => _dl[m['name'] as String] = m);
        if (m['status'] == 'done') _reload();
      } catch (_) {}
    } else if (type == 'status' || type == 'error') {
      if (mounted) setState(() => _msg = text);
    }
  }

  String _nameFromUrl(String url) {
    final u = Uri.tryParse(url);
    final seg = (u != null && u.pathSegments.isNotEmpty) ? u.pathSegments.last : '';
    return Uri.decodeComponent(seg);
  }

  Future<void> _startDownload(String rawUrl) async {
    var url = rawUrl.trim().replaceFirst('/blob/', '/resolve/');
    final name = _nameFromUrl(url);
    if (!url.startsWith('https://') || !name.toLowerCase().endsWith('.gguf')) {
      setState(() => _msg = 'الصق رابط ملف .gguf مباشر يبدأ بـ https://');
      return;
    }
    _urls[name] = url;
    setState(() {
      _msg = null;
      _dl[name] = {'name': name, 'got': 0, 'total': -1, 'status': 'running', 'msg': ''};
    });
    try {
      await widget.bridge.download(url, name);
    } catch (e) {
      setState(() => _msg = '$e');
    }
  }

  Future<void> _import() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.any);
    final src = r?.files.single.path;
    if (src == null) return;
    final name = src.split('/').last;
    if (!name.toLowerCase().endsWith('.gguf')) {
      setState(() => _msg = 'اختر ملفًا بامتداد .gguf');
      return;
    }
    setState(() {
      _importing = true;
      _msg = 'جارٍ النسخ… قد يستغرق دقيقة للملفات الكبيرة';
    });
    try {
      await File(src).copy('$_dir/$name');
      _msg = 'تم استيراد $name';
    } catch (e) {
      _msg = 'فشل الاستيراد: $e';
    }
    if (mounted) setState(() => _importing = false);
    await _reload();
  }

  String _mb(num bytes) => '${(bytes / 1048576).toStringAsFixed(0)} MB';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PatternBackground(
        child: SafeArea(
          child: ListView(padding: const EdgeInsets.all(16), children: [
            Row(children: [
              GlassButton(icon: Icons.close_rounded, onTap: () => widget.onClose != null ? widget.onClose!() : Navigator.pop(context)),
              const SizedBox(width: 12),
              const Text('الأدوات والنماذج',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: DG.text)),
            ]),
            const SizedBox(height: 14),
            if (_msg != null) _note(DG.gold, _msg!),
            if (!_native)
              _note(DG.gold, 'المكتبة الأصلية غير موجودة في هذا الـ APK. أعد البناء من GitHub.'),
            _sectionTitle('النماذج المثبّتة (اختر النموذج النشط)'),
            if (_models.isEmpty)
              const GlassPanel(
                child: Text('لا توجد نماذج بعد. نزّل واحدًا من الأسفل أو الصق رابط أي نموذج GGUF.',
                    style: TextStyle(color: DG.textDim, height: 1.6)),
              ),
            for (final m in _models) _installedTile(m),
            const SizedBox(height: 4),
            if (_dl.values.any((d) => d['status'] != 'done')) ...[
              _sectionTitle('التنزيلات (تستمر في الخلفية)'),
              for (final d in _dl.values.where((d) => d['status'] != 'done')) _dlTile(d),
            ],
            _sectionTitle('إضافة نموذج'),
            GlassPanel(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('الصق رابط أي نموذج GGUF من Hugging Face (يعمل مع أي نموذج: Qwen وLlama وGemma وPhi وغيرها)',
                    style: TextStyle(color: DG.textDim, fontSize: 12.5, height: 1.6)),
                const SizedBox(height: 8),
                TextField(
                  controller: _url,
                  textDirection: TextDirection.ltr,
                  style: const TextStyle(color: DG.gold, fontFamily: 'monospace', fontSize: 12),
                  decoration: const InputDecoration(
                    hintText: 'https://huggingface.co/…/resolve/main/model-Q4_K_M.gguf',
                    hintStyle: TextStyle(color: DG.textDim, fontSize: 11.5),
                    border: InputBorder.none,
                  ),
                ),
                const SizedBox(height: 6),
                Wrap(spacing: 8, runSpacing: 8, children: [
                  GlassButton(
                      icon: Icons.download_rounded,
                      label: 'تنزيل',
                      color: DG.fire,
                      onTap: () => _startDownload(_url.text)),
                  GlassButton(
                      icon: Icons.folder_open_rounded,
                      label: _importing ? 'جارٍ النسخ…' : 'استيراد من الجهاز',
                      onTap: _importing ? () {} : _import),
                ]),
                const SizedBox(height: 10),
                const Text('اقتراحات:', style: TextStyle(color: DG.textDim, fontSize: 12)),
                const SizedBox(height: 6),
                for (final s in _suggested)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: GestureDetector(
                      onTap: () => setState(() => _url.text = s.url),
                      child: Row(children: [
                        const Icon(Icons.add_circle_outline_rounded, color: DG.gold, size: 18),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text('${s.title} — ${s.note}',
                              style: const TextStyle(color: DG.text, fontSize: 13)),
                        ),
                      ]),
                    ),
                  ),
              ]),
            ),
            const SizedBox(height: 12),
            _sectionTitle('فحص النموذج'),
            GlassPanel(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text(
                    'يعرض معلومات النموذج والمعالج ويجرّب ردًّا قصيرًا بلا عشوائية. إن ظهرت كلمات عشوائية فالمشكلة في النموذج أو الملف أو بناء المكتبة، وأرسل لي النتيجة.',
                    style: TextStyle(color: DG.textDim, fontSize: 12.5, height: 1.6)),
                const SizedBox(height: 8),
                GlassButton(
                  icon: Icons.health_and_safety_outlined,
                  label: 'فحص الآن',
                  color: DG.ok,
                  onTap: () async {
                    await widget.bridge.submitTask('/diag');
                    if (mounted) { widget.onDiag != null ? widget.onDiag!() : Navigator.pop(context, 'diag'); }
                  },
                ),
              ]),
            ),
            const SizedBox(height: 12),
            _sectionTitle('Termux'),
            _termuxPanel(),
            const SizedBox(height: 12),
            _sectionTitle('المهارات المثبّتة وفائدتها'),
            _skillsPanel(),
            const SizedBox(height: 12),
            _sectionTitle('الأداء'),
            _perfPanel(),
            const SizedBox(height: 12),
            _sectionTitle('GitHub'),
            _githubPanel(),
            const SizedBox(height: 12),
            GlassPanel(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('مجلد النماذج', style: TextStyle(color: DG.text, fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                SelectableText(_dir,
                    textDirection: TextDirection.ltr,
                    style: const TextStyle(color: DG.textDim, fontSize: 11.5, fontFamily: 'monospace')),
              ]),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _sectionTitle(String t) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 10, 4, 8),
        child: Text(t, style: const TextStyle(color: DG.fire, fontWeight: FontWeight.w800, fontSize: 15)),
      );

  Widget _note(Color c, String t) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: GlassPanel(glow: c, child: Text(t, style: TextStyle(color: c, fontSize: 13, height: 1.6))),
      );

  Widget _installedTile(Map<String, dynamic> m) {
    final name = m['name'] as String;
    final active = m['active'] == true;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GlassPanel(
        glow: active ? DG.ok : null,
        child: Row(children: [
          GestureDetector(
            onTap: () async {
              await widget.bridge.setActiveModel(name);
              await _reload();
            },
            child: Icon(active ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded,
                color: active ? DG.ok : DG.textDim),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(name,
                  textDirection: TextDirection.ltr,
                  style: const TextStyle(color: DG.text, fontSize: 13, fontWeight: FontWeight.w700)),
              const SizedBox(height: 2),
              Text('${_mb(m['size'] as num)}${active ? ' · نشط' : ''}',
                  style: TextStyle(color: active ? DG.ok : DG.textDim, fontSize: 12)),
            ]),
          ),
          GestureDetector(
            onTap: () async {
              await widget.bridge.deleteModel(name);
              await _reload();
            },
            child: const Icon(Icons.delete_outline_rounded, color: DG.textDim),
          ),
        ]),
      ),
    );
  }

  Widget _dlTile(Map<String, dynamic> d) {
    final name = d['name'] as String;
    final got = (d['got'] as num).toDouble();
    final total = (d['total'] as num).toDouble();
    final status = d['status'] as String;
    final p = total > 0 ? (got / total).clamp(0.0, 1.0) : null;
    final msg = (d['msg'] as String?) ?? '';
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GlassPanel(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(name,
              textDirection: TextDirection.ltr,
              style: const TextStyle(color: DG.text, fontSize: 13, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          LinearProgressIndicator(
              value: status == 'running' ? p : (p ?? 0), color: DG.fire, backgroundColor: Colors.white12),
          const SizedBox(height: 6),
          Text(
            status == 'error'
                ? 'فشل: $msg'
                : status == 'paused'
                    ? 'متوقف ${_mb(got)}'
                    : '${_mb(got)}${total > 0 ? ' / ${_mb(total)}' : ''}${msg.isNotEmpty ? '\n$msg' : ''}',
            style: TextStyle(color: status == 'error' ? DG.gold : DG.textDim, fontSize: 12, height: 1.5),
          ),
          const SizedBox(height: 8),
          Row(children: [
            if (status == 'running')
              GlassButton(
                  icon: Icons.pause_rounded,
                  label: 'إيقاف',
                  color: DG.gold,
                  onTap: () => widget.bridge.cancelDownload(name)),
            if (status != 'running')
              GlassButton(
                  icon: Icons.play_arrow_rounded,
                  label: 'استئناف',
                  color: DG.fire,
                  onTap: () {
                    final u = _urls[name] ?? _url.text.trim();
                    if (u.isNotEmpty && _nameFromUrl(u) == name) {
                      _startDownload(u);
                    } else {
                      setState(() => _msg = 'الصق نفس رابط التنزيل في الخانة أعلاه ثم اضغط استئناف');
                    }
                  }),
          ]),
        ]),
      ),
    );
  }

  Future<void> _loadSkills() async {
    try {
      final l = await widget.bridge.listSkills();
      if (mounted) setState(() => _skills = l);
    } catch (_) {}
  }

  Widget _skillsPanel() => GlassPanel(
        blur: false,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text(
            'المهارات تعليمات يقرؤها الوكيل قبل مهام متخصصة (موشن جرافيك، تجهيز Termux، كتابة الكود…). اطلب منه «استخدم مهارة كذا» أو «ثبّت مهارة من هذا الرابط».',
            style: TextStyle(color: DG.textDim, fontSize: 12.5, height: 1.7),
          ),
          const SizedBox(height: 8),
          if (_skills.isEmpty) const Text('لا مهارات مثبّتة', style: TextStyle(color: DG.textDim)),
          for (final s in _skills)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Pressable(
                  onTap: () async {
                    final n = s['name'] as String;
                    if (_openSkill == n) {
                      setState(() => _openSkill = null);
                      return;
                    }
                    final txt = await widget.bridge.readSkill(n);
                    if (mounted) setState(() { _openSkill = n; _skillText = txt; });
                  },
                  child: Row(children: [
                    Icon((s['builtin'] == true) ? Icons.verified_rounded : Icons.extension_rounded,
                        color: (s['builtin'] == true) ? DG.gold : DG.ok, size: 20),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(s['name'] as String,
                            textDirection: TextDirection.ltr,
                            style: const TextStyle(color: DG.text, fontWeight: FontWeight.w700, fontSize: 14)),
                        Text((s['desc'] as String?)?.isNotEmpty == true ? s['desc'] as String : 'بلا وصف',
                            style: const TextStyle(color: DG.textDim, fontSize: 12, height: 1.5)),
                      ]),
                    ),
                    if (s['builtin'] != true)
                      GestureDetector(
                        onTap: () async {
                          await widget.bridge.deleteSkill(s['name'] as String);
                          await _loadSkills();
                        },
                        child: const Padding(padding: EdgeInsets.all(6), child: Icon(Icons.delete_outline_rounded, color: DG.textDim, size: 20)),
                      ),
                  ]),
                ),
                if (_openSkill == s['name'])
                  Container(
                    margin: const EdgeInsets.only(top: 6),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(12)),
                    child: Text(_skillText, style: const TextStyle(color: DG.text, fontSize: 12, height: 1.6)),
                  ),
              ]),
            ),
        ]),
      );

  Widget _perfPanel() => GlassPanel(
        blur: false,
        child: Row(children: [
          const Expanded(
            child: Text('وضع الأداء الخفيف: يوقف الضبابية وحركات الظهور لتصبح الواجهة أسلس (يُنصح به أثناء التوليد الطويل).',
                style: TextStyle(color: DG.textDim, fontSize: 12.5, height: 1.7)),
          ),
          Switch(
            value: Perf.lite,
            activeColor: DG.fire,
            onChanged: (v) async {
              await Prefs.setBool('lite', v);
              setState(() => Perf.lite = v);
            },
          ),
        ]),
      );

  Widget _githubPanel() => GlassPanel(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _row('رمز GitHub محفوظ', _ghOn),
          const SizedBox(height: 6),
          const Text(
            'للقراءة من مستودعات عامة لا تحتاج رمزًا. للكتابة وتشغيل سير العمل: أنشئ Personal access token (صلاحيات repo و workflow) والصقه هنا. يُحفظ على الجهاز فقط، وكل كتابة تطلب موافقتك.',
            style: TextStyle(color: DG.textDim, fontSize: 12.5, height: 1.7),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _ghToken,
            obscureText: true,
            textDirection: TextDirection.ltr,
            style: const TextStyle(color: DG.text, fontSize: 13),
            decoration: const InputDecoration(hintText: 'ghp_… أو github_pat_…', hintStyle: TextStyle(color: DG.textDim)),
          ),
          const SizedBox(height: 8),
          GlassButton(
            icon: Icons.save_rounded,
            label: 'حفظ الرمز',
            color: DG.fire,
            onTap: () async {
              await widget.bridge.setGithubToken(_ghToken.text.trim());
              final on = await widget.bridge.hasGithubToken();
              _ghToken.clear();
              if (mounted) setState(() { _ghOn = on; _msg = on ? 'حُفظ الرمز' : 'حُذف الرمز'; });
            },
          ),
        ]),
      );

  Widget _termuxPanel() => GlassPanel(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _row('Termux مثبّت', _termux),
          _row('إذن تشغيل الأوامر', _termuxPerm),
          _row('جسر Termux (بديل بلا إذن)', _bridgeOn),
          const SizedBox(height: 8),
          const Text('الطريقة الأسهل: جسر محلي بلا أي إذن',
              style: TextStyle(color: DG.text, fontWeight: FontWeight.w700, fontSize: 13)),
          const SizedBox(height: 4),
          const Text(
            'انسخ الأمر التالي، افتح Termux، الصقه ونفّذه مرة واحدة. ثم ارجع واضغط «تحديث» لترى الجسر متصلًا. '
            'يبقى الجسر يعمل في الخلفية داخل Termux (أعد تنفيذ الأمر إن أغلقت Termux).',
            style: TextStyle(color: DG.textDim, fontSize: 12.5, height: 1.7),
          ),
          const SizedBox(height: 8),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: Colors.black38, borderRadius: BorderRadius.circular(12)),
            child: SelectableText(
              _bridgeCmd.isEmpty ? '...' : _bridgeCmd,
              textDirection: TextDirection.ltr,
              style: const TextStyle(color: DG.gold, fontFamily: 'monospace', fontSize: 11.5, height: 1.5),
            ),
          ),
          const SizedBox(height: 8),
          GlassButton(
            icon: Icons.copy_rounded,
            label: 'نسخ أمر الجسر',
            color: DG.fire,
            onTap: () async {
              await Clipboard.setData(ClipboardData(text: _bridgeCmd));
              if (mounted) setState(() => _msg = 'نُسخ أمر الجسر');
            },
          ),
          const SizedBox(height: 14),
          const Text('أو بإذن أندرويد (إن توفّر عندك):',
              style: TextStyle(color: DG.textDim, fontSize: 12.5)),
          const SizedBox(height: 8),
          const Text('الخطوات (مرة واحدة):',
              style: TextStyle(color: DG.text, fontWeight: FontWeight.w700, fontSize: 13)),
          const SizedBox(height: 4),
          const Text(
            '١) انسخ الأمر ثم افتح Termux والصقه ونفّذه.\n'
            '٢) أغلق Termux تمامًا وافتحه من جديد.\n'
            '٣) اضغط «منح الإذن»، وإن لم تظهر نافذة فاضغط «إعدادات التطبيق» ← الأذونات ← أذونات إضافية ← «Run commands in Termux environment».\n'
            '٤) اضغط «اختبار» وسترى النتيجة بالأعلى.',
            style: TextStyle(color: DG.textDim, fontSize: 12.5, height: 1.7),
          ),
          const SizedBox(height: 8),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: Colors.black38, borderRadius: BorderRadius.circular(12)),
            child: const SelectableText(
              'mkdir -p ~/.termux; grep -qx "allow-external-apps=true" ~/.termux/termux.properties 2>/dev/null || echo "allow-external-apps=true" >> ~/.termux/termux.properties; termux-reload-settings; cat ~/.termux/termux.properties',
              textDirection: TextDirection.ltr,
              style: TextStyle(color: DG.gold, fontFamily: 'monospace', fontSize: 11.5, height: 1.5),
            ),
          ),
          const SizedBox(height: 10),
          Wrap(spacing: 8, runSpacing: 8, children: [
            GlassButton(
              icon: Icons.copy_rounded,
              label: 'نسخ الأمر',
              onTap: () async {
                await Clipboard.setData(const ClipboardData(
                    text: 'mkdir -p ~/.termux; grep -qx "allow-external-apps=true" ~/.termux/termux.properties 2>/dev/null || echo "allow-external-apps=true" >> ~/.termux/termux.properties; termux-reload-settings; cat ~/.termux/termux.properties'));
                if (mounted) setState(() => _msg = 'نُسخ الأمر');
              },
            ),
            GlassButton(
              icon: Icons.terminal_rounded,
              label: 'فتح Termux',
              onTap: () async {
                final ok = await widget.bridge.openApp('com.termux');
                if (!ok && mounted) setState(() => _msg = 'Termux غير مثبّت');
              },
            ),
            GlassButton(
              icon: Icons.verified_user_outlined,
              label: 'منح الإذن',
              color: DG.ok,
              onTap: () async {
                await widget.bridge.requestTermuxPermission();
                await Future.delayed(const Duration(seconds: 2));
                _init();
              },
            ),
            GlassButton(
                icon: Icons.settings_rounded, label: 'إعدادات التطبيق', onTap: () => widget.bridge.openAppSettings()),
            GlassButton(
              icon: Icons.play_circle_outline_rounded,
              label: 'اختبار',
              color: DG.fire,
              onTap: () => widget.bridge.termuxTest(),
            ),
            GlassButton(icon: Icons.refresh_rounded, label: 'تحديث', onTap: _init),
          ]),
        ]),
      );

  Widget _row(String k, bool ok) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(children: [
          Icon(ok ? Icons.check_circle_rounded : Icons.cancel_rounded, size: 18, color: ok ? DG.ok : DG.textDim),
          const SizedBox(width: 8),
          Text(k, style: const TextStyle(color: DG.text, fontSize: 13)),
        ]),
      );
}
