import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../theme.dart';

/// خلفية فحمية/كحلية: نقوش حضرمية (معينات ومثلثات وشريط مثلثات) مع حروف خط المسند الحقيقية
/// (Unicode: Old South Arabian، U+10A60..U+10A7C). الخط يُحمَّل من assets/musnad.ttf
/// إن وُجد (يجلبه سير العمل)، وإلا نكتفي بالنقوش الهندسية بلا مربعات فارغة.
class PatternBackground extends StatefulWidget {
  final Widget child;
  const PatternBackground({super.key, required this.child});

  @override
  State<PatternBackground> createState() => _PatternBackgroundState();
}

class _PatternBackgroundState extends State<PatternBackground> {
  static const _family = 'Musnad';
  static const _count = 28; // U+10A60..U+10A7B
  List<TextPainter>? _gold;
  List<TextPainter>? _white;

  @override
  void initState() {
    super.initState();
    _loadFont();
  }

  Future<void> _loadFont() async {
    try {
      final data = await rootBundle.load('assets/musnad.ttf');
      if (data.lengthInBytes < 10000) return;
      final loader = FontLoader(_family)..addFont(Future.value(data));
      await loader.load();
      TextPainter mk(int i, Color c) => TextPainter(
            text: TextSpan(
              text: String.fromCharCode(0x10A60 + i),
              style: TextStyle(fontFamily: _family, fontSize: 26, color: c, height: 1),
            ),
            textDirection: TextDirection.ltr,
          )..layout();
      final gold = [for (var i = 0; i < _count; i++) mk(i, DG.gold.withOpacity(0.16))];
      final white = [for (var i = 0; i < _count; i++) mk(i, DG.text.withOpacity(0.10))];
      if (mounted) setState(() { _gold = gold; _white = white; });
    } catch (_) {
      // لا خط: نبقي النقوش الهندسية فقط
    }
  }

  @override
  Widget build(BuildContext context) => Stack(children: [
        Positioned.fill(
            child: RepaintBoundary(
                child: CustomPaint(painter: _PatternPainter(_gold, _white)))),
        widget.child,
      ]);
}

class _PatternPainter extends CustomPainter {
  final List<TextPainter>? gold;
  final List<TextPainter>? white;
  const _PatternPainter(this.gold, this.white);

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    canvas.drawRect(
        rect,
        Paint()
          ..shader = const LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [DG.navy, DG.charcoal],
          ).createShader(rect));

    final line = Paint()
      ..color = DG.gold.withOpacity(0.10)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.9;
    final dot = Paint()..color = DG.text.withOpacity(0.11);

    const cell = 64.0;
    final cols = (size.width / cell).ceil() + 1;
    final rows = (size.height / cell).ceil() + 1;
    for (int j = 0; j < rows; j++) {
      for (int i = 0; i < cols; i++) {
        final c = Offset(i * cell, j * cell);
        // معيّن حضرمي مزدوج
        final d = Path()
          ..moveTo(c.dx, c.dy - 20)
          ..lineTo(c.dx + 20, c.dy)
          ..lineTo(c.dx, c.dy + 20)
          ..lineTo(c.dx - 20, c.dy)
          ..close();
        canvas.drawPath(d, line);
        canvas.drawPath(
            Path()
              ..moveTo(c.dx, c.dy - 11)
              ..lineTo(c.dx + 11, c.dy)
              ..lineTo(c.dx, c.dy + 11)
              ..lineTo(c.dx - 11, c.dy)
              ..close(),
            line);
        canvas.drawCircle(c, 2.2, dot);

        final mid = c + const Offset(cell / 2, cell / 2);
        // مثلثات الحواف على الخلايا الزوجية
        if ((i + j).isEven) {
          final t = Path()
            ..moveTo(mid.dx - 6, mid.dy + 12)
            ..lineTo(mid.dx + 6, mid.dy + 12)
            ..lineTo(mid.dx, mid.dy + 12 - 10 * math.sqrt(0.75) * 1.4)
            ..close();
          canvas.drawPath(t, line);
        }

        // حرف مسند في كل خلية (توزيع ثابت لا عشوائي)
        final g = gold, w = white;
        if (g != null && w != null) {
          final h = (i * 73856093) ^ (j * 19349663);
          final idx = (h & 0x7fffffff) % g.length;
          final tp = ((i + 2 * j) % 3 == 0 ? g : w)[idx];
          tp.paint(canvas, mid - Offset(tp.width / 2, tp.height / 2));
        } else {
          // بدون الخط: نقاط تُحاكي ترتيب المسند
          final k = (i + j) % 3;
          for (int n = 0; n <= k; n++) {
            canvas.drawCircle(mid + Offset(0, n * 6.0 - 6), 1.3, dot);
          }
        }
      }
    }

    // شريط مثلثات حضرمي أعلى الشاشة وأسفلها
    final band = Paint()
      ..color = DG.gold.withOpacity(0.13)
      ..style = PaintingStyle.fill;
    for (double x = 0; x < size.width + 16; x += 16) {
      final top = Path()
        ..moveTo(x, 0)
        ..lineTo(x + 16, 0)
        ..lineTo(x + 8, 9)
        ..close();
      canvas.drawPath(top, band);
      final bot = Path()
        ..moveTo(x, size.height)
        ..lineTo(x + 16, size.height)
        ..lineTo(x + 8, size.height - 9)
        ..close();
      canvas.drawPath(bot, band);
    }

    // تعتيم لطيف وسط الشاشة كي يبقى النص مقروءًا والنقوش أوضح عند الأطراف
    canvas.drawRect(
        rect,
        Paint()
          ..shader = RadialGradient(
            center: Alignment.center,
            radius: 0.95,
            colors: [DG.charcoal.withOpacity(0.55), DG.charcoal.withOpacity(0.0)],
          ).createShader(rect));
  }

  @override
  bool shouldRepaint(covariant _PatternPainter old) =>
      old.gold != gold || old.white != white;
}
