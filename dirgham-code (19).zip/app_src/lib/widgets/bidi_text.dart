import 'package:flutter/material.dart';
import '../theme.dart';

final _arabic = RegExp(r'[؀-ۿݐ-ݿ]');

/// نص مختلط عربي/إنجليزي: كل سطر باتجاهه الصحيح، وكتل ``` تُعرض يسارًا بخط ثابت.
class BidiText extends StatelessWidget {
  final String text;
  final TextStyle style;
  const BidiText(this.text, {super.key, required this.style});

  @override
  Widget build(BuildContext context) {
    final out = <Widget>[];
    final code = StringBuffer();
    var inCode = false;
    void flushCode() {
      if (code.isEmpty) return;
      out.add(Container(
        width: double.infinity,
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(color: Colors.black38, borderRadius: BorderRadius.circular(10)),
        child: SelectableText(code.toString().trimRight(),
            textDirection: TextDirection.ltr,
            textAlign: TextAlign.left,
            style: style.copyWith(fontFamily: 'monospace', fontSize: (style.fontSize ?? 15) - 2, color: DG.gold)),
      ));
      code.clear();
    }

    for (final line in text.split('\n')) {
      if (line.trimLeft().startsWith('```')) {
        if (inCode) { flushCode(); }
        inCode = !inCode;
        continue;
      }
      if (inCode) {
        code.writeln(line);
        continue;
      }
      if (line.trim().isEmpty) {
        out.add(const SizedBox(height: 6));
        continue;
      }
      final rtl = _arabic.hasMatch(line);
      out.add(SizedBox(
        width: double.infinity,
        child: SelectableText(line,
            textDirection: rtl ? TextDirection.rtl : TextDirection.ltr,
            textAlign: rtl ? TextAlign.right : TextAlign.left,
            style: style),
      ));
    }
    flushCode();
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: out);
  }
}
