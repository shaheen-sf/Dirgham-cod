import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:permission_handler/permission_handler.dart';
import 'screens/models_screen.dart';
import 'services/agent_bridge.dart';
import 'services/chat_store.dart';
import 'theme.dart';
import 'widgets/bidi_text.dart';
import 'widgets/glass.dart';
import 'widgets/pattern_background.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Prefs.load();
  Perf.lite = Prefs.getBool('lite', false);
  runApp(const DirghamApp());
}

class DirghamApp extends StatelessWidget {
  const DirghamApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'ضرغام كود',
        debugShowCheckedModeBanner: false,
        theme: DG.theme(),
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        home: const HomeScreen(),
      );
}

enum MsgKind { user, assistant, think, tool, status, file }

class Msg {
  final MsgKind kind;
  String text;
  bool expanded = false;
  Msg(this.kind, this.text);
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _bridge = AgentBridge();
  final _ctrl = TextEditingController();
  final _scroll = ScrollController();
  final List<Msg> _msgs = [];
  StreamSubscription? _sub;
  bool _listening = false;
  bool _busy = false;
  bool _streaming = false;
  bool _thinkStreaming = false;
  bool _speak = false;
  bool _thinking = false;
  final _sk = GlobalKey<ScaffoldState>();
  final Map<String, String> _saved = {};
  final _hk = GlobalKey();
  final _ck = GlobalKey();
  double _headerH = 80;
  double _composerH = 90;
  String _chatId = DateTime.now().millisecondsSinceEpoch.toString();

  static const _welcome =
      'أهلًا بك في ضرغام كود. أنا وكيل محلي: أكتب الملفات والأكواد، وأنفّذ الأوامر في Termux بموافقتك، وأستعمل المهارات وأصنع موشن جرافيك.\n'
      'إن لم تنزّل نموذجًا بعد فافتح «الأدوات» من الأعلى.';

  @override
  void initState() {
    _scroll.addListener(() {
      if (_scroll.hasClients) {
        final p = _scroll.position;
        _nearBottom = p.pixels >= p.maxScrollExtent - 160;
      }
    });
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      try {
        final c = await _bridge.lastCrash();
        if (c.trim().isNotEmpty && mounted) {
          await showDialog(
            context: context,
            builder: (ctx) => AlertDialog(
              backgroundColor: DG.navy,
              title: const Text('توقّف التطبيق سابقًا', style: TextStyle(color: DG.fire, fontSize: 16)),
              content: SingleChildScrollView(child: SelectableText(c, textDirection: TextDirection.ltr, style: const TextStyle(color: DG.text, fontSize: 11.5))),
              actions: [
                TextButton(onPressed: () { Clipboard.setData(ClipboardData(text: c)); Navigator.pop(ctx); }, child: const Text('نسخ وإغلاق')),
                TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إغلاق')),
              ],
            ),
          );
        }
      } catch (_) {}
    });
    _msgs.add(Msg(MsgKind.assistant, _welcome));
    _boot();
  }

  Future<void> _boot() async {
    await [Permission.microphone, Permission.notification].request();
    _sub = _bridge.events.listen(_onEvent, onError: (_) {});
    try {
      await _bridge.startService();
      final t = await _bridge.getThinking();
      if (mounted) setState(() => _thinking = t);
    } catch (_) {}
    try {
      final l = await ChatStore.all();
      if (l.isNotEmpty && _msgs.length <= 1 && mounted) _openSaved(l.first, closeSheet: false);
    } catch (_) {}
  }

  // ---------- المحادثات المتعددة ----------
  Future<void> _save() async {
    final real = _msgs.where((m) => m.kind != MsgKind.think).toList();
    final firstUser = real.where((m) => m.kind == MsgKind.user).toList();
    if (firstUser.isEmpty) return;
    var title = firstUser.first.text.replaceAll('\n', ' ').trim();
    if (title.length > 36) title = '${title.substring(0, 36)}…';
    await ChatStore.save(SavedChat(_chatId, title, 0, [for (final m in real) SavedMsg(m.kind.index, m.text)]));
  }

  String _historyJson() {
    final src = _msgs.where((m) => m.kind == MsgKind.user || m.kind == MsgKind.assistant).toList();
    final tail = src.length > 14 ? src.sublist(src.length - 14) : src;
    return jsonEncode([
      for (final m in tail)
        if (m.text.trim().isNotEmpty && m.text != _welcome)
          {'r': m.kind == MsgKind.user ? 'user' : 'assistant', 'c': m.text.length > 1500 ? m.text.substring(0, 1500) : m.text}
    ]);
  }

  void _openSaved(SavedChat c, {bool closeSheet = true}) {
    if (closeSheet) _sk.currentState?.closeEndDrawer();
    setState(() {
      _chatId = c.id;
      _msgs
        ..clear()
        ..addAll([for (final m in c.msgs) Msg(MsgKind.values[m.kind.clamp(0, MsgKind.values.length - 1)], m.text)]);
      if (_msgs.isEmpty) _msgs.add(Msg(MsgKind.assistant, _welcome));
      _busy = false;
      _endStreams();
    });
    _bridge.restoreChat(_historyJson()).catchError((_) {});
    _toBottom();
  }

  List<SavedChat> _chatList = [];

  Future<void> _refreshChats() async {
    await _save();
    final l = await ChatStore.all();
    if (mounted) setState(() => _chatList = List.of(l));
  }

  Future<void> _openChats() async {
    await _refreshChats();
    _sk.currentState?.openEndDrawer();
  }

  /// لوحة المحادثات: تنزلق من اليسار.
  Widget _chatsDrawer() => Drawer(
        width: math.min(MediaQuery.of(context).size.width * 0.86, 400),
        backgroundColor: Colors.transparent,
        elevation: 0,
        child: PatternBackground(
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(children: [
                Row(children: [
                  const Text('المحادثات', style: TextStyle(color: DG.text, fontSize: 20, fontWeight: FontWeight.w800)),
                  const Spacer(),
                  GlassButton(
                    icon: Icons.add_rounded,
                    label: 'جديدة',
                    color: DG.fire,
                    onTap: () {
                      _sk.currentState?.closeEndDrawer();
                      _newChat();
                    },
                  ),
                ]),
                const SizedBox(height: 12),
                Expanded(
                  child: _chatList.isEmpty
                      ? const Center(child: Text('لا توجد محادثات محفوظة بعد', style: TextStyle(color: DG.textDim)))
                      : ListView.builder(
                          itemCount: _chatList.length,
                          itemBuilder: (_, i) {
                            final c = _chatList[i];
                            final cur = c.id == _chatId;
                            return Reveal(
                              key: ValueKey(c.id),
                              delayMs: 35 * i.clamp(0, 10),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(vertical: 4),
                                child: Pressable(
                                  onTap: () => _openSaved(c),
                                  child: GlassPanel(
                                    blur: false,
                                    radius: 18,
                                    glow: cur ? DG.ok : null,
                                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                                    child: Row(children: [
                                      Icon(cur ? Icons.chat_bubble_rounded : Icons.chat_bubble_outline_rounded,
                                          color: cur ? DG.ok : DG.textDim, size: 20),
                                      const SizedBox(width: 10),
                                      Expanded(
                                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                          Text(c.title,
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                              style: const TextStyle(color: DG.text, fontSize: 14.5, fontWeight: FontWeight.w600)),
                                          Text(_ago(c.ts), style: const TextStyle(color: DG.textDim, fontSize: 11.5)),
                                        ]),
                                      ),
                                      GestureDetector(
                                        onTap: () async {
                                          await ChatStore.delete(c.id);
                                          setState(() => _chatList.removeWhere((x) => x.id == c.id));
                                          if (cur && mounted) {
                                            _chatId = DateTime.now().millisecondsSinceEpoch.toString();
                                            try {
                                              await _bridge.cancel();
                                              await _bridge.newChat();
                                            } catch (_) {}
                                            setState(() {
                                              _msgs
                                                ..clear()
                                                ..add(Msg(MsgKind.assistant, _welcome));
                                              _busy = false;
                                              _endStreams();
                                            });
                                          }
                                        },
                                        child: const Padding(
                                          padding: EdgeInsets.all(6),
                                          child: Icon(Icons.delete_outline_rounded, color: DG.textDim, size: 20),
                                        ),
                                      ),
                                    ]),
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ]),
            ),
          ),
        ),
      );

  /// لوحة الإعدادات والأدوات: تنزلق من اليمين.
  Widget _settingsDrawer() => Drawer(
        width: math.min(MediaQuery.of(context).size.width * 0.94, 460),
        backgroundColor: Colors.transparent,
        elevation: 0,
        child: _settingsW,
      );

  /// نسخة واحدة ثابتة من الإعدادات: لا يُعاد بناؤها مع كل رمز يُولَّد (كان سبب تجمّد اللوحة).
  late final Widget _settingsW = RepaintBoundary(
    child: ModelsScreen(
      bridge: _bridge,
      onClose: () => _sk.currentState?.closeDrawer(),
      onDiag: () {
        _sk.currentState?.closeDrawer();
        setState(() {
          _msgs.add(Msg(MsgKind.user, 'فحص النموذج'));
          _busy = true;
          _endStreams();
        });
      },
    ),
  );

  String _ago(int ts) {
    final d = DateTime.now().difference(DateTime.fromMillisecondsSinceEpoch(ts));
    if (d.inMinutes < 1) return 'الآن';
    if (d.inMinutes < 60) return 'قبل ${d.inMinutes} دقيقة';
    if (d.inHours < 24) return 'قبل ${d.inHours} ساعة';
    return 'قبل ${d.inDays} يوم';
  }

  void _endStreams() {
    _streaming = false;
    _thinkStreaming = false;
  }

  String _tokBuf = '';
  Timer? _tokTimer;

  /// تجميع الرموز وتحديث الواجهة كل ~90ms بدل كل رمز (أخفّ بكثير على المعالج).
  String _cut(String s, int n) => s.length > n ? s.substring(0, n) : s;

  void _flushTok() {
    _tokTimer?.cancel();
    _tokTimer = null;
    if (_tokBuf.isEmpty || !mounted) return;
    final b = _tokBuf;
    _tokBuf = '';
    setState(() {
      if (_msgs.isNotEmpty && _msgs.last.kind == MsgKind.assistant) _msgs.last.text += b;
    });
    _toBottom();
  }

  void _onEvent(Map e) {
    final type = e['type'] as String? ?? '';
    if (type != 'token') _flushTok();
    final text = e['text'] as String? ?? '';
    switch (type) {
      case 'token':
        _thinkStreaming = false;
        if (!_streaming) {
          setState(() {
            _msgs.add(Msg(MsgKind.assistant, ''));
            _streaming = true;
          });
        }
        _tokBuf += text;
        _tokTimer ??= Timer(const Duration(milliseconds: 90), _flushTok);
        break;
      case 'think':
        if (!_thinkLogged) { _thinkLogged = true; _flow.add(FlowStep('think', 'يفكّر…')); }
        setState(() {
          _streaming = false;
          if (!_thinkStreaming) {
            _msgs.add(Msg(MsgKind.think, ''));
            _thinkStreaming = true;
          }
          _msgs.last.text += text;
        });
        break;
      case 'flow':
        setState(() {
          final parts = text.split('\u0001');
          _flow.add(FlowStep('plan', parts.first, parts.skip(1).toList()));
        });
        break;
      case 'tool':
        setState(() {
          if (text.startsWith('←')) {
            final last = _flow.lastWhere((f) => f.kind == 'tool' && f.state == 0, orElse: () => FlowStep('', ''));
            if (last.kind == 'tool') {
              last.state = (text.contains('ERROR') || text.contains('رفض') || text.contains('فشل')) ? 2 : 1;
              last.details.add(text.substring(1).trim());
            }
          } else if (!text.startsWith('\$')) {
            final sp = text.indexOf(' ');
            final nm = sp < 0 ? text : text.substring(0, sp);
            final args = sp < 0 ? '' : text.substring(sp + 1);
            _flow.add(FlowStep('tool', FlowStep.label(nm), args.isEmpty ? [] : [args])..tool = nm);
          }
          _endStreams();
          _msgs.add(Msg(MsgKind.tool, text));
          if (text.startsWith('←')) {
            if (_stepSt.isNotEmpty) _stepSt[_stepSt.length - 1] = (text.contains('ERROR') || text.contains('رفض') || text.contains('فشل')) ? 2 : 1;
          } else if (!text.startsWith('\$') && !text.startsWith('كُتب')) {
            _steps.add(text.split(' ').first);
            _stepSt.add(0);
          }
        });
        break;
      case 'stats':
        try {
          final j = jsonDecode(text) as Map<String, dynamic>;
          final tps = (j['tps'] as num).toDouble();
          final cpu = (j['cpu'] as num).toInt();
          setState(() => _stats = '${tps > 0 ? '${tps.toStringAsFixed(1)} رمز/ث' : '—'}  ·  RAM ${j['ram']} MB (حر ${j['free']})  ·  CPU ${cpu < 0 ? '—' : '$cpu%'}');
        } catch (_) {}
        break;
      case 'progress':
        setState(() => _progress = text);
        break;
      case 'file':
        setState(() {
          _endStreams();
          _progress = '';
          _msgs.add(Msg(MsgKind.file, text));
        });
        break;
      case 'status':
        setState(() {
          _flow.add(FlowStep('status', text));
          _endStreams();
          _msgs.add(Msg(MsgKind.status, text));
        });
        break;
      case 'transcript':
        setState(() => _ctrl.text = text);
        break;
      case 'final':
        setState(() {
          _listening = false;
          _ctrl.text = text;
        });
        _send();
        break;
      case 'voice_end':
        setState(() => _listening = false);
        break;
      case 'confirm':
        _confirmRun(text);
        break;
      case 'preview':
        _bridge.openPreview(text).catchError((_) {});
        break;
      case 'openapp':
        _bridge.openApp(text).then((ok) {
          if (!ok && mounted) setState(() => _msgs.add(Msg(MsgKind.status, 'تعذّر فتح التطبيق: $text')));
        }).catchError((_) {});
        break;
      case 'done':
        Msg? lastAssistant;
        for (var i = _msgs.length - 1; i >= 0; i--) {
          if (_msgs[i].kind == MsgKind.assistant) {
            lastAssistant = _msgs[i];
            break;
          }
        }
        setState(() {
          _busy = false;
          _progress = '';
          _endStreams();
        });
        _save();
        if (_speak && lastAssistant != null && lastAssistant.text.trim().isNotEmpty) {
          final clean = lastAssistant.text.replaceAll(RegExp(r'```[\s\S]*?```'), ' كود ');
          _bridge.speak(clean);
        }
        break;
      case 'error':
        setState(() {
          _busy = false;
          _endStreams();
          _msgs.add(Msg(MsgKind.status, text));
        });
        break;
    }
    _toBottom();
  }

  Future<void> _confirmRun(String payload) async {
    String id = '', title = 'تأكيد', detail = payload;
    try {
      final j = jsonDecode(payload) as Map<String, dynamic>;
      id = j['id'] as String? ?? '';
      title = j['title'] as String? ?? title;
      detail = j['detail'] as String? ?? '';
    } catch (_) {}
    final ok = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: GlassPanel(
          glow: DG.gold,
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(color: DG.fire, fontWeight: FontWeight.w800, fontSize: 16)),
            const SizedBox(height: 10),
            Container(
              width: double.infinity,
              constraints: const BoxConstraints(maxHeight: 220),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(color: Colors.black38, borderRadius: BorderRadius.circular(12)),
              child: SingleChildScrollView(
                child: SelectableText(detail,
                    textDirection: TextDirection.ltr,
                    style: const TextStyle(color: DG.gold, fontFamily: 'monospace', fontSize: 13)),
              ),
            ),
            const SizedBox(height: 14),
            Row(children: [
              GlassButton(
                  icon: Icons.check_rounded, label: 'موافق', color: DG.ok, onTap: () => Navigator.pop(ctx, true)),
              const SizedBox(width: 10),
              GlassButton(icon: Icons.close_rounded, label: 'رفض', onTap: () => Navigator.pop(ctx, false)),
            ]),
          ]),
        ),
      ),
    );
    try {
      await _bridge.confirmResult(id, ok == true);
    } catch (_) {}
  }

  void _toBottom() => WidgetsBinding.instance.addPostFrameCallback((_) {
        // لا نسحب المستخدم للأسفل إذا كان يقرأ أعلى المحادثة
        if (_scroll.hasClients && _nearBottom) {
          _scroll.animateTo(_scroll.position.maxScrollExtent,
              duration: const Duration(milliseconds: 220), curve: Curves.easeOut);
        }
      });

  final List<({String name, String text})> _attached = [];
  bool _importing = false;
  String _progress = '';
  String _stats = '';
  final List<FlowStep> _flow = [];
  bool _flowOpen = false;
  bool _nearBottom = true;
  bool _thinkLogged = false;
  final List<String> _steps = [];
  final List<int> _stepSt = []; // 0 جارٍ، 1 تم، 2 فشل

  Future<void> _attach() async {
    try {
      final r = await FilePicker.platform.pickFiles(allowMultiple: true, withData: false, type: FileType.any);
      if (r == null) return;
      for (final f in r.files) {
        final path = f.path;
        if (path == null) continue;
        if (mounted) setState(() => _importing = true);
        try {
          final d = await _bridge.importFile(path, f.name);
          if (mounted) setState(() => _attached.add((name: f.name, text: d)));
        } finally {
          if (mounted) setState(() => _importing = false);
        }
      }
    } catch (e) {
      if (mounted) setState(() => _msgs.add(Msg(MsgKind.status, 'تعذّر إرفاق الملف: $e')));
    }
  }

  Future<void> _send() async {
    final typed = _ctrl.text.trim();
    if ((typed.isEmpty && _attached.isEmpty) || _busy) return;
    await _bridge.stopSpeak();
    final att = List.of(_attached);
    final shown = [
      if (typed.isNotEmpty) typed,
      for (final a in att) '📎 ${a.name}',
    ].join('\n');
    final task = [
      if (typed.isNotEmpty) typed,
      for (final a in att) a.text,
    ].join('\n\n');
    setState(() {
      _msgs.add(Msg(MsgKind.user, shown));
      _busy = true;
      _progress = '';
      _steps.clear();
      _stepSt.clear();
      _flow.clear();
      _thinkLogged = false;
      _nearBottom = true;
      _stats = '';
      _endStreams();
      _ctrl.clear();
      _attached.clear();
    });
    _toBottom();
    try {
      await _bridge.submitTask(task);
    } catch (_) {
      setState(() => _busy = false);
    }
  }

  Future<void> _toggleMic() async {
    if (_busy) return;
    final next = !_listening;
    setState(() => _listening = next);
    try {
      next ? await _bridge.startListening() : await _bridge.stopListening();
    } catch (_) {
      setState(() => _listening = false);
    }
  }

  Future<void> _openTools() async {
    _sk.currentState?.openDrawer();
  }

  Future<void> _newChat() async {
    await _save();
    _chatId = DateTime.now().millisecondsSinceEpoch.toString();
    try {
      await _bridge.cancel();
      await _bridge.newChat();
    } catch (_) {}
    setState(() {
      _msgs
        ..clear()
        ..add(Msg(MsgKind.assistant, _welcome));
      _busy = false;
      _endStreams();
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    _ctrl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _sk,
      drawer: _settingsDrawer(),
      endDrawer: _chatsDrawer(),
      onEndDrawerChanged: (open) {
        if (open) _refreshChats();
      },
      drawerScrimColor: Colors.black54,
      body: PatternBackground(
        child: SafeArea(
          child: LayoutBuilder(builder: (context, _) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              final h = _hk.currentContext?.size?.height;
              final c = _ck.currentContext?.size?.height;
              if (mounted && h != null && c != null && ((h - _headerH).abs() > 1 || (c - _composerH).abs() > 1)) {
                setState(() {
                  _headerH = h;
                  _composerH = c;
                });
              }
            });
            return Stack(children: [
              Positioned.fill(child: _list()),
              Positioned(top: 0, left: 0, right: 0, child: KeyedSubtree(key: _hk, child: _header())),
              Positioned(bottom: 0, left: 0, right: 0, child: KeyedSubtree(key: _ck, child: _composer())),
            ]);
          }),
        ),
      ),
    );
  }

  Widget _icon(IconData i, Color c, VoidCallback onTap, String tip) => Tooltip(
        message: tip,
        child: Pressable(
          onTap: onTap,
          glow: c,
          child: Padding(padding: const EdgeInsets.all(7), child: Icon(i, color: c, size: 24)),
        ),
      );

  Widget _header() => Column(mainAxisSize: MainAxisSize.min, children: [
        _headerBar(),
        if (_busy || _flow.isNotEmpty) _statusStrip(),
      ]);

  Widget _headerBar() => Padding(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
        child: GlassPanel(
          glow: DG.fire,
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          child: Row(children: [
            _icon(Icons.tune_rounded, DG.gold, _openTools, 'الإعدادات والأدوات'),
            const SizedBox(width: 4),
            Container(
              width: 9,
              height: 9,
              decoration: BoxDecoration(
                color: _busy ? DG.gold : DG.ok,
                shape: BoxShape.circle,
                boxShadow: [BoxShadow(color: (_busy ? DG.gold : DG.ok).withOpacity(0.7), blurRadius: 7)],
              ),
            ),
            const SizedBox(width: 8),
            const Text('ضرغام', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: DG.text)),
            const Text(' كود', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: DG.fire)),
            const Spacer(),
            _icon(Icons.add_comment_outlined, DG.text, _newChat, 'محادثة جديدة'),
            _icon(Icons.forum_outlined, DG.text, _openChats, 'المحادثات'),
            PopupMenuButton<String>(
              color: const Color(0xFF1B2338),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              icon: const Icon(Icons.more_vert_rounded, color: DG.text, size: 24),
              onSelected: (v) async {
                if (v == 'think') {
                  final n = !_thinking;
                  setState(() => _thinking = n);
                  try {
                    await _bridge.setThinking(n);
                  } catch (_) {}
                } else if (v == 'speak') {
                  setState(() => _speak = !_speak);
                }
              },
              itemBuilder: (_) => [
                PopupMenuItem(
                  value: 'think',
                  child: Row(children: [
                    Icon(Icons.psychology_alt_rounded, color: _thinking ? DG.fire : DG.textDim, size: 20),
                    const SizedBox(width: 10),
                    Text(_thinking ? 'التفكير: مفعّل (أبطأ)' : 'التفكير: متوقف', style: const TextStyle(color: DG.text)),
                  ]),
                ),
                PopupMenuItem(
                  value: 'speak',
                  child: Row(children: [
                    Icon(_speak ? Icons.volume_up_rounded : Icons.volume_off_rounded, color: _speak ? DG.ok : DG.textDim, size: 20),
                    const SizedBox(width: 10),
                    Text(_speak ? 'النطق: مفعّل' : 'النطق: متوقف', style: const TextStyle(color: DG.text)),
                  ]),
                ),
              ],
            ),
          ]),
        ),
      );


  String _flowSummary() {
    if (_flow.isEmpty) return 'سير العمل';
    final n = <String, int>{};
    for (final f in _flow) {
      if (f.kind == 'tool') n[f.title] = (n[f.title] ?? 0) + 1;
    }
    final parts = n.entries.map((e) => e.value > 1 ? '${e.key} ×${e.value}' : e.key).toList();
    final head = '${_flow.length} خطوة';
    return parts.isEmpty ? head : '$head: ${parts.take(3).join('، ')}${parts.length > 3 ? '…' : ''}';
  }

  Widget _flowRow(FlowStep f) {
    final icon = f.kind == 'tool'
        ? (f.state == 1 ? Icons.check_circle_rounded : f.state == 2 ? Icons.error_rounded : Icons.autorenew_rounded)
        : f.kind == 'plan' ? Icons.lightbulb_rounded : f.kind == 'think' ? Icons.psychology_rounded : Icons.circle;
    final col = f.kind == 'tool' ? (f.state == 1 ? DG.ok : f.state == 2 ? DG.fire : DG.gold) : f.kind == 'plan' ? DG.gold : DG.textDim;
    final can = f.details.isNotEmpty;
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      InkWell(
        onTap: can ? () => setState(() => f.open = !f.open) : null,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 5),
          child: Row(children: [
            Icon(icon, size: f.kind == 'status' ? 7 : 16, color: col),
            const SizedBox(width: 8),
            Expanded(child: Text(f.title, maxLines: f.open ? 6 : 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: f.kind == 'status' ? DG.textDim : DG.text, fontSize: 12.5))),
            if (can) Icon(f.open ? Icons.keyboard_arrow_up_rounded : Icons.keyboard_arrow_down_rounded, size: 18, color: DG.textDim),
          ]),
        ),
      ),
      if (f.open)
        Container(
          margin: const EdgeInsetsDirectional.only(start: 7, bottom: 4),
          padding: const EdgeInsetsDirectional.only(start: 14),
          decoration: BoxDecoration(border: BorderDirectional(start: BorderSide(color: col.withOpacity(.4), width: 1.5))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            for (final d in f.details)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 3),
                child: Text(d,
                    maxLines: 14,
                    overflow: TextOverflow.ellipsis,
                    textDirection: f.kind == 'tool' ? TextDirection.ltr : null,
                    style: TextStyle(color: DG.textDim, fontSize: 11.5, height: 1.45, fontFamily: f.kind == 'tool' ? 'monospace' : null)),
              ),
          ]),
        ),
    ]);
  }

  Widget _statusStrip() => Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 4),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(
            color: const Color(0xE60B1020),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: DG.gold.withOpacity(.35)),
          ),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () => setState(() => _flowOpen = !_flowOpen),
              child: Row(children: [
                Icon(_flowOpen ? Icons.keyboard_arrow_up_rounded : Icons.keyboard_arrow_down_rounded, color: DG.gold, size: 22),
                const SizedBox(width: 4),
                Flexible(child: Text(_flowSummary(), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: DG.gold, fontSize: 12.5, fontWeight: FontWeight.w700))),
                const SizedBox(width: 10),
                if (_busy && _stats.isNotEmpty)
                  Expanded(
                    child: Directionality(
                      textDirection: TextDirection.ltr,
                      child: Text(_stats,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: DG.textDim, fontSize: 11, fontFamily: 'monospace')),
                    ),
                  )
                else
                  const Spacer(),
              ]),
            ),
            if (_steps.isNotEmpty && _busy)
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                reverse: true,
                child: Row(children: [
                  for (var i = 0; i < _steps.length; i++) ...[
                    if (i > 0) const Text('  ›  ', style: TextStyle(color: DG.textDim, fontSize: 12)),
                    Text(
                      '${_stepSt[i] == 1 ? '✓' : _stepSt[i] == 2 ? '✗' : '●'} ${_steps[i]}',
                      textDirection: TextDirection.ltr,
                      style: TextStyle(
                          color: _stepSt[i] == 1 ? DG.ok : _stepSt[i] == 2 ? DG.fire : DG.gold,
                          fontSize: 12.5,
                          fontWeight: FontWeight.w700),
                    ),
                  ],
                ]),
              ),
            if (_flowOpen)
              ConstrainedBox(
                constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * .5),
                child: _flow.isEmpty
                    ? const Padding(padding: EdgeInsets.all(8), child: Text('لا توجد خطوات بعد.', style: TextStyle(color: DG.textDim, fontSize: 12)))
                    : ListView(
                        shrinkWrap: true,
                        padding: const EdgeInsets.only(top: 6),
                        children: [for (final f in _flow) _flowRow(f)],
                      ),
              ),
          ]),
        ),
      );

  Widget _list() => ListView.builder(
        controller: _scroll,
        padding: EdgeInsets.fromLTRB(16, _headerH + 4, 16, _composerH + 4),
        itemCount: _msgs.length + ((_busy && !_streaming && !_thinkStreaming) ? 1 : 0),
        itemBuilder: (_, i) => i >= _msgs.length ? _typing() : Reveal(key: ObjectKey(_msgs[i]), child: _bubble(_msgs[i])),
      );

  Widget _typing() => Align(
        alignment: Alignment.centerLeft,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: GlassPanel(blur: false, 
            radius: 18,
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              const SizedBox(
                  width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: DG.gold)),
              const SizedBox(width: 10),
              Text(_progress.isEmpty ? 'يعمل…' : _progress, style: const TextStyle(color: DG.gold, fontSize: 13)),
            ]),
          ),
        ),
      );

  Widget _bubble(Msg m) {
    final maxW = MediaQuery.of(context).size.width;
    switch (m.kind) {
      case MsgKind.user:
        return Align(
          alignment: Alignment.centerRight,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 5),
            child: ConstrainedBox(
              constraints: BoxConstraints(maxWidth: maxW * .82),
              child: GlassPanel(blur: false, 
                glow: DG.fire,
                child: Text(m.text, style: const TextStyle(color: DG.text, fontSize: 15, height: 1.6)),
              ),
            ),
          ),
        );
      case MsgKind.think:
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: GestureDetector(
            onTap: () => setState(() => m.expanded = !m.expanded),
            child: GlassPanel(blur: false, 
              radius: 16,
              padding: const EdgeInsets.all(10),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Icon(Icons.psychology_alt_rounded, color: DG.textDim, size: 18),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(m.text.trim().isEmpty ? 'يفكّر…' : m.text.trim(),
                      maxLines: m.expanded ? null : 3,
                      overflow: m.expanded ? TextOverflow.visible : TextOverflow.ellipsis,
                      style: const TextStyle(
                          color: DG.textDim, fontSize: 12.5, height: 1.6, fontStyle: FontStyle.italic)),
                ),
              ]),
            ),
          ),
        );
      case MsgKind.tool:
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 5),
          child: GlassPanel(blur: false, 
            radius: 16,
            child: Row(children: [
              const Icon(Icons.terminal_rounded, color: DG.gold, size: 18),
              const SizedBox(width: 8),
              Expanded(
                child: Text(m.text,
                    textDirection: TextDirection.ltr,
                    style: const TextStyle(color: DG.gold, fontFamily: 'monospace', fontSize: 12.5)),
              ),
            ]),
          ),
        );
      case MsgKind.file:
        Map<String, dynamic> fj = {};
        try {
          fj = jsonDecode(m.text) as Map<String, dynamic>;
        } catch (_) {}
        final fname = (fj['name'] as String?) ?? 'ملف';
        final fpath = (fj['path'] as String?) ?? '';
        final fmime = (fj['mime'] as String?) ?? '*/*';
        final fsize = (fj['size'] as num?)?.toInt() ?? 0;
        final fsz = fsize >= 1048576 ? '${(fsize / 1048576).toStringAsFixed(1)} MB' : '${(fsize / 1024).ceil()} KB';
        final saved = _saved[fpath];
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: GlassPanel(
            blur: false,
            glow: DG.ok,
            child: Row(children: [
              const Icon(Icons.insert_drive_file_rounded, color: DG.ok, size: 28),
              const SizedBox(width: 10),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(fname,
                      textDirection: TextDirection.ltr,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: DG.text, fontWeight: FontWeight.w700, fontSize: 14)),
                  Text(saved == null ? '$fsz · اضغط تنزيل لحفظه' : '$fsz · حُفظ في التنزيلات/Dirgham',
                      style: const TextStyle(color: DG.textDim, fontSize: 11.5)),
                ]),
              ),
              if (saved == null)
                GlassButton(
                  icon: Icons.download_rounded,
                  label: 'تنزيل',
                  color: DG.ok,
                  onTap: () async {
                    final uri = await _bridge.saveFile(fpath, fname, fmime);
                    if (!mounted) return;
                    if (uri.isEmpty) {
                      setState(() => _msgs.add(Msg(MsgKind.status, 'تعذّر حفظ الملف (ربما حُذف). اطلب من الوكيل إنشاءه من جديد.')));
                    } else {
                      setState(() => _saved[fpath] = uri);
                    }
                  },
                )
              else ...[
                GlassButton(
                  icon: Icons.open_in_new_rounded,
                  color: DG.ok,
                  onTap: () async {
                    final ok = await _bridge.openUri(saved, fmime, false);
                    if (!ok && mounted) setState(() => _msgs.add(Msg(MsgKind.status, 'لا يوجد تطبيق يفتح هذا النوع؛ جرّب المشاركة')));
                  },
                ),
                const SizedBox(width: 6),
                GlassButton(icon: Icons.share_rounded, color: DG.gold, onTap: () => _bridge.openUri(saved, fmime, true)),
              ],
            ]),
          ),
        );
      case MsgKind.status:
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Center(
              child: Text(m.text,
                  textAlign: TextAlign.center, style: const TextStyle(color: DG.textDim, fontSize: 12))),
        );
      case MsgKind.assistant:
        return Align(
          alignment: Alignment.centerLeft,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 5),
            child: ConstrainedBox(
              constraints: BoxConstraints(maxWidth: maxW * .9),
              child: GlassPanel(blur: false, 
                child: BidiText(m.text.isEmpty ? '…' : m.text,
                    style: const TextStyle(color: DG.text, fontSize: 15, height: 1.7)),
              ),
            ),
          ),
        );
    }
  }

  Widget _composer() => Padding(
        padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          if (_importing)
            const Padding(
              padding: EdgeInsets.only(bottom: 8),
              child: Text('جارٍ تجهيز الملف…', style: TextStyle(color: DG.gold, fontSize: 12.5)),
            ),
          if (_attached.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Wrap(spacing: 8, runSpacing: 6, children: [
                for (final a in _attached)
                  InputChip(
                    label: Text(a.name, style: const TextStyle(color: DG.text, fontSize: 12)),
                    backgroundColor: Colors.white10,
                    onDeleted: () => setState(() => _attached.remove(a)),
                  ),
              ]),
            ),
          _composerRow(),
        ]),
      );

  Widget _composerRow() => Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          GlassButton(icon: Icons.attach_file_rounded, onTap: _attach),
          const SizedBox(width: 8),
          GlassButton(
              icon: _listening ? Icons.graphic_eq_rounded : Icons.mic_rounded,
              color: _listening ? DG.ok : DG.text,
              big: true,
              onTap: _toggleMic),
          const SizedBox(width: 10),
          Expanded(
            child: GlassPanel(blur: false, 
              radius: 28,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: TextField(
                controller: _ctrl,
                minLines: 1,
                maxLines: 4,
                style: const TextStyle(color: DG.text),
                decoration: InputDecoration(
                  hintText: _listening ? 'أسمعك… تحدّث الآن' : 'اكتب مهمتك…',
                  hintStyle: const TextStyle(color: DG.textDim),
                  border: InputBorder.none,
                ),
                onSubmitted: (_) => _send(),
              ),
            ),
          ),
          const SizedBox(width: 10),
          GlassButton(
              icon: _busy ? Icons.stop_rounded : Icons.arrow_upward_rounded,
              color: DG.fire,
              big: true,
              onTap: _busy ? () => _bridge.cancel() : _send),
        ]);
}


/// خطوة في سير العمل: عنوان + تفاصيل قابلة للفتح (كل تفصيلة قد تحمل تفصيلًا آخر).
class FlowStep {
  FlowStep(this.kind, this.title, [List<String>? d]) : details = d ?? [];
  final String kind; // plan | tool | think | status
  final String title;
  final List<String> details;
  String tool = '';
  int state = 0; // 0 جارية، 1 تمّت، 2 فشلت
  bool open = false;
  static String label(String n) {
    const m = {
      'read_file': 'قرأ ملفًا', 'write_file': 'كتب ملفًا', 'list_files': 'استعرض الملفات', 'run_shell': 'شغّل أمرًا',
      'web_search': 'بحث في الويب', 'fetch_url': 'قرأ صفحة', 'make_video': 'أنشأ فيديو', 'make_image': 'رسم صورة',
      'image_info': 'حلّل صورة', 'image_edit': 'عدّل صورة', 'tts': 'ولّد صوتًا', 'transcribe': 'فرّغ صوتًا',
      'use_skill': 'استخدم مهارة', 'github': 'GitHub', 'open_app': 'فتح تطبيق', 'ask_user': 'سأل المستخدم',
      'describe_media': 'تعرّف على وسائط', 'audio_info': 'حلّل صوتًا',
    };
    return m[n] ?? n;
  }
}
