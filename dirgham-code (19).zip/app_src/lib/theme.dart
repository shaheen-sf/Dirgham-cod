import 'package:flutter/material.dart';

/// الهوية البصرية لضرغام كود
class DG {
  static const charcoal = Color(0xFF0E1015);
  static const navy = Color(0xFF111A2B);
  static const text = Color(0xFFF2F4F8);
  static const textDim = Color(0xFFA9B0BD);
  static const fire = Color(0xFFFF6A1A); // إبراز الكلمات المهمة
  static const ok = Color(0xFF2ECC71); // تشغيل / نجاح
  static const gold = Color(0xFFF2B83C); // عناصر تقنية / تحذير

  static ThemeData theme() => ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: charcoal,
        colorScheme: const ColorScheme.dark(primary: fire, secondary: gold),
      );
}
