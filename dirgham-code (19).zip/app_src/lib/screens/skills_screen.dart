import 'package:flutter/material.dart';
import '../services/agent_bridge.dart';
import '../theme.dart';
import '../widgets/glass.dart';
import '../widgets/pattern_background.dart';

/// صفحة المهارات: قسم مستقل داخل الإعدادات (قائمة، بحث، قراءة، حذف).
class SkillsScreen extends StatefulWidget {
  final AgentBridge bridge;
  const SkillsScreen({super.key, required this.bridge});
  @override
  State<SkillsScreen> createState() => _SkillsScreenState();
}

class _SkillsScreenState extends State<SkillsScreen> {
  List<Map<String, dynamic>> _skills = [];
  String? _openSkill;
  String _skillQ = '';
  bool _skillsAll = false;
  String _skillText = '';

  @override
  void initState() {
    super.initState();
    _loadSkills();
  }

  Future<void> _loadSkills() async {
    try {
      final l = await widget.bridge.listSkills();
      if (mounted) setState(() => _skills = l);
    } catch (_) {}
  }

  Widget _skillsPanel() => GlassPanel(
        blur: false,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text(
            'المهارات تعليمات يقرؤها الوكيل قبل مهام متخصصة (موشن جرافيك، تجهيز Termux، كتابة الكود…). اطلب منه «استخدم مهارة كذا» أو «ثبّت مهارة من هذا الرابط».',
            style: TextStyle(color: DG.textDim, fontSize: 12.5, height: 1.7),
          ),
          const SizedBox(height: 8),
          Row(children: const [
            Icon(Icons.extension_rounded, color: DG.ok, size: 16),
            SizedBox(width: 4),
            Expanded(child: Text('قطعة أحجية = مهارة ثبّتَّها أنت (يمكن حذفها بالسلة)', style: TextStyle(color: DG.textDim, fontSize: 11.5))),
          ]),
          const SizedBox(height: 2),
          Row(children: const [
            Icon(Icons.verified_rounded, color: DG.gold, size: 16),
            SizedBox(width: 4),
            Expanded(child: Text('علامة صح = مهارة مدمجة مع التطبيق (لا تُحذف)', style: TextStyle(color: DG.textDim, fontSize: 11.5))),
          ]),
          const SizedBox(height: 8),
          if (_skills.isEmpty) const Text('لا مهارات مثبّتة', style: TextStyle(color: DG.textDim)),
          if (_skills.length > 8)
            Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: TextField(
                textDirection: TextDirection.ltr,
                style: const TextStyle(color: DG.text, fontSize: 13),
                decoration: const InputDecoration(hintText: 'ابحث في المهارات…', hintStyle: TextStyle(color: DG.textDim), isDense: true),
                onChanged: (v) => setState(() => _skillQ = v.trim().toLowerCase()),
              ),
            ),
          for (final s in _skills.where((s) => _skillQ.isEmpty || ('${s['name']} ${s['desc']}').toLowerCase().contains(_skillQ)).take(_skillsAll || _skillQ.isNotEmpty ? 1000 : 12))
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Pressable(
                  onTap: () async {
                    final n = s['name'] as String;
                    if (_openSkill == n) {
                      setState(() => _openSkill = null);
                      return;
                    }
                    final txt = await widget.bridge.readSkill(n);
                    if (mounted) setState(() { _openSkill = n; _skillText = txt; });
                  },
                  child: Row(children: [
                    Icon((s['builtin'] == true) ? Icons.verified_rounded : Icons.extension_rounded,
                        color: (s['builtin'] == true) ? DG.gold : DG.ok, size: 20),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(s['name'] as String,
                            textDirection: TextDirection.ltr,
                            style: const TextStyle(color: DG.text, fontWeight: FontWeight.w700, fontSize: 14)),
                        Text((s['desc'] as String?)?.isNotEmpty == true ? s['desc'] as String : 'بلا وصف',
                            style: const TextStyle(color: DG.textDim, fontSize: 12, height: 1.5)),
                      ]),
                    ),
                    if (s['builtin'] != true)
                      GestureDetector(
                        onTap: () async {
                          await widget.bridge.deleteSkill(s['name'] as String);
                          await _loadSkills();
                        },
                        child: const Padding(padding: EdgeInsets.all(6), child: Icon(Icons.delete_outline_rounded, color: DG.textDim, size: 20)),
                      ),
                  ]),
                ),
                if (_openSkill == s['name'])
                  Container(
                    margin: const EdgeInsets.only(top: 6),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(12)),
                    child: Text(_skillText, style: const TextStyle(color: DG.text, fontSize: 12, height: 1.6)),
                  ),
              ]),
            ),
          if (!_skillsAll && _skillQ.isEmpty && _skills.length > 12)
            TextButton(onPressed: () => setState(() => _skillsAll = true), child: Text('عرض الكل (${_skills.length})')),
        ]),
      );


  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: DG.navy,
          body: PatternBackground(
            child: SafeArea(
              child: ListView(padding: const EdgeInsets.all(16), children: [
                Row(children: [
                  IconButton(icon: const Icon(Icons.arrow_forward_rounded, color: DG.text), onPressed: () => Navigator.of(context).pop()),
                  const SizedBox(width: 8),
                  Text('المهارات (${_skills.length})', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: DG.text)),
                ]),
                const SizedBox(height: 12),
                _skillsPanel(),
              ]),
            ),
          ),
        ),
      );
}
