cmake_minimum_required(VERSION 3.22.1)

# إصلاح "ninja: manifest 'build.ninja' still dirty after 100 tries":
# أي ملف إدخال طابعه الزمني أحدث من build.ninja يجعل ninja يعيد تشغيل CMake في حلقة.
# Gradle يعيد التهيئة بنفسه عند تغيّر الملفات فلا حاجة لإعادة توليد ninja الذاتية.
set(CMAKE_SUPPRESS_REGENERATION ON)

project(llama_jni LANGUAGES C CXX)

# arm64 فقط. أي معمارية أخرى تبني مكتبة فارغة كي لا يفشل البناء.
if(NOT ANDROID_ABI STREQUAL "arm64-v8a")
  add_library(llama_jni SHARED ${CMAKE_CURRENT_SOURCE_DIR}/stub.cpp)
  return()
endif()

set(CMAKE_BUILD_TYPE Release)
set(CMAKE_CXX_STANDARD 17)

set(BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_COMMON OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_TESTS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_SERVER OFF CACHE BOOL "" FORCE)
set(LLAMA_CURL OFF CACHE BOOL "" FORCE)
set(GGML_OPENMP OFF CACHE BOOL "" FORCE)
set(GGML_NATIVE OFF CACHE BOOL "" FORCE)
set(GGML_CCACHE OFF CACHE BOOL "" FORCE)
# مسارات محسّنة تُشتبه بإخراج رموز عشوائية على بعض المعالجات: نعطّلها مفضّلين الصحة
set(GGML_CPU_REPACK OFF CACHE BOOL "" FORCE)
set(GGML_LLAMAFILE OFF CACHE BOOL "" FORCE)
set(GGML_CPU_KLEIDIAI OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_NUMBER 11500 CACHE STRING "" FORCE)
set(LLAMA_BUILD_COMMIT "pinned" CACHE STRING "" FORCE)
# معمارية أساسية armv8-a (NEON) بلا أي مسارات محسّنة: الأضمن صحةً. يمكن تمرير -DDIRGHAM_ARM_ARCH=armv8.2-a+dotprod لاحقًا لسرعة أعلى.
# سرعة: dotprod متوفر في Snapdragon 888/Exynos 2100 وما بعدهما (Galaxy S21 فما فوق). يتحقق التطبيق من الدعم قبل التحميل.
if(NOT DIRGHAM_ARM_ARCH)
  set(DIRGHAM_ARM_ARCH "armv8.2-a+dotprod")
endif()
if(DIRGHAM_ARM_ARCH)
  set(GGML_CPU_ARM_ARCH "${DIRGHAM_ARM_ARCH}" CACHE STRING "" FORCE)
endif()

add_subdirectory(${CMAKE_CURRENT_SOURCE_DIR}/llama.cpp ${CMAKE_CURRENT_BINARY_DIR}/llama.cpp)

add_library(llama_jni SHARED llama_jni.cpp compute_check.cpp)
target_include_directories(llama_jni PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}/llama.cpp/include
    ${CMAKE_CURRENT_SOURCE_DIR}/llama.cpp/ggml/include)
target_link_libraries(llama_jni llama ggml log android)
