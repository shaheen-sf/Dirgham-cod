#pragma once
#include <string>
// اختبار حسابي مستقل عن أي نموذج: يقارن ggml_mul_mat بمرجع بسيط لأنواع F32 وQ8_0 وQ4_K.
std::string dg_compute_check(int n_threads);
