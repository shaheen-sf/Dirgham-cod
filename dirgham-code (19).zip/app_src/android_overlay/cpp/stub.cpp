extern "C" void dirgham_stub() {}
