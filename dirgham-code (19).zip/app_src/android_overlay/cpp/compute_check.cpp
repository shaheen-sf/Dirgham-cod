#include "compute_check.h"
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <vector>
#include "ggml.h"
#include "ggml-cpu.h"

static float rnd(uint32_t & s) {
    s = s * 1664525u + 1013904223u;
    return ((s >> 8) & 0xFFFF) / 32768.0f - 1.0f; // [-1, 1)
}

// يعيد أكبر خطأ نسبي بين ggml_mul_mat والمرجع (أو -1 عند فشل التنفيذ)
static double check_type(enum ggml_type T, int n_threads, std::string & note) {
    const int K = 256, M = 32, N = 4;
    const ggml_type_traits * tr = ggml_get_type_traits(T);
    if (!tr) { note = "no traits"; return -1; }

    ggml_init_params ip = { 16 * 1024 * 1024, nullptr, false };
    ggml_context * ctx = ggml_init(ip);
    if (!ctx) { note = "ggml_init failed"; return -1; }

    uint32_t seed = 12345;
    std::vector<float> wf((size_t) K * M), bf((size_t) K * N);
    for (auto & v : wf) v = rnd(seed);
    for (auto & v : bf) v = rnd(seed);

    ggml_tensor * W = ggml_new_tensor_2d(ctx, T, K, M);
    ggml_tensor * B = ggml_new_tensor_2d(ctx, GGML_TYPE_F32, K, N);
    if (!W || !B) { ggml_free(ctx); note = "alloc failed"; return -1; }

    const size_t row = ggml_row_size(T, K);
    std::vector<float> wd((size_t) K * M);
    for (int m = 0; m < M; m++) {
        uint8_t * dst = (uint8_t *) W->data + (size_t) m * row;
        if (T == GGML_TYPE_F32) {
            memcpy(dst, &wf[(size_t) m * K], row);
        } else {
            tr->from_float_ref(&wf[(size_t) m * K], dst, K);
        }
        if (T == GGML_TYPE_F32) {
            memcpy(&wd[(size_t) m * K], dst, row);
        } else {
            tr->to_float(dst, &wd[(size_t) m * K], K);
        }
    }
    memcpy(B->data, bf.data(), bf.size() * sizeof(float));

    ggml_tensor * R = ggml_mul_mat(ctx, W, B); // [M x N]
    ggml_cgraph * gf = ggml_new_graph(ctx);
    ggml_build_forward_expand(gf, R);
    if (ggml_graph_compute_with_ctx(ctx, gf, n_threads) != GGML_STATUS_SUCCESS) {
        ggml_free(ctx); note = "compute failed"; return -1;
    }

    double maxErr = 0, maxRef = 1e-9;
    for (int n = 0; n < N; n++) {
        for (int m = 0; m < M; m++) {
            double ref = 0;
            for (int k = 0; k < K; k++) ref += (double) wd[(size_t) m * K + k] * bf[(size_t) n * K + k];
            double got = ((const float *) R->data)[(size_t) n * M + m];
            maxErr = std::fmax(maxErr, std::fabs(got - ref));
            maxRef = std::fmax(maxRef, std::fabs(ref));
        }
    }
    ggml_free(ctx);
    return maxErr / maxRef;
}

std::string dg_compute_check(int n_threads) {
    std::string out;
    const struct { ggml_type t; const char * n; double tol; } cases[] = {
        { GGML_TYPE_F32,  "F32",  1e-4 },
        { GGML_TYPE_F16,  "F16",  1e-2 },
        { GGML_TYPE_Q8_0, "Q8_0", 3e-2 },
        { GGML_TYPE_Q4_K, "Q4_K", 8e-2 },
    };
    bool all = true;
    for (auto & c : cases) {
        std::string note;
        double e = check_type(c.t, n_threads, note);
        bool ok = e >= 0 && e < c.tol;
        all = all && ok;
        char buf[160];
        snprintf(buf, sizeof(buf), "%s %s خطأ نسبي=%.5f %s\n", ok ? "✔" : "✘", c.n, e, note.c_str());
        out += buf;
    }
    out += all ? "الحساب الرياضي سليم." : "الحساب الرياضي معطوب في هذا البناء/الجهاز.";
    return out;
}
