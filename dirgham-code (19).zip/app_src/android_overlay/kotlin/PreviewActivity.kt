package com.dirgham.code

import android.app.Activity
import android.os.Bundle
import android.webkit.WebView
import java.io.File

/** معاينة صفحات HTML التي يولّدها الوكيل (موشن جرافيك وغيره) داخل التطبيق. */
class PreviewActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val rel = intent.getStringExtra("path")
        if (rel == null) {
            finish()
            return
        }
        val root = File(filesDir, "workspace").canonicalFile
        val f = File(root, rel).canonicalFile
        if (!f.path.startsWith(root.path + File.separator) || !f.isFile) {
            finish()
            return
        }
        val wv = WebView(this)
        wv.settings.javaScriptEnabled = true
        wv.settings.allowFileAccess = false
        wv.settings.allowContentAccess = false
        wv.setBackgroundColor(0xFF0E1015.toInt())
        setContentView(wv)
        wv.loadDataWithBaseURL("https://preview.local/", f.readText(), "text/html", "utf-8", null)
    }
}
