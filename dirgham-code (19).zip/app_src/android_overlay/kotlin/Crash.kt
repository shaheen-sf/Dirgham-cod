package com.dirgham.code

import android.content.Context
import java.io.File

/**
 * صندوق أسود: يسجّل انهيارات Java في crash.log ويحفظ «آخر خطوة» في ملف؛ فإن قُتلت العملية فجأة
 * (نفاد ذاكرة أو انهيار المحرك الأصلي) تُعرض الخطوة عند الفتح التالي بدل التخمين.
 */
object Crash {
    private var dir: File? = null
    @Volatile private var prev: String = ""
    @Volatile private var lastMark = "idle"

    fun init(c: Context) {
        if (dir != null) return
        val d = c.applicationContext.filesDir
        dir = d
        prev = try { File(d, "breadcrumb.txt").readText() } catch (_: Exception) { "" }
        mark("idle")
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val stamp = java.text.SimpleDateFormat("MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date())
                File(d, "crash.log").appendText("[$stamp] thread=${t.name} last=$lastMark\n" + android.util.Log.getStackTraceString(e).take(3500) + "\n\n")
            } catch (_: Throwable) {}
            old?.uncaughtException(t, e)
        }
    }

    fun mark(s: String) {
        lastMark = s
        try { dir?.let { File(it, "breadcrumb.txt").writeText(s) } } catch (_: Exception) {}
    }

    /** تقرير آخر توقف (يُصفَّر بعد القراءة). */
    fun report(): String {
        val d = dir ?: return ""
        var out = ""
        val log = File(d, "crash.log")
        if (log.exists()) { out += log.readText().takeLast(3500); log.delete() }
        if (prev.isNotBlank() && prev != "idle") out += "\nأُغلقت العملية فجأة أثناء: $prev\n(غالبًا نفاد ذاكرة الجهاز أو انهيار في محرك النموذج)"
        prev = ""
        return out.trim()
    }
}
