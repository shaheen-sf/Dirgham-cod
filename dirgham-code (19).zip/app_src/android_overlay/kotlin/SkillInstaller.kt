package com.dirgham.code

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** تثبيت المهارات بكل ملحقاتها (references/scripts/assets…) من مجلد مفكوك أو من مستودعات GitHub. */
object SkillInstaller {
    private const val MAX_FILES = 60
    private const val MAX_FILE = 400_000L
    private const val MAX_TOTAL = 3_000_000L

    fun slug(s: String): String =
        s.lowercase().replace(Regex("[^a-z0-9_-]+"), "-").trim('-').take(40).ifEmpty { "skill" }

    fun nameOf(text: String, fallback: String): String {
        val n = Regex("(?m)^name:\\s*(.+)$").find(text)?.groupValues?.get(1)?.trim()?.trim('"', '\'')
        return slug(if (n.isNullOrBlank()) fallback else n)
    }

    private fun hasOwnSkill(root: File, f: File): Boolean {
        var p = f.parentFile
        while (p != null && p != root) { if (File(p, "SKILL.md").exists()) return true; p = p.parentFile }
        return false
    }

    /** يثبّت كل مجلد فيه SKILL.md تحت root مع ملفاته المرافقة. يعيد سطرًا لكل مهارة. */
    fun fromDir(ctx: Context, root: File): List<String> {
        val out = ArrayList<String>()
        val skills = root.walkTopDown().onEnter { it.name != "node_modules" && it.name != ".git" }
            .filter { it.isFile && it.name.equals("SKILL.md", true) }.take(80).toList()
        for (f in skills) {
            val dir = f.parentFile ?: continue
            val text = f.readText().take(80_000)
            val name = nameOf(text, if (dir == root) root.name.removeSuffix("_unzipped") else dir.name)
            val dest = File(Skills.dir(ctx), name).also { it.mkdirs() }
            File(dest, "SKILL.md").writeText(text)
            var n = 0; var total = 0L
            for (x in dir.walkTopDown().onEnter { it.name != "node_modules" && it.name != ".git" }.filter { it.isFile && it != f }) {
                if (n >= MAX_FILES || total > MAX_TOTAL) break
                if (x.length() > MAX_FILE || hasOwnSkill(dir, x)) continue
                val rel = x.relativeTo(dir).path
                if (rel.contains("..")) continue
                val t = File(dest, rel); t.parentFile?.mkdirs()
                x.copyTo(t, overwrite = true); n++; total += x.length()
            }
            out.add("$name — ${Skills.description(text).take(60)}" + (if (n > 0) " (+$n ملف مرفق)" else ""))
        }
        return out
    }

    private fun get(url: String, token: String, ms: Int = 25_000): ByteArray? = try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000; c.readTimeout = ms
        c.setRequestProperty("User-Agent", "DirghamCode")
        if (token.isNotBlank() && url.startsWith("https://api.github.com")) c.setRequestProperty("Authorization", "Bearer $token")
        if (c.responseCode in 200..299) c.inputStream.use { it.readBytes() } else null
    } catch (_: Exception) { null }

    private fun enc(p: String) = p.split('/').joinToString("/") { URLEncoder.encode(it, "UTF-8").replace("+", "%20") }

    /** مستودع واحد: يبحث عن كل SKILL.md فيه (شجرة GitHub) وينزّل ملحقاته. */
    private fun fromRepo(ctx: Context, owner: String, repo: String, token: String): List<String> {
        val out = ArrayList<String>()
        val raw = "https://raw.githubusercontent.com/$owner/$repo/HEAD/"
        val treeBytes = get("https://api.github.com/repos/$owner/$repo/git/trees/HEAD?recursive=1", token)
        val entries = ArrayList<Pair<String, Long>>()
        if (treeBytes != null) {
            try {
                val arr = JSONObject(String(treeBytes)).optJSONArray("tree")
                if (arr != null) for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    if (o.optString("type") == "blob") entries.add(o.optString("path") to o.optLong("size"))
                }
            } catch (_: Exception) {}
        }
        val skillPaths = entries.map { it.first }.filter { it == "SKILL.md" || it.endsWith("/SKILL.md") }.take(8).toMutableList()
        if (skillPaths.isEmpty() && entries.isEmpty()) {            // لا شجرة (حد المعدل): جرّب جذر المستودع فقط
            if (get(raw + "SKILL.md", token) != null) skillPaths.add("SKILL.md")
        }
        for (sp in skillPaths) {
            val text = String(get(raw + enc(sp), token) ?: continue).take(80_000)
            val prefix = sp.removeSuffix("SKILL.md")
            val name = nameOf(text, if (prefix.isEmpty()) repo else prefix.trimEnd('/').substringAfterLast('/'))
            val dest = File(Skills.dir(ctx), name).also { it.mkdirs() }
            File(dest, "SKILL.md").writeText(text)
            var n = 0; var total = 0L
            for ((p, size) in entries) {
                if (n >= 40 || total > MAX_TOTAL) break
                if (!p.startsWith(prefix) || p == sp || size > MAX_FILE) continue
                val rel = p.removePrefix(prefix)
                if (rel.contains("..") || rel.contains("node_modules/")) continue
                if (skillPaths.any { it != sp && it.removeSuffix("SKILL.md").isNotEmpty() && p.startsWith(it.removeSuffix("SKILL.md")) && it.removeSuffix("SKILL.md").length > prefix.length }) continue
                val b = get(raw + enc(p), token) ?: continue
                val t = File(dest, rel); t.parentFile?.mkdirs(); t.writeBytes(b); n++; total += b.size
            }
            out.add("$name ($owner/$repo) — ${Skills.description(text).take(50)}" + (if (n > 0) " (+$n ملف)" else ""))
        }
        return out
    }

    /** يعالج قائمة روابط GitHub بالتوازي (6 معًا). يعيد (المثبّت، عدد الروابط التي فُحصت). */
    suspend fun fromRepos(ctx: Context, links: List<String>, token: String, progress: (String) -> Unit): List<String> =
        withContext(Dispatchers.IO) {
            val sem = Semaphore(6)
            var done = 0
            coroutineScope {
                links.map { link ->
                    async {
                        sem.withPermit {
                            val m = Regex("github\\.com/([^/]+)/([^/#?]+)").find(link)
                            val r = if (m == null) emptyList() else try { fromRepo(ctx, m.groupValues[1], m.groupValues[2].removeSuffix(".git"), token) } catch (_: Exception) { emptyList() }
                            synchronized(this@SkillInstaller) { done++; progress("فحص المستودعات $done/${links.size}") }
                            r
                        }
                    }
                }.awaitAll().flatten()
            }
        }
}
