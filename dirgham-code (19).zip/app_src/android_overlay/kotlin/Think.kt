package com.dirgham.code

class Seg(val think: Boolean, val text: String)

/** يفصل كتل <think>…</think> عن النص العادي أثناء البث، حتى لو تقطّعت الوسوم بين الرموز. */
class ThinkSplitter {
    private val open = "<think>"
    private val close = "</think>"
    private var inThink = false
    private val buf = StringBuilder()

    fun feed(s: String): List<Seg> {
        buf.append(s)
        val out = ArrayList<Seg>()
        while (true) {
            val tag = if (inThink) close else open
            val i = buf.indexOf(tag)
            if (i >= 0) {
                if (i > 0) out.add(Seg(inThink, buf.substring(0, i)))
                buf.delete(0, i + tag.length)
                inThink = !inThink
                continue
            }
            val keep = tag.length - 1
            if (buf.length > keep) {
                out.add(Seg(inThink, buf.substring(0, buf.length - keep)))
                buf.delete(0, buf.length - keep)
            }
            break
        }
        return out
    }

    fun flush(): List<Seg> {
        val o = ArrayList<Seg>()
        if (buf.isNotEmpty()) o.add(Seg(inThink, buf.toString()))
        buf.setLength(0)
        return o
    }
}

/** يمنع عرض استدعاء الأداة للمستخدم (وسم <tool_call> أو كتلة JSON باسم أداة): يمرّر النص حتى يظهر ثم يتوقف. */
class ToolGate {
    private val re = Regex("<tool_call>|<tool_response|<(?:write|append)_file\\s+path|```(?:json|tool_call)?\\s*\\{\\s*\\\"name\\\"|\\{\\s*\\\"name\\\"\\s*:\\s*\\\"[a-z_]+\\\"")
    private val buf = StringBuilder()
    private var stopped = false
    val triggered: Boolean get() = stopped
    private val keep = 48

    fun feed(s: String): String {
        if (stopped) return ""
        buf.append(s)
        val m = re.find(buf)
        if (m != null) {
            val out = buf.substring(0, m.range.first)
            buf.setLength(0)
            stopped = true
            return out
        }
        if (buf.length <= keep) return ""
        val out = buf.substring(0, buf.length - keep)
        buf.delete(0, buf.length - keep)
        return out
    }

    fun flush(): String {
        if (stopped) return ""
        val o = buf.toString()
        buf.setLength(0)
        return o
    }
}
