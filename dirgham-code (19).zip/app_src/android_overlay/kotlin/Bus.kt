package com.dirgham.code

import android.os.Handler
import android.os.Looper
import io.flutter.plugin.common.EventChannel

/** ناقل أحداث واحد من الخدمة والنشاط إلى واجهة Flutter. */
object Bus {
    private val ui = Handler(Looper.getMainLooper())

    @Volatile
    var sink: EventChannel.EventSink? = null

    fun emit(type: String, text: String = "") {
        ui.post { sink?.success(mapOf("type" to type, "text" to text)) }
    }
}
