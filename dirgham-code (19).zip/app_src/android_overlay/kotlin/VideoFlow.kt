package com.dirgham.code

import org.json.JSONArray
import org.json.JSONObject

/**
 * مسار الفيديو الحتمي: طلب الفيديو يُوجَّه برمجيًا إلى make_video (لا يترك النموذج الصغير يختار بين موقع وفيديو).
 * مع صور/صوت مرفقة يُبنى المونتاج مباشرة بلا أي توليد من النموذج (دقيقة أو أقل)، كأدوات المونتاج.
 */
object VideoFlow {
    data class Att(val name: String, val where: String, val kind: String, val sec: Double, val text: String)

    private val VIDEO = Regex("(فيديو|فديو|مونتاج|كليب|مقطع\\s+(?:فيديو|فديو)|(?<![\\w/.\\-])(?:mp4|video|montage)(?![\\w/\\-]))", RegexOption.IGNORE_CASE)
    private val SITE = Regex("(موقع|صفحة|website|web\\s?page|landing)", RegexOption.IGNORE_CASE)

    /** نص تعليمة المستخدم بلا أوصاف الملفات المرفقة. */
    fun instruction(t: String): String = t.substringBefore("[attached:").trim()

    fun isVideoRequest(t: String): Boolean {
        val i = instruction(t)
        return i.isNotEmpty() && VIDEO.containsMatchIn(i) && !SITE.containsMatchIn(i)
    }

    fun parseAtts(t: String): List<Att> {
        val out = ArrayList<Att>()
        val parts = t.split("[attached:").drop(1)
        for (p in parts) {
            val m = Regex("^\\s*(.+?) -> (.+?)\\]\\s*(image|video|audio|text file|zip|binary)?([\\s\\S]*)$").find(p) ?: continue
            val kind = m.groupValues[3].ifEmpty { "binary" }
            val rest = m.groupValues[4]
            val sec = Regex("([0-9]+(?:\\.[0-9]+)?) s").find(rest.take(120))?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0
            val text = if (kind == "text file") rest.substringAfter(":\n", "").trim() else ""
            out.add(Att(m.groupValues[1].trim(), m.groupValues[2].trim(), kind, sec, text))
        }
        return out
    }

    private fun sentences(s: String): List<String> =
        s.split(Regex("(?<=[.!؟?!])\\s+|\\n+")).map { it.trim() }.filter { it.length >= 4 }.take(60)

    /** مونتاج من الصور (+ صوت اختياري + نص اختياري كترجمة). يعيد null إن لم توجد صور. */
    fun slideshow(atts: List<Att>): JSONObject? {
        val imgs = atts.filter { it.kind == "image" }
        if (imgs.isEmpty()) return null
        val audio = atts.firstOrNull { it.kind == "audio" || (it.kind == "video" && false) }
        val script = atts.firstOrNull { it.kind == "text file" }?.text.orEmpty()
        val caps = sentences(script)
        val total = if (audio != null && audio.sec > 1) audio.sec else 4.0 * imgs.size
        val scenes = JSONArray()
        if (caps.isNotEmpty()) {
            val weights = caps.map { it.length.coerceAtLeast(8).toDouble() }
            val sum = weights.sum()
            caps.forEachIndexed { i, c ->
                val img = imgs[(i * imgs.size / caps.size).coerceIn(0, imgs.size - 1)]
                scenes.put(JSONObject().put("speaker", "narrator").put("text", c).put("image", img.name)
                    .put("sec", (total * weights[i] / sum).coerceAtLeast(1.5)))
            }
        } else {
            val n = if (total / imgs.size > 10) Math.ceil(total / 6.0).toInt() else imgs.size
            for (i in 0 until n) {
                scenes.put(JSONObject().put("speaker", "narrator").put("text", "")
                    .put("image", imgs[i % imgs.size].name).put("sec", total / n))
            }
        }
        val spec = JSONObject().put("scenes", scenes)
        if (audio != null) spec.put("audio", audio.name)
        return spec
    }

    /** يستخرج أول كائن JSON متوازن من ناتج النموذج. */
    fun extractJson(s: String): JSONObject? {
        val a = s.indexOf('{')
        if (a < 0) return null
        var depth = 0
        var inStr = false
        var esc = false
        for (i in a until s.length) {
            val c = s[i]
            if (inStr) { if (esc) esc = false else if (c == '\\') esc = true else if (c == '"') inStr = false; continue }
            when (c) {
                '"' -> inStr = true
                '{' -> depth++
                '}' -> { depth--; if (depth == 0) return try { JSONObject(s.substring(a, i + 1)) } catch (_: Exception) { null } }
            }
        }
        return null
    }

    private val EDIT = Regex("(بدّل|بدل|غيّر|غير|استبدل|عدّل|عدل|replace|swap|change)", RegexOption.IGNORE_CASE)
    private val EDIT_TARGET = Regex("(شخصي|الاستاذ|الأستاذ|المعلم|المدرس|المدرّس|مدرس|الطالب|التلميذ|الراوي|الكلب|خلفي|الصورة|character|background|teacher|student)", RegexOption.IGNORE_CASE)
    private val CHARS = Regex("(شخصي|شخصيات|بطل|character)", RegexOption.IGNORE_CASE)
    private val VOICE = Regex("(صوت|تعليق|voice|narrat|نطق|تتكلم|يتكلم)", RegexOption.IGNORE_CASE)

    fun wantsCharacters(i: String) = CHARS.containsMatchIn(i)
    fun wantsVoice(i: String) = VOICE.containsMatchIn(i)

    /** طلب تعديل على فيديو سابق (لا إنشاء جديد). */
    private val STICK = Regex("(ستيكمان|stickman|stick ?man|شخصي|حوار|يقابل|قصة|حكاية|كوميد|comedy|ريلز|reel|مشهد|story|character|dialog)", RegexOption.IGNORE_CASE)
    /** طلب قصة/حوار بشخصيات مرسومة بلا صور مرفقة → ستيكمان بمفاصل. */
    fun wantsStick(t: String): Boolean = STICK.containsMatchIn(instruction(t))

    private val REPLACE = Regex("(بدل|مكان|استبدل|عوض|replace|swap|instead)", RegexOption.IGNORE_CASE)
    /** تعليمة استبدال («أضف هذي الشخصية بدل المدرس») — تعني استبدالًا لا إضافة. */
    fun isReplace(t: String): Boolean = REPLACE.containsMatchIn(norm0(instruction(t)))
    private fun norm0(s: String) = s.replace(Regex("[\\u064B-\\u0652]"), "")

    fun isVideoEdit(t: String): Boolean {
        val i = instruction(t)
        // نص طويل (وصف/إرشادات ملصقة) ليس أمر تعديل؛ التعديل جملة قصيرة
        if (i.length > 220) return false
        return i.isNotEmpty() && (EDIT.containsMatchIn(i) || isReplace(t)) && EDIT_TARGET.containsMatchIn(i) && !SITE.containsMatchIn(i) && t.contains("[attached:")
    }

    private fun norm(s: String) = s.lowercase().replace("ال", "").replace(Regex("[\\u064B-\\u0652]"), "").replace('أ', 'ا').replace('إ', 'ا').replace('ة', 'ه')

    /** يعيّن الصور كشخصيات A/B بالترتيب. */
    fun assignCharacters(spec: JSONObject, imgs: List<Att>) {
        val ch = spec.optJSONObject("characters") ?: JSONObject()
        imgs.take(2).forEachIndexed { k, im -> ch.put(if (k == 0) "A" else "B", JSONObject().put("image", im.name)) }
        spec.put("characters", ch)
    }

    /** يطبّق التعديل على المواصفات ويعيد وصفًا بما تغيّر. */
    fun applyEdit(spec: JSONObject, instr: String, imgs: List<Att>): String {
        if (imgs.isEmpty()) return "غيّرتُ الصوت فقط"
        val names = spec.optJSONObject("names") ?: JSONObject()
        val n = norm(instr)
        if (Regex("(خلفي|background)", RegexOption.IGNORE_CASE).containsMatchIn(instr) && !CHARS.containsMatchIn(instr)) {
            val sc = spec.getJSONArray("scenes")
            for (i in 0 until sc.length()) sc.getJSONObject(i).put("image", imgs[0].name)
            return "الخلفية صارت الصورة المرفقة"
        }
        var target: String? = null
        for (k in listOf("A", "B")) {
            val nm = norm(names.optString(k))
            if (nm.length >= 2 && n.contains(nm)) { target = k; break }
        }
        if (target == null && Regex("(الثاني|الطالب|التلميذ|الثانيه|second|student)", RegexOption.IGNORE_CASE).containsMatchIn(instr)) target = "B"
        if (target == null && Regex("(الاستاذ|الأستاذ|المعلم|المدرس|المدرّس|مدرس|الاول|الأول|first|teacher)", RegexOption.IGNORE_CASE).containsMatchIn(instr)) target = "A"
        val ch = spec.optJSONObject("characters") ?: JSONObject()
        if (target == null && imgs.size >= 2) {
            ch.put("A", JSONObject().put("image", imgs[0].name)); ch.put("B", JSONObject().put("image", imgs[1].name))
            spec.put("characters", ch)
            return "الشخصيتان A وB استُبدلتا بالصورتين"
        }
        val t = target ?: "A"
        ch.put(t, JSONObject().put("image", imgs[0].name))
        spec.put("characters", ch)
        return "استبدلتُ ${names.optString(t, "الشخصية $t")} بالشخصية التي أرفقتها (قصصتُ خلفيتها تلقائيًا)"
    }

    private val EDIT_ADD = Regex("(أضف|اضف|ضع|حط|زد|أدخل|ادخل|add|put)", RegexOption.IGNORE_CASE)
    private val EDIT_VID = Regex("(الفيديو|الفديو|المقطع|المشهد|المشاهد|video)", RegexOption.IGNORE_CASE)
    private val ICONS = listOf(
        Regex("(كر[ةه]\\s*(?:ال)?قدم|كر[ةه]|ball|football)", RegexOption.IGNORE_CASE) to "ball",
        Regex("(نجم[ةه]|star)", RegexOption.IGNORE_CASE) to "star",
        Regex("(قلب|heart)", RegexOption.IGNORE_CASE) to "heart",
        Regex("(شمس|sun)", RegexOption.IGNORE_CASE) to "sun",
        Regex("(قمر|هلال|moon)", RegexOption.IGNORE_CASE) to "moon",
        Regex("(شجر[ةه]|نخل[ةه]|tree)", RegexOption.IGNORE_CASE) to "tree",
        Regex("(غيم[ةه]|سحاب[ةه]|cloud)", RegexOption.IGNORE_CASE) to "cloud")

    /** طلب نصي بلا مرفقات لإضافة عنصر مرسوم للفيديو السابق («أضف كرة قدم»). */
    fun isAddToVideo(t: String): Boolean {
        val i = instruction(t)
        return i.isNotEmpty() && EDIT_ADD.containsMatchIn(i) && EDIT_VID.containsMatchIn(i) || (EDIT_ADD.containsMatchIn(i) && i.length < 40 && ICONS.any { it.first.containsMatchIn(i) })
    }

    /** يضيف أيقونة متحركة لكل المشاهد. يعيد وصف ما تغيّر أو null إن لم أعرف رسم المطلوب. */
    fun addIcon(spec: JSONObject, instr: String): String? {
        val name = ICONS.firstOrNull { it.first.containsMatchIn(instr) }?.second ?: return null
        val sc = spec.getJSONArray("scenes")
        for (k in 0 until sc.length()) {
            val s = sc.getJSONObject(k)
            val ls = s.optJSONArray("layers") ?: JSONArray()
            ls.put(JSONObject().put("type", "icon").put("name", name).put("x", if (k % 2 == 0) 0.82 else 0.18).put("y", 0.62)
                .put("w", 0.16).put("h", 0.16).put("bob", 0.04))
            s.put("layers", ls)
        }
        return "أضفتُ $name متحركة في ${sc.length()} مشهدًا"
    }

    private val ADD_CHAR = Regex("(اضف|أضف|ضيف|أضيف|حط|ضع|ادخل|أدخل|add|put|include)", RegexOption.IGNORE_CASE)
    private val CHAR_WORD = Regex("(شخصي|الصورة|الصوره|هذي|هذه|هذا|character|image|this)", RegexOption.IGNORE_CASE)

    /** إضافة صورة مرفقة (مقصوصة) كشخصية تتحرك داخل الفيديو السابق. */
    fun isAddCharacter(t: String): Boolean {
        val i = instruction(t)
        return t.contains("[attached:") && parseAtts(t).any { it.kind == "image" } && ADD_CHAR.containsMatchIn(i) && CHAR_WORD.containsMatchIn(i) && !isReplace(t) && i.length <= 220 && !SITE.containsMatchIn(i)
    }

    fun addCharacter(spec: JSONObject, img: Att): String {
        val sc = spec.getJSONArray("scenes")
        var withDog = false
        for (k in 0 until sc.length()) {
            val s = sc.getJSONObject(k)
            val ls = s.optJSONArray("layers") ?: JSONArray()
            var ph = k.toDouble(); var amp = 0.28; var hz = 0.22
            for (j in 0 until ls.length()) {
                val l = ls.getJSONObject(j)
                if (l.optString("name") == "dog") {
                    withDog = true
                    l.optJSONArray("osc")?.optJSONObject(0)?.let { o -> ph = o.optDouble("ph", ph); amp = o.optDouble("amp", amp); hz = o.optDouble("hz", hz) }
                }
            }
            // الشخصية تركض خلف الكلب (فارق طور) وتنعكس عند تغيّر الاتجاه
            ls.put(JSONObject().put("type", "image").put("src", img.name).put("cutout", true).put("face", true)
                .put("x", 0.5).put("y", 0.55).put("h", 0.46).put("bob", 0.02)
                .put("osc", JSONArray().put(JSONObject().put("p", "x").put("amp", amp).put("hz", hz).put("ph", ph - 0.9))))
            s.put("layers", ls)
        }
        return "أضفتُ الشخصية التي أرفقتها (بعد قصّ الخلفية) " + (if (withDog) "تركض خلف الكلب" else "تتحرك") + " في ${sc.length()} " + (if (sc.length() <= 10) "مشاهد" else "مشهدًا")
    }
}
