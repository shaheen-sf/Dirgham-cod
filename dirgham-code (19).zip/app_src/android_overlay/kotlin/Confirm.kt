package com.dirgham.code

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

/**
 * طلب موافقة من المستخدم قبل أي عمل حساس. تُعرض نافذة في الواجهة ويُنتظر الرد.
 * إن كان التطبيق في الخلفية يُرسل إشعار «يحتاج موافقتك» ويستمر الانتظار (حتى 15 دقيقة) بدل الرفض الصامت،
 * وتُعاد النافذة تلقائيًا عند فتح التطبيق.
 */
object Confirm {
    private class Req(val title: String, val detail: String, val d: CompletableDeferred<Boolean>)
    private val pending = ConcurrentHashMap<String, Req>()

    /** يُضبط من AgentService لإظهار إشعار عند غياب الواجهة. */
    @Volatile var notifier: ((String, String) -> Unit)? = null

    private fun emit(id: String, r: Req) {
        Bus.emit("confirm", JSONObject().put("id", id).put("title", r.title).put("detail", r.detail).toString())
    }

    suspend fun ask(title: String, detail: String): Boolean {
        val id = System.nanoTime().toString()
        val r = Req(title, detail, CompletableDeferred())
        pending[id] = r
        emit(id, r)
        if (!MainActivity.visible) notifier?.invoke(title, detail)
        val ok = withTimeoutOrNull(900_000L) { r.d.await() } ?: false
        pending.remove(id)
        return ok
    }

    /** عند عودة المستخدم للتطبيق: أعد عرض الطلبات المعلّقة. */
    fun replay() {
        pending.forEach { (id, r) -> if (!r.d.isCompleted) emit(id, r) }
    }

    fun answer(id: String, ok: Boolean) {
        pending[id]?.d?.complete(ok)
    }
}
