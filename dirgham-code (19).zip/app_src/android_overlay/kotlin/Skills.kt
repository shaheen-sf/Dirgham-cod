package com.dirgham.code

import android.content.Context
import java.io.File

/** المهارات: ملفات SKILL.md يقرؤها الوكيل عند الحاجة. تُثبَّت من رابط أو نص، وتُحفظ في التخزين الداخلي. */
object Skills {
    fun dir(c: Context): File = File(c.filesDir, "skills").also { it.mkdirs() }

    fun ensureBuiltins(c: Context) {
        for ((name, text) in BUILTIN) {
            val d = File(dir(c), name)
            d.mkdirs()
            File(d, "SKILL.md").writeText(text)
        }
    }

    fun description(c: Context, name: String): String {
        val txt = read(c, name) ?: return ""
        return description(txt)
    }

    /** ملفات المهارة المرافقة (references/scripts…) كمسارات نسبية. */
    fun companions(c: Context, name: String): List<String> {
        if (!name.matches(Regex("[A-Za-z0-9_-]{1,60}"))) return emptyList()
        val root = File(dir(c), name)
        return root.walkTopDown().filter { it.isFile && it.name != "SKILL.md" }.take(40).map { it.relativeTo(root).path }.toList()
    }

    fun readFile(c: Context, name: String, rel: String): String? {
        if (!name.matches(Regex("[A-Za-z0-9_-]{1,60}")) || rel.contains("..")) return null
        val root = File(dir(c), name).canonicalFile
        val f = File(root, rel).canonicalFile
        return if (f.path.startsWith(root.path) && f.isFile && f.length() < 400_000) f.readText() else null
    }

    /** فهرس مختصر للنموذج (اسم + وصف قصير) بحجم محدود كي لا يتضخم السياق. */
    fun catalog(c: Context, maxChars: Int = 2400): String {
        val sb = StringBuilder()
        for (n in names(c)) {
            val line = "- $n: " + description(c, n).take(70) + "\n"
            if (sb.length + line.length > maxChars) { sb.append("- … (use list_skills for the rest)\n"); break }
            sb.append(line)
        }
        return sb.toString().trimEnd()
    }

    private val AR = mapOf(
        "فيديو" to "video", "فديو" to "video", "مونتاج" to "video montage edit", "صوت" to "audio voice tts speech", "ترجمه" to "subtitle caption transcribe translate",
        "ترجمة" to "subtitle caption transcribe translate", "صوره" to "image picture", "صورة" to "image picture", "موقع" to "website web html css", "صفحه" to "page html",
        "كود" to "code", "برمج" to "code program", "تصميم" to "design layout", "رسوم" to "animation motion", "متحرك" to "animation motion", "موشن" to "motion animation",
        "شخصيه" to "character", "شخصية" to "character", "انمي" to "anime", "أنمي" to "anime", "جيميني" to "gemini", "تطبيق" to "app", "لعبه" to "game", "لعبة" to "game")

    /** أقرب المهارات للطلب (بالكلمات المشتركة مع الاسم والوصف، مع ترجمة كلمات عربية شائعة). */
    fun relevant(c: Context, request: String, n: Int): List<String> {
        val words = HashSet<String>()
        for (w in Regex("[\\p{L}0-9]{3,}").findAll(request.lowercase()).map { it.value }) {
            words.add(w)
            AR[w]?.split(' ')?.let { words.addAll(it) }
        }
        if (words.isEmpty()) return emptyList()
        return names(c).map { nm ->
            val hay = (nm + " " + description(c, nm)).lowercase()
            nm to words.count { it.length >= 3 && hay.contains(it) }
        }.filter { it.second > 0 }.sortedByDescending { it.second }.take(n).map { it.first }
    }

    fun isBuiltin(name: String): Boolean = BUILTIN.containsKey(name)

    fun delete(c: Context, name: String): Boolean =
        !isBuiltin(name) && name.matches(Regex("[A-Za-z0-9_-]{1,60}")) && File(dir(c), name).deleteRecursively()

    fun names(c: Context): List<String> =
        (dir(c).listFiles() ?: emptyArray()).filter { File(it, "SKILL.md").exists() }.map { it.name }.sorted()

    fun read(c: Context, name: String): String? {
        if (!name.matches(Regex("[A-Za-z0-9_-]{1,60}"))) return null
        val f = File(File(dir(c), name), "SKILL.md")
        return if (f.exists()) f.readText() else null
    }

    fun description(text: String): String {
        val m = Regex("(?m)^description:\\s*(.+)$").find(text)
        val d = m?.groupValues?.get(1)?.trim()?.trim('"', '\'', '>', '|')?.trim()
        if (!d.isNullOrBlank()) return d
        val body = text.substringAfter("\n---", text)
        val prose = body.lineSequence().map { it.trim() }.firstOrNull { it.length > 25 && !it.startsWith("#") && !it.startsWith("---") && !it.startsWith("|") && !it.startsWith("```") }
        return (prose ?: text.lineSequence().map { it.trim().trimStart('#', ' ') }.firstOrNull { it.length > 3 && it != "---" } ?: "").take(160)
    }

    fun save(c: Context, name: String, text: String) {
        val d = File(dir(c), name)
        d.mkdirs()
        File(d, "SKILL.md").writeText(text)
    }

    private val BUILTIN: Map<String, String> = mapOf(
        "motion-graphics" to """---
name: motion-graphics
description: صناعة موشن جرافيك متحرك (نصوص، أشكال، شخصيات، انتقالات) كصفحة HTML كاملة، وتصديره فيديو MP4 عبر Termux عند الطلب.
---
# Motion graphics

## الصفحة المتحركة (تعمل مباشرة)
1. اكتب ملف HTML واحدًا كاملًا مستقلًا بوسم الملف: <write_file path="motion/scene.html"> ... </write_file> (لا تختصر ولا تضع «...» داخل الكود).
2. المسرح 1280x720. استعمل CSS animations أو canvas مع requestAnimationFrame، وحلقة مدتها 8 إلى 12 ثانية، مع عدة مشاهد (ظهور، حوار بفقاعات نص، انتقال).
3. الشخصيات: ارسمها بـ SVG أو CSS (رأس دائري، جسم، ذراعان تتحركان بـ keyframes)، ولكل شخصية لون مميز وفقاعة كلام تظهر بالتناوب لتبدو كأنها تتحاور.
4. سلّم الملف: send_file {"path":"motion/scene.html"} (يفتح معاينة ويحفظه في التنزيلات).

## الأسرع: أداة make_video (فيديو جاهز بلا كتابة كود)
لأي طلب فيديو فيه شخصيتان تتحاوران: استدعِ make_video بمشاهد قصيرة (speaker: A أو B أو narrator، text، sec). تنتج MP4 وتسلّمه تلقائيًا، وتعمل في دقائق لا ساعات. يلزم جسر Termux متصلًا.

## تصدير فيديو مخصص (يدويًا)
1. shell: pkg install -y python ffmpeg && pip install pillow
2. اكتب سكربت بايثون كاملًا motion/render.py بوسم الملف؛ يرسم الإطارات بـ Pillow إلى motion/frames/f0001.png… (30 إطارًا في الثانية).
3. shell: python3 motion/render.py ثم: ffmpeg -y -framerate 30 -i motion/frames/f%04d.png -c:v libx264 -pix_fmt yuv420p motion/out.mp4
4. سلّم: send_file {"path":"motion/out.mp4"}. للصوت: أضف ‎-i voice.mp3 ‎ في أمر ffmpeg.

## ملاحظات
- نفّذ العمل فعليًا بالأدوات؛ لا تقل «استخدمت المهارة» دون أن تكتب الملفات.
- الحركات البسيطة (ظهور، انزلاق، تكبير، اهتزاز) أنسب لنموذج صغير.
""",
        "termux-setup" to """---
name: termux-setup
description: تجهيز Termux بأدوات التطوير الشائعة وحل مشاكل الصلاحيات والتثبيت.
---
# تجهيز Termux

- تحديث: pkg update -y && pkg upgrade -y
- أدوات شائعة: pkg install -y python git nodejs clang make ffmpeg
- تثبيت حزمة بايثون: pip install اسم_الحزمة
- إذا فشل pkg بسبب المرآة: termux-change-repo
- لا تنفّذ أوامر حذف أو تعديل خارج مجلد المشروع دون إذن صريح من المستخدم.
- بعد كل أمر اقرأ exit= في النتيجة؛ إن لم يكن 0 فاقرأ stderr وأصلح الأمر ثم أعد المحاولة مرة واحدة.
""",
        "code-writer" to """---
name: code-writer
description: قواعد كتابة الكود وحفظه واختباره بشكل منظم.
---
# كتابة الكود

1. افهم المطلوب في جملة، ثم اكتب كل ملف كاملًا بوسم الملف <write_file path="مجلد/ملف.py"> ... </write_file> (بلا اختصار).
2. ملفات مسمّاة بوضوح، وتعليقات قصيرة.
3. للتجربة: شغّله بـ shell (مثال: python3 مجلد/main.py). وللتسليم استعمل send_file.
4. إن ظهر خطأ فاقرأه وأصلح السبب الجذري ولا تخمّن.
5. اختم بملخص عربي من سطرين: ما الذي كتبته وأين وكيف يشغّله المستخدم.
""",
        "skill-creator" to """---
name: skill-creator
description: كتابة مهارة جديدة وتثبيتها ليستعملها الوكيل لاحقًا.
---
# إنشاء مهارة

صيغة الملف:
---
name: اسم-بحروف-لاتينية-صغيرة
description: جملة واحدة تقول متى تُستعمل المهارة
---
ثم تعليمات مرقّمة قصيرة وواضحة.

للتثبيت استعمل install_skill بالاسم والنص (content)، أو بالرابط (url) إن طلب المستخدم ذلك.
لا تثبّت مهارة من رابط دون أن يوافق المستخدم على الرابط.
"""
    )
}
