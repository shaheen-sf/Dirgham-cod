package com.dirgham.code

import android.content.Context
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import kotlinx.coroutines.runBlocking
import java.io.File
import java.util.zip.ZipFile

/**
 * استيراد أي ملف يرفقه المستخدم: يُنسخ إلى مساحة العمل، ويُدفع إلى Termux (~/dirgham/inputs) إن كان الجسر متصلًا،
 * ويُوصَف للنموذج نصيًا (الأبعاد، المدة، محتويات الضغط…). النموذج لا «يرى» الصور ولا «يسمع» الصوت؛
 * يعالجها بأدوات Termux (ffmpeg/python…).
 */
object Inputs {
    private val TEXT_EXT = setOf(
        "txt", "md", "json", "csv", "tsv", "xml", "html", "htm", "css", "js", "ts", "py", "kt", "java", "dart", "c", "cpp", "h",
        "sh", "yml", "yaml", "toml", "ini", "cfg", "log", "sql", "srt", "vtt", "svg", "gradle", "properties", "rs", "go", "php"
    )

    private fun ext(n: String) = n.substringAfterLast('.', "").lowercase()

    private fun looksText(f: File): Boolean = try {
        val b = f.inputStream().use { it.readNBytes(4096) }
        b.none { it.toInt() == 0 }
    } catch (_: Exception) { false }

    private fun mb(n: Long) = if (n >= 1048576) "%.1f MB".format(n / 1048576.0) else "${n / 1024} KB"

    private fun describeMedia(f: File): String = try {
        val r = MediaMetadataRetriever()
        r.setDataSource(f.absolutePath)
        fun g(k: Int) = r.extractMetadata(k)
        val dur = g(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
        val w = g(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
        val h = g(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
        val br = g(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toLongOrNull()
        val title = g(MediaMetadataRetriever.METADATA_KEY_TITLE)
        val hasV = g(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO) == "yes"
        r.release()
        buildString {
            append(if (hasV) "video" else "audio")
            if (w != null && h != null) append(" ${w}x$h")
            if (dur != null) append(", %.1f s".format(dur / 1000.0))
            if (br != null) append(", ${br / 1000} kbps")
            if (!title.isNullOrBlank()) append(", title: $title")
        }
    } catch (_: Exception) { "media (unreadable metadata)" }

    private fun describeZip(f: File, ws: File, base: String): String = try {
        val zf = ZipFile(f)
        val entries = zf.entries().toList().filter { !it.isDirectory }
        val sb = StringBuilder("zip archive, ${entries.size} files:\n")
        entries.take(40).forEach { sb.append("  ").append(it.name).append(" (").append(mb(it.size)).append(")\n") }
        if (entries.size > 40) sb.append("  … +${entries.size - 40} more\n")
        // نفكّ الضغط محليًا بحدود آمنة (حماية من zip-slip وقنابل الضغط)
        val outDir = File(ws, "inputs/$base" + "_unzipped")
        var total = 0L
        var inlined = 0
        var inlineChars = 0
        for (e in entries.take(300)) {
            if (e.size > 200L * 1048576 || total + e.size > 400L * 1048576) continue
            val dest = File(outDir, e.name).canonicalFile
            if (!dest.path.startsWith(outDir.canonicalPath + File.separator)) continue
            dest.parentFile?.mkdirs()
            zf.getInputStream(e).use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
            total += e.size
            if (ext(e.name) in TEXT_EXT && inlined < 5 && inlineChars < 12000 && e.size < 20000) {
                val txt = dest.readText().take(4000)
                sb.append("--- ${e.name} ---\n").append(txt).append("\n")
                inlined++; inlineChars += txt.length
            }
        }
        zf.close()
        sb.append("(extracted to workspace inputs/${base}_unzipped)")
        sb.toString()
    } catch (e: Exception) { "zip archive (could not open: ${e.message})" }

    /** يعيد وصفًا جاهزًا للإدراج في رسالة المستخدم. يعمل في خيط خلفي. */
    fun import(ctx: Context, srcPath: String, displayName: String): String {
        val ws = File(ctx.filesDir, "workspace").also { it.mkdirs() }
        val inDir = File(ws, "inputs").also { it.mkdirs() }
        val name = LocalBridge.cleanName(displayName)
        val dst = File(inDir, name)
        File(srcPath).inputStream().use { i -> dst.outputStream().use { o -> i.copyTo(o) } }

        val e = ext(name)
        val kind = when {
            e == "zip" -> describeZip(dst, ws, name.substringBeforeLast('.'))
            e in setOf("jpg", "jpeg", "png", "webp", "gif", "bmp") -> {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(dst.absolutePath, o)
                "image ${o.outWidth}x${o.outHeight} (you cannot see it; process it with tools)"
            }
            e in setOf("mp4", "mkv", "mov", "webm", "avi", "3gp", "mp3", "wav", "m4a", "aac", "ogg", "flac", "opus") -> describeMedia(dst)
            e in TEXT_EXT || looksText(dst) -> "text file, ${mb(dst.length())}:\n" + dst.readText().let { if (it.length > 6000) it.take(6000) + "\n…(use read_file for the rest)" else it }
            else -> "binary file, ${mb(dst.length())}"
        }

        var where = "inputs/$name (app workspace)"
        if (LocalBridge.connected()) {
            val enc = java.net.URLEncoder.encode(name, "UTF-8")
            val r = try {
                runBlocking { TermuxBridge.runCapture(ctx, "mkdir -p ~/dirgham/inputs && curl -fsS -o 'inputs/$name' '${LocalBridge.url("file/$enc")}' && echo staged", 180_000L) }
            } catch (_: Exception) { "" }
            if (r.contains("staged")) where = "~/dirgham/inputs/$name"
        }
        return "[attached: $name -> $where] $kind"
    }
}
