package com.dirgham.code

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import java.io.File

/** حفظ الملفات في «التنزيلات» عندما يضغط المستخدم زر «تنزيل» على بطاقة الملف. */
object Deliver {
    fun mimeOf(name: String): String {
        val e = name.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(e)
            ?: when (e) { "md", "py", "kt", "dart", "sh", "log" -> "text/plain"; else -> "application/octet-stream" }
    }

    /** يعيد Uri كنص، أو يرمي استثناءً. */
    fun saveToDownloads(ctx: Context, src: File, name: String, mime: String): String {
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/Dirgham")
            }
            val res = ctx.contentResolver
            val uri = res.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                ?: throw IllegalStateException("MediaStore رفض الإنشاء")
            res.openOutputStream(uri)!!.use { o -> src.inputStream().use { it.copyTo(o) } }
            return uri.toString()
        }
        val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: ctx.filesDir
        val out = File(dir, name)
        src.copyTo(out, overwrite = true)
        return android.net.Uri.fromFile(out).toString()
    }
}
