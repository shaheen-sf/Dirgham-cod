#!/usr/bin/env python3
"""
يدمج مصدر ضرغام كود (app_src) داخل مشروع Flutter الذي ولّده `flutter create`.

الاستعمال:  python3 tools/apply_overlay.py <مجلد_المشروع_المولّد>   (الافتراضي: app)

يقوم بـ:
  1) نسخ pubspec و lib و assets
  2) نسخ ملفات Kotlin و C++ و res
  3) ضبط gradle (الحزمة، minSdk، CMake، الاعتماديات) سواء كان kts أو groovy
  4) دمج الأذونات والخدمة في AndroidManifest
السكربت متكرر الأمان (يمكن تشغيله أكثر من مرة).
"""
import re
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "app_src"
APP = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else ROOT / "app"
PKG = "com.dirgham.code"
GEN_PKG = "com.dirgham.dirgham_code"

ANDROID = APP / "android" / "app"
MAIN = ANDROID / "src" / "main"


def log(msg):
    print(f"[overlay] {msg}")


def copy_tree(src: Path, dst: Path):
    if dst.exists():
        shutil.rmtree(dst)
    shutil.copytree(src, dst)


# ---------- 1) Flutter ----------
shutil.copy2(SRC / "pubspec.yaml", APP / "pubspec.yaml")
copy_tree(SRC / "lib", APP / "lib")
copy_tree(SRC / "assets", APP / "assets")
shutil.rmtree(APP / "test", ignore_errors=True)
log("Flutter sources copied")

# ---------- 2) Kotlin / C++ / res ----------
old_kt = MAIN / "kotlin" / "com" / "dirgham" / "dirgham_code"
shutil.rmtree(old_kt, ignore_errors=True)
new_kt = MAIN / "kotlin" / "com" / "dirgham" / "code"
new_kt.mkdir(parents=True, exist_ok=True)
for f in (SRC / "android_overlay" / "kotlin").glob("*.kt"):
    shutil.copy2(f, new_kt / f.name)

cpp = MAIN / "cpp"
cpp.mkdir(parents=True, exist_ok=True)
for f in (SRC / "android_overlay" / "cpp").glob("*"):
    if f.is_file():
        shutil.copy2(f, cpp / f.name)

shutil.copy2(SRC / "android_overlay" / "signing" / "dirgham.jks", ANDROID / "dirgham.jks")

xml_dir = MAIN / "res" / "xml"
xml_dir.mkdir(parents=True, exist_ok=True)
shutil.copy2(SRC / "android_overlay" / "res" / "xml" / "file_paths.xml", xml_dir / "file_paths.xml")
log("Kotlin / C++ / res copied")

if not (cpp / "llama.cpp" / "CMakeLists.txt").exists():
    sys.exit("llama.cpp غير موجود في " + str(cpp / "llama.cpp") + " — استنسخه أولًا (انظر build-apk.yml)")

# ---------- 3) Gradle ----------
kts = ANDROID / "build.gradle.kts"
groovy = ANDROID / "build.gradle"
gfile = kts if kts.exists() else groovy
is_kts = gfile == kts
text = gfile.read_text(encoding="utf-8")

if "llama_jni" not in text and "externalNativeBuild" not in text:
    text = text.replace(GEN_PKG, PKG)

    if is_kts:
        text = re.sub(r"minSdk\s*=\s*flutter\.minSdkVersion", "minSdk = 26", text)
        native_block = (
            '\n    externalNativeBuild {\n'
            '        cmake {\n'
            '            path = file("src/main/cpp/CMakeLists.txt")\n'
            '            version = "3.22.1"\n'
            '        }\n'
            '    }\n'
        )
        cfg_block = (
            '\n        ndk { abiFilters += listOf("arm64-v8a") }\n'
            '        externalNativeBuild {\n'
            '            cmake {\n'
            '                abiFilters("arm64-v8a")\n'
            '                arguments("-DANDROID_STL=c++_shared", "-DGGML_NATIVE=OFF")\n'
            '            }\n'
            '        }\n'
        )
        deps = (
            '\ndependencies {\n'
            '    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")\n'
            '    implementation("androidx.core:core-ktx:1.13.1")\n'
            '    implementation("androidx.annotation:annotation:1.8.2")\n'
            '}\n'
        )
    else:
        text = re.sub(r"minSdkVersion\s+flutter\.minSdkVersion", "minSdkVersion 26", text)
        native_block = (
            '\n    externalNativeBuild {\n'
            '        cmake {\n'
            '            path "src/main/cpp/CMakeLists.txt"\n'
            '            version "3.22.1"\n'
            '        }\n'
            '    }\n'
        )
        cfg_block = (
            '\n        ndk { abiFilters "arm64-v8a" }\n'
            '        externalNativeBuild {\n'
            '            cmake {\n'
            '                abiFilters "arm64-v8a"\n'
            '                arguments "-DANDROID_STL=c++_shared", "-DGGML_NATIVE=OFF"\n'
            '            }\n'
            '        }\n'
        )
        deps = (
            '\ndependencies {\n'
            '    implementation "org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1"\n'
            '    implementation "androidx.core:core-ktx:1.13.1"\n'
            '    implementation "androidx.annotation:annotation:1.8.2"\n'
            '}\n'
        )

    if is_kts:
        sign_block = (
            '\n    signingConfigs {\n'
            '        create("dirgham") {\n'
            '            storeFile = file("dirgham.jks")\n'
            '            storePassword = "dirgham123"\n'
            '            keyAlias = "dirgham"\n'
            '            keyPassword = "dirgham123"\n'
            '        }\n'
            '    }\n'
        )
        text = re.sub(r'signingConfigs\.getByName\("debug"\)', 'signingConfigs.getByName("dirgham")', text)
    else:
        sign_block = (
            '\n    signingConfigs {\n'
            '        dirgham {\n'
            '            storeFile file("dirgham.jks")\n'
            '            storePassword "dirgham123"\n'
            '            keyAlias "dirgham"\n'
            '            keyPassword "dirgham123"\n'
            '        }\n'
            '    }\n'
        )
        text = re.sub(r'signingConfigs\.debug', 'signingConfigs.dirgham', text)
    native_block = sign_block + native_block

    m = re.search(r"^android\s*\{", text, re.M)
    if not m:
        sys.exit("لم أجد كتلة android { في " + str(gfile))
    text = text[: m.end()] + native_block + text[m.end():]

    m = re.search(r"defaultConfig\s*\{", text)
    if not m:
        sys.exit("لم أجد defaultConfig { في " + str(gfile))
    text = text[: m.end()] + cfg_block + text[m.end():]

    text += deps
    gfile.write_text(text, encoding="utf-8")
    log(f"patched {gfile.name}")
else:
    log("gradle already patched")

# مواضع أخرى قد يظهر فيها اسم الحزمة المولَّدة
for extra in [ANDROID / "build.gradle", ANDROID / "build.gradle.kts"]:
    if extra.exists():
        t = extra.read_text(encoding="utf-8")
        if GEN_PKG in t:
            extra.write_text(t.replace(GEN_PKG, PKG), encoding="utf-8")

# ---------- 4) Manifest ----------
mf = MAIN / "AndroidManifest.xml"
mt = mf.read_text(encoding="utf-8")

if "dirgham.files" not in mt and ".files" not in mt:
    perms = """
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_SPECIAL_USE" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="com.termux.permission.RUN_COMMAND" />

    <queries>
        <package android:name="com.termux" />
        <package android:name="com.lemon.lvoverseas" />
        <package android:name="io.elevenlabs.app" />
        <intent><action android:name="android.speech.RecognitionService" /></intent>
        <intent><action android:name="android.speech.action.RECOGNIZE_SPEECH" /></intent>
        <intent><action android:name="android.intent.action.TTS_SERVICE" /></intent>
    </queries>
"""
    comps = """
        <service
            android:name=".AgentService"
            android:exported="false"
            android:foregroundServiceType="specialUse">
            <property
                android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE"
                android:value="local_llm_agent" />
        </service>

        <activity
            android:name=".PreviewActivity"
            android:exported="false"
            android:theme="@android:style/Theme.Black.NoTitleBar" />

        <provider
            android:name="androidx.core.content.FileProvider"
            android:authorities="${applicationId}.files"
            android:exported="false"
            android:grantUriPermissions="true">
            <meta-data
                android:name="android.support.FILE_PROVIDER_PATHS"
                android:resource="@xml/file_paths" />
        </provider>
"""
    # الأذونات والـ queries قبل <application
    idx = mt.index("<application")
    mt = mt[:idx] + perms.lstrip("\n") + "\n    " + mt[idx:]
    # الخدمة والـ provider قبل </application>
    mt = mt.replace("</application>", comps + "    </application>", 1)
    # اسم التطبيق
    mt = re.sub(r'android:label="[^"]*"', 'android:label="ضرغام كود"', mt, count=1)
    # دعم RTL
    if "android:supportsRtl" not in mt:
        mt = mt.replace("<application", '<application android:supportsRtl="true"', 1)
    mf.write_text(mt, encoding="utf-8")
    log("manifest patched")
else:
    log("manifest already patched")

log("done")
