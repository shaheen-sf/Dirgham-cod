#!/usr/bin/env bash
# بناء محلي (اختياري). يتطلب: Flutter + JDK 17 + Android SDK/NDK + git
set -euo pipefail
cd "$(dirname "$0")/.."

LLAMA_REF="${LLAMA_REF:-b5000}"

[ -d app ] || flutter create --org com.dirgham --project-name dirgham_code --platforms android app
CPP=app/android/app/src/main/cpp
if [ ! -d "$CPP/llama.cpp" ]; then
  git clone --depth 1 --branch "$LLAMA_REF" https://github.com/ggml-org/llama.cpp.git "$CPP/llama.cpp"
  rm -rf "$CPP/llama.cpp/.git"
fi

python3 tools/apply_overlay.py app
cd app
flutter pub get
flutter build apk --release --target-platform android-arm64
echo "الناتج: app/build/app/outputs/flutter-apk/app-release.apk"
