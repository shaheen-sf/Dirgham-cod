package com.dirgham.code

import android.content.Context

object Settings {
    private fun p(c: Context) = c.getSharedPreferences("dirgham", Context.MODE_PRIVATE)

    fun activeModel(c: Context): String = p(c).getString("model", "") ?: ""
    fun setActiveModel(c: Context, v: String) { p(c).edit().putString("model", v).apply() }

    fun thinking(c: Context): Boolean = p(c).getBoolean("thinking", false)
    fun setThinking(c: Context, v: Boolean) { p(c).edit().putBoolean("thinking", v).apply() }

    // ملف التشغيل المختار بالفحص الذاتي (فارغ = لم يُفحص بعد). يرتبط برقم البناء كي يُعاد الفحص بعد كل تحديث.
    fun profile(c: Context): String = p(c).getString("profile", "") ?: ""
    fun setProfile(c: Context, v: String) { p(c).edit().putString("profile", v).apply() }

    /** رمز سري ثابت لجسر Termux المحلي (يُولَّد مرة واحدة). */
    fun bridgeToken(c: Context): String {
        var v = p(c).getString("bridge_token", "") ?: ""
        if (v.length < 16) {
            val chars = "abcdefghijklmnopqrstuvwxyz0123456789"
            val r = java.security.SecureRandom()
            v = (1..24).map { chars[r.nextInt(chars.length)] }.joinToString("")
            p(c).edit().putString("bridge_token", v).apply()
        }
        return v
    }

    fun githubToken(c: Context): String = p(c).getString("github_token", "") ?: ""
    fun setGithubToken(c: Context, v: String) { p(c).edit().putString("github_token", v.trim()).apply() }

    fun elevenKey(c: Context): String = p(c).getString("eleven_key", "") ?: ""
    fun elevenVoice(c: Context): String = p(c).getString("eleven_voice", "") ?: ""
    fun setEleven(c: Context, key: String, voice: String) { p(c).edit().putString("eleven_key", key.trim()).putString("eleven_voice", voice.trim()).apply() }

    /** دقائق الخمول قبل تفريغ النموذج من الرام (0 = لا يُفرَّغ). */
    fun threads(c: Context): Int = p(c).getInt("threads", 0)
    fun setThreads(c: Context, n: Int) { p(c).edit().putInt("threads", n).apply() }
    fun pinBig(c: Context): Boolean = p(c).getBoolean("pin_big", false)
    fun setPinBig(c: Context, b: Boolean) { p(c).edit().putBoolean("pin_big", b).apply() }
    fun geminiKey(c: Context): String = p(c).getString("gemini_key", "") ?: ""
    fun setGeminiKey(c: Context, k: String) { p(c).edit().putString("gemini_key", k).apply() }
    fun idleMinutes(c: Context): Int = p(c).getInt("idle_min", 30)
    fun setIdleMinutes(c: Context, v: Int) { p(c).edit().putInt("idle_min", v).apply() }

    /** نموذج سريع للمهام البسيطة (اسم ملف؛ فارغ = استعمل النموذج النشط دائمًا). */
    fun fastModel(c: Context): String = p(c).getString("fast_model", "") ?: ""
    fun setFastModel(c: Context, v: String) { p(c).edit().putString("fast_model", v).apply() }

    /** أمر تحويل نص لصوت محلي في Termux (اختياري). المتغيران {text} ملف النص و{out} ملف الإخراج. */
    fun ttsCmd(c: Context): String = p(c).getString("tts_cmd", "") ?: ""
    fun imgCmd(c: Context): String = p(c).getString("img_cmd", "") ?: ""
    fun setLocalCmds(c: Context, tts: String, img: String) { p(c).edit().putString("tts_cmd", tts.trim()).putString("img_cmd", img.trim()).apply() }
}
