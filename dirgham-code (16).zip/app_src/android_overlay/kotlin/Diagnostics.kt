package com.dirgham.code

import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import android.speech.SpeechRecognizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** فحص شامل بالأرقام الفعلية: ما يعمل وما لا يعمل على هذا الجهاز الآن، مع خطوة الإصلاح لكل خلل. */
object Diagnostics {
    private const val OK = "✅"
    private const val BAD = "❌"
    private const val WARN = "⚠️"

    suspend fun run(ctx: Context): String = withContext(Dispatchers.IO) {
        val sb = StringBuilder()
        val fix = ArrayList<String>()
        fun line(mark: String, text: String) { sb.append(mark).append(' ').append(text).append('\n') }

        sb.append("— الجهاز —\n")
        line(OK, "${Build.MANUFACTURER} ${Build.MODEL} • أندرويد ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT}) • ${Runtime.getRuntime().availableProcessors()} أنوية")
        try {
            val mi = ActivityManager.MemoryInfo()
            (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
            val rss = try { File("/proc/self/statm").readText().trim().split(" ")[1].toLong() * 4096 / 1048576 } catch (_: Exception) { -1L }
            line(OK, "الرام: الكلي ${mi.totalMem / 1048576} م.ب • المتاح ${mi.availMem / 1048576} م.ب • التطبيق ${rss} م.ب" + (if (mi.lowMemory) " (ذاكرة منخفضة!)" else ""))
        } catch (_: Throwable) {}

        sb.append("\n— المحرك —\n")
        val llm = LlamaEngine.shared(ctx)
        if (!LlamaEngine.nativeOk) { line(BAD, "المكتبة الأصلية غير موجودة في الـ APK"); fix.add("أعد بناء التطبيق (مكتبة llama_jni لم تُحمَّل).") }
        else {
            line(OK, "المكتبة الأصلية محمّلة" + (if (llm.cpuHasDotprodPublic()) " • المعالج يدعم dotprod" else ""))
            val m = LlamaEngine.activeModel(ctx)
            if (m == null) { line(BAD, "لا يوجد نموذج مختار"); fix.add("نزّل نموذجًا من «الأدوات» (أنصح بـ Qwen3 4B أو 8B).") }
            else line(if (llm.isLoaded()) OK else WARN, "النموذج: ${m.name} (${m.length() / 1048576} م.ب) — " + (if (llm.isLoaded()) "محمّل في الرام" else "غير محمّل الآن (يُحمَّل عند أول رسالة)"))
            line(OK, "الخيوط: ${if (Settings.threads(ctx) > 0) Settings.threads(ctx).toString() else "تلقائي"} • تثبيت على الأنوية الكبيرة: ${llm.pinnedDescription()}")
        }

        sb.append("\n— الجسر وTermux —\n")
        val termux = TermuxBridge.isInstalled(ctx)
        line(if (termux) OK else BAD, "Termux " + (if (termux) "مثبّت" else "غير مثبّت"))
        if (!termux) fix.add("ثبّت Termux من F-Droid (ليس من متجر Play).")
        val perm = TermuxBridge.hasPermission(ctx)
        line(if (perm) OK else WARN, "إذن RUN_COMMAND: " + (if (perm) "ممنوح (التشغيل التلقائي للجسر ممكن)" else "غير ممنوح (الجسر يعمل بدونه لكن لا يُعاد تشغيله تلقائيًا)"))
        val age = LocalBridge.ageMs()
        if (LocalBridge.connected()) {
            line(OK, "الجسر متصل (آخر نبضة قبل ${age / 1000} ث)")
            val t0 = System.currentTimeMillis()
            val r = LocalBridge.run(
                "echo ok; python3 --version 2>&1 | head -1; python3 -c 'import PIL;print(\"Pillow\",PIL.__version__)' 2>&1 | tail -1; " +
                    "ffmpeg -version 2>&1 | head -1; grep -c 'allow-external-apps *= *true' ~/.termux/termux.properties 2>&1", 25)
            val ms = System.currentTimeMillis() - t0
            if (r == null) { line(BAD, "الجسر لم يردّ على أمر اختبار خلال 25 ث"); fix.add("أعد تشغيل الجسر: الصق أمر الجسر في Termux ثانية.") }
            else {
                line(OK, "زمن استجابة الجسر: $ms مللي ثانية")
                val o = r.second.lines().map { it.trim() }.filter { it.isNotEmpty() }
                line(if (o.any { it.startsWith("Python") }) OK else BAD, "Python: " + (o.firstOrNull { it.startsWith("Python") } ?: "غير موجود"))
                if (o.none { it.startsWith("Python") }) fix.add("في Termux: pkg install python")
                line(if (o.any { it.startsWith("Pillow") }) OK else BAD, "Pillow: " + (o.firstOrNull { it.startsWith("Pillow") } ?: "غير موجود"))
                if (o.none { it.startsWith("Pillow") }) fix.add("في Termux: pkg install python-pillow")
                line(if (o.any { it.startsWith("ffmpeg") }) OK else BAD, "ffmpeg: " + (o.firstOrNull { it.startsWith("ffmpeg") }?.take(40) ?: "غير موجود"))
                if (o.none { it.startsWith("ffmpeg") }) fix.add("في Termux: pkg install ffmpeg")
                val ext = o.lastOrNull()?.toIntOrNull() ?: 0
                line(if (ext > 0) OK else WARN, "allow-external-apps في Termux: " + (if (ext > 0) "مفعّل" else "غير مفعّل (يُضاف تلقائيًا عند إعادة تشغيل سكربت الجسر)"))
            }
        } else {
            line(BAD, "الجسر غير متصل" + (if (age < Long.MAX_VALUE / 2) " (آخر نبضة قبل ${age / 1000} ث)" else " (لم يتصل منذ تشغيل التطبيق)"))
            fix.add("افتح Termux والصق أمر الجسر (الإعدادات ← Termux). إن تكرّر الانقطاع فشغّل ~/fix-phantom.sh مرة واحدة (انظر أسفل).")
        }
        try {
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            val a = pm.isIgnoringBatteryOptimizations(ctx.packageName)
            val b = pm.isIgnoringBatteryOptimizations("com.termux")
            line(if (a) OK else WARN, "استثناء ضرغام كود من تحسين البطارية: " + (if (a) "نعم" else "لا"))
            line(if (b) OK else WARN, "استثناء Termux من تحسين البطارية: " + (if (b) "نعم" else "لا"))
            if (!b) fix.add("الإعدادات ← التطبيقات ← Termux ← البطارية ← «غير مقيّد» (Unrestricted).")
            if (!a) fix.add("الإعدادات ← التطبيقات ← ضرغام كود ← البطارية ← «غير مقيّد».")
        } catch (_: Throwable) {}
        try {
            val v = android.provider.Settings.Global.getString(ctx.contentResolver, "settings_enable_monitor_phantom_procs")
            when (v) {
                "false" -> line(OK, "قاتل العمليات الشبحية: معطّل (ممتاز لثبات الجسر)")
                "true" -> { line(WARN, "قاتل العمليات الشبحية: مفعّل (قد يقتل الجسر)"); fix.add("شغّل في Termux: bash ~/fix-phantom.sh (مرة واحدة، من الهاتف نفسه عبر التصحيح اللاسلكي).") }
                else -> { line(WARN, "قاتل العمليات الشبحية: الإعداد غير مقروء/افتراضي (يُعدّ مفعّلًا على أندرويد 12+)"); if (Build.VERSION.SDK_INT >= 31) fix.add("شغّل في Termux: bash ~/fix-phantom.sh (مرة واحدة).") }
            }
        } catch (_: Throwable) {}

        sb.append("\n— الصوت —\n")
        val mic = ctx.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        line(if (mic) OK else BAD, "إذن الميكروفون: " + (if (mic) "ممنوح" else "غير ممنوح"))
        if (!mic) fix.add("اضغط زر الميكروفون وامنح الإذن، أو من إعدادات التطبيق ← الأذونات ← الميكروفون.")
        val rec = SpeechRecognizer.isRecognitionAvailable(ctx)
        line(if (rec) OK else WARN, "خدمة التعرف على الصوت: " + (if (rec) "متوفرة" else "غير متوفرة (سأفتح نافذة التعرف القياسية إن وُجدت)"))

        sb.append("\n— المفاتيح —\n")
        line(if (Settings.geminiKey(ctx).isNotBlank()) OK else WARN, "Gemini (التعرف على الصور/الصوت): " + (if (Settings.geminiKey(ctx).isNotBlank()) "مضاف" else "غير مضاف"))
        line(if (Settings.elevenKey(ctx).isNotBlank()) OK else WARN, "ElevenLabs (الصوت): " + (if (Settings.elevenKey(ctx).isNotBlank()) "مضاف" else "غير مضاف"))
        line(if (Settings.githubToken(ctx).isNotBlank()) OK else WARN, "GitHub: " + (if (Settings.githubToken(ctx).isNotBlank()) "توكن مضاف" else "بلا توكن (حدّ معدل منخفض)"))

        sb.append("\n— آخر انهيار —\n")
        val cr = Crash.report()
        sb.append(if (cr.isNullOrBlank()) "$OK لا يوجد\n" else "$WARN ${cr.take(500)}\n")

        if (fix.isNotEmpty()) {
            sb.append("\n— ما يجب إصلاحه —\n")
            fix.distinct().forEachIndexed { i, f -> sb.append("${i + 1}. $f\n") }
        } else sb.append("\nكل شيء سليم.\n")
        sb.toString()
    }
}
