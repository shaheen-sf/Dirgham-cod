package com.dirgham.code

import android.content.Context
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import org.json.JSONArray
import org.json.JSONObject

/**
 * حلقة الوكيل: يولّد النموذج، فإن طلب أداة نفّذناها وأعدنا النتيجة إليه، ونكرر حتى يُنهي.
 * يعمل مع أي نموذج GGUF لأن القالب يُؤخذ من النموذج نفسه.
 */
class Agent(private val ctx: Context, private val llm: LlamaEngine) {

    private val tools = Tools(ctx)
    private val history = ArrayList<Pair<String, String>>() // (role, content) بلا رسالة النظام

    companion object {
        const val MAX_STEPS = 14
        const val MAX_NEW_TOKENS = 3200
        const val HISTORY_CHARS = 12000
        private val TOOLS = setOf("list_files","read_file","write_file","delete_file","shell","termux_save","web_fetch","web_search","make_video","send_file","append_file",
            "github_get","github_put","github_runs","github_dispatch","list_skills","use_skill","install_skill","preview","open_app",
            "image_info","describe_media","audio_info","image_edit","make_image","generate_image","tts","transcribe","termux_inventory","request_package","ask_user","split_pieces","html_to_image")
        private val CALL_RE = Regex("<tool_call>\\s*([\\s\\S]*?)\\s*(?:</tool_call>|\\z)")
    }

    private var modelName: String = ""
    @Volatile var tps: Float = 0f
    private var chatMode = false
    private var toolsEverUsed = false
    @Volatile var ctxTokensHint: Int = 0

    fun clear() { history.clear() }

    /** استرجاع محادثة محفوظة: مصفوفة JSON من {r:"user|assistant", c:"..."} */
    fun restore(json: String) {
        history.clear()
        try {
            val arr = org.json.JSONArray(json)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val r = o.optString("r")
                val c = o.optString("c")
                if ((r == "user" || r == "assistant") && c.isNotBlank()) history.add(r to c)
            }
        } catch (_: Exception) {}
        while (history.isNotEmpty() && history[0].first != "user") history.removeAt(0)
    }

    private fun systemPrompt(): String {
        val skills = "Installed skills: ${Skills.names(ctx).size}. The user message may end with a [Hint: …] naming the best matching ones: call use_skill first. list_skills shows them all."
        if (chatMode) return "You are Dirgham, a friendly assistant on an Android phone. Answer briefly in the user's language (Arabic by default). No tools."
        return """You are "Dirgham Code", a local coding agent on an Android phone. Reply in the user's language (Arabic by default), briefly.
RULES
0. THINK FIRST: read the whole message and the attachments, work out what the user really wants and what the final deliverable is (a file, a video, an image, audio, an answer, an installed skill, a fix). Never default to an HTML site or a two-person dialog video unless that is what was asked. Installing a skill means saving its SKILL.md instruction file, nothing more. Reason step by step, one tool at a time, and adapt to the task.
1. You act only through tools. Never claim you did something unless a <tool_response> confirms it.
2. To CREATE or EDIT a file, use the file tag. Write the COMPLETE file, no JSON, no escaping:
<write_file path="site/index.html">
...full file content...
</write_file>
If a file is very long, write the first part, then continue next turn with <append_file path="site/index.html">...</append_file>.
3. For other tools output exactly one line and stop: <tool_call>{"name":"TOOL","arguments":{...}}</tool_call>
4. Deliver results to the user with send_file (it saves the file in Downloads and shows an Open button). Use it for any file, website, image, audio or video the user asked for.
5. Attached files are listed as [attached: name -> path]. In code, use only the file name (never copy the bracket text). You cannot see images/video or hear audio yourself; use shell tools (ffprobe, ffmpeg, python, unzip) to inspect or transform them.
6. When a skill is relevant, call use_skill first, then DO the work with tools following it. Reading a skill is not the work.
7. One tool call per reply. After the final tool result, answer briefly with no tool call.
8. For tasks with several steps, first write a numbered plan of 2-5 short lines, then start. To change part of an existing file use edit_file (small), not a full rewrite.
9. Skills are just text files stored on the phone; using one needs no internet. install_skill with "url" downloads a SKILL.md (needs internet); with "content" it only saves text you wrote. Never say a skill was downloaded unless you used url and the tool confirmed it.
10. If a tool result starts with ERROR, fix the problem and retry; never pretend it worked.
11. COMPOSE: for a big request, chain tools and combine the pieces into ONE final deliverable: (a) image_info on attached images, (b) image_edit (cutout/autocrop/crop/resize) to prepare characters, (c) make_image or generate_image for new pictures, (d) tts for voice, (e) make_video using those files, (f) send_file. Never reuse one picture for everything.
12. If something important is unclear (who is the character, which language, how long, which style), call ask_user with ONE short question and stop. Do not guess on big tasks. If you need a program that is missing in Termux, call termux_inventory first, then request_package (the user is asked for permission).
13. You cannot see or hear media. Use describe_media {path,question} (real recognition of an image/audio/video via Gemini, needs the user's key), image_info (colors, subject box), audio_info (duration, loudness, silences) and transcribe (speech to text); report only what they return.

TOOLS (JSON form)
list_files {"path":"."} | read_file {"path":"a.txt"} | delete_file {"path":"a.txt"}
edit_file {"path":"a.html","old":"exact old text","new":"replacement"}
shell {"cmd":"python3 a.py"} (Termux, user confirms) | send_file {"path":"out/video.mp4"}
make_video {"out":"video/talk.mp4","title":"...","names":{"A":"Ahmad","B":"Sara"},"scenes":[{"speaker":"A","text":"...","sec":4},{"speaker":"B","text":"...","sec":4}]} (builds a finished MP4 and sends it; USE THIS for any video request, never write video code. A scene may have "image":"attached-name.png" (background photo with slow zoom); top-level "audio":"voice.mp3" uses an attached audio file and stretches scenes to its length)
make_video extras: top-level "format":"vertical" (720x1280), "grid":true (grid + frame background), "font":"MyFont.ttf" (an attached font file for Arabic text); "characters":{"A":{"image":"teacher.png"},"B":{"image":"kid.jpg"}} replaces the drawn figures with the user's pictures (background removed automatically); a scene may have "layers":[{"type":"rect|ellipse|text|image","x":0.5,"y":0.5,"w":0.2,"h":0.2,"color":"#ff8844","text":"..","src":"a.png","cutout":true,"anim":[{"p":"x|y|alpha|scale|rot","from":0.2,"to":0.8,"t0":0,"t1":2}]}] (x,y,w,h are fractions of the screen); "voice":true adds a spoken voice-over of all scene texts
image_info {"path":"a.png"} | describe_media {"path":"a.png","question":"what is in it?"} | audio_info {"path":"a.mp3"} | image_edit {"src":"a.png","out":"out/b.png","ops":[{"op":"cutout"},{"op":"autocrop"},{"op":"crop","box":[0.1,0.1,0.5,0.8]},{"op":"resize","h":600}]}
make_image {"out":"out/card.png","w":1024,"h":576,"bg":"#16203a","layers":[...same layer format...]} | generate_image {"prompt":"english description","out":"out/pic.jpg"} (online)
tts {"text":"...","out":"out/voice"} (ElevenLabs if the user set a key, else Android voice) | transcribe {"path":"voice.m4a"}
split_pieces {"src":"sheet.png","out":"out/part"} (cuts a character sheet into separate transparent pieces and lists their boxes) | html_to_image {"html":"<full html page>","w":1080,"h":1920,"out":"out/poster.png"} (renders HTML/CSS with correct Arabic to a PNG; use for posters, titles, designed cards)
termux_inventory {} | request_package {"packages":"tesseract","reason":"to read text in images"} | ask_user {"question":"..."}
web_fetch {"url":"https://..."} | web_search {"query":"..."}
github_get {"repo":"owner/name","path":"README.md"} | github_put {"repo":"owner/name","path":"f.txt","content":"...","message":"msg"}
github_runs {"repo":"owner/name"} | github_dispatch {"repo":"owner/name","workflow":"build-apk.yml","ref":"main"}
list_skills {} | use_skill {"name":"motion-graphics"} (the result also lists the skill's companion files; read one with use_skill {"name":"..","file":"references/x.md"}) | install_skill {"name":"x","content":"# skill text"}
preview {"path":"a.html"} | open_app {"name":"capcut"}

EXAMPLES
User: make a page with a bouncing ball and give it to me
<write_file path="ball/index.html">
<!doctype html><html>...complete page...</html>
</write_file>
(after the result) <tool_call>{"name":"send_file","arguments":{"path":"ball/index.html"}}</tool_call>
User: make a short video where two people talk about coffee
<tool_call>{"name":"make_video","arguments":{"out":"video/coffee.mp4","title":"Coffee","names":{"A":"Ahmad","B":"Sara"},"scenes":[{"speaker":"A","text":"Do you like coffee?","sec":3},{"speaker":"B","text":"I love it every morning.","sec":3}]}}</tool_call>
User: search the web for flutter news
<tool_call>{"name":"web_search","arguments":{"query":"flutter news"}}</tool_call>
User: run hello.py
<tool_call>{"name":"shell","arguments":{"cmd":"python3 hello.py"}}</tool_call>
Installed skills:
$skills"""
    }

    private fun buildPrompt(noThinkSuffix: Boolean): String {
        // نقتطع من الأقدم حتى تصغر الحصيلة، ونضمن أن تبدأ بدور user
        var start = 0
        var total = history.sumOf { it.second.length }
        while (total > HISTORY_CHARS && start < history.size - 1) {
            total -= history[start].second.length
            start++
        }
        while (start < history.size - 1 && history[start].first != "user") start++
        val msgs = ArrayList<Pair<String, String>>()
        msgs.add("system" to systemPrompt())
        for (i in start until history.size) {
            val (r, c) = history[i]
            val isLastUser = (i == history.size - 1) && r == "user"
            msgs.add(r to (if (isLastUser && noThinkSuffix && modelName.contains("qwen3", ignoreCase = true)) "$c /no_think" else c))
        }
        return llm.applyTemplate(msgs) ?: chatml(msgs)
    }

    private fun chatml(msgs: List<Pair<String, String>>): String {
        val sb = StringBuilder()
        for ((r, c) in msgs) sb.append("<|im_start|>").append(r).append('\n').append(c).append("<|im_end|>\n")
        sb.append("<|im_start|>assistant\n")
        return sb.toString()
    }

    private fun parseBody(body: String): Pair<String, JSONObject>? {
        val s = body.indexOf('{')
        val e = body.lastIndexOf('}')
        if (s < 0 || e <= s) return null
        return try {
            val j = JSONObject(body.substring(s, e + 1))
            val name = j.optString("name").ifEmpty { j.optString("tool") }
            if (name.isEmpty()) null
            else Pair(name, j.optJSONObject("arguments") ?: j.optJSONObject("parameters") ?: j.optJSONObject("args") ?: JSONObject())
        } catch (_: Exception) { null }
    }

    private val FILE_TAG = Regex("<(write_file|append_file)\\s+path\\s*=\\s*[\"']([^\"']+)[\"']\\s*>\\n?([\\s\\S]*?)(?:</\\1>|\\z)")

    private fun fileCall(text: String): Triple<String, JSONObject, Boolean>? {
        val m = FILE_TAG.find(text) ?: return null
        var body = m.groupValues[3]
        val closed = text.contains("</" + m.groupValues[1] + ">")
        // إن لفّ النموذج المحتوى بسياج ``` نزيله
        val f = Regex("^\\s*```[A-Za-z0-9_+-]*\\n([\\s\\S]*?)\\n?```\\s*$").find(body)
        if (f != null) body = f.groupValues[1]
        return Triple(m.groupValues[1], JSONObject().put("path", m.groupValues[2]).put("content", body), closed)
    }

    /** يقبل <tool_call>، أو كتلة ```json، أو كائن JSON خام باسم أداة معروفة. */
    private fun extractCall(text: String): Pair<String, JSONObject>? {
        CALL_RE.find(text)?.let { m -> parseBody(m.groupValues[1])?.let { return it } }
        Regex("```(?:json|tool_call)?\\s*([\\s\\S]*?)```").findAll(text).forEach { m ->
            parseBody(m.groupValues[1])?.let { if (it.first in TOOLS) return it }
        }
        val s = text.indexOf("{\"name\"")
        if (s >= 0) parseBody(text.substring(s))?.let { if (it.first in TOOLS) return it }
        return null
    }

    /** يولّد ردًّا واحدًا ببث الرموز للواجهة. يعيد النص المرئي (بلا تفكير) كاملًا. */
    private suspend fun generateOnce(prompt: String, temp: Float): String {
        Crash.mark("توليد/قراءة الموجّه (${modelName})")
        val splitter = ThinkSplitter()
        val gate = ToolGate()
        val raw = StringBuilder()
        var hidden = 0
        var lastProg = 0
        val co = currentCoroutineContext()

        fun handle(segs: List<Seg>) {
            for (seg in segs) {
                if (seg.think) {
                    Bus.emit("think", seg.text)
                } else {
                    raw.append(seg.text)
                    val vis = gate.feed(seg.text)
                    if (vis.isNotEmpty()) Bus.emit("token", vis)
                    if (gate.triggered) {
                        hidden += seg.text.length
                        if (hidden - lastProg >= 300 || lastProg == 0) {
                            lastProg = hidden
                            Bus.emit("progress", "يكتب… $hidden حرف")
                        }
                    }
                }
            }
        }

        var stop = false
        var nTok = 0
        var tFirst = 0L
        llm.generate(prompt, MAX_NEW_TOKENS, temp) { piece ->
            nTok++
            if (nTok == 1) tFirst = System.nanoTime()
            else {
                val el = (System.nanoTime() - tFirst) / 1e9f
                if (el > 0.8f) tps = (nTok - 1) / el
            }
            handle(splitter.feed(piece))
            // نوقف التوليد فور اكتمال الاستدعاء (توفير وقت كبير) أو إذا بدأ النموذج يختلق نتيجة الأداة
            if (!stop) {
                val tail = if (raw.length > 40) raw.substring(raw.length - 40) else raw.toString()
                if (tail.contains("</tool_call>") || tail.contains("</write_file>") || tail.contains("</append_file>") ||
                    tail.contains("<tool_response")) stop = true
            }
            if (!stop) {
                val lim = if (chatMode) 400 else if (raw.contains("<write_file") || raw.contains("<append_file")) MAX_NEW_TOKENS else 900
                if (nTok >= lim) { stop = true; Bus.emit("status", "قطعتُ التوليد عند $lim رمزًا (حدّ الأمان)") }
            }
            co.isActive && !stop
        }
        handle(splitter.flush())
        val tail = gate.flush()
        if (tail.isNotEmpty()) Bus.emit("token", tail)
        var out = raw.toString()
        val k = out.indexOf("<tool_response")
        if (k >= 0) out = out.substring(0, k)
        Crash.mark("idle")
        return out.trim()
    }

    /** مسار الفيديو: يعيد true إن عالج الطلب بالكامل. */
    private fun flow(s: String, vararg details: String) =
        Bus.emit("flow", (listOf(s) + details.filter { it.isNotBlank() }).joinToString("\u0001"))

    /** يحقن مقتطف أول مهارة مناسبة في الرسالة نفسها (النماذج الصغيرة لا تستدعي use_skill من تلقاء نفسها). */
    private fun skillBlock(names: List<String>): String {
        val top = names.first()
        val body = (Skills.read(ctx, top) ?: "").substringAfter("---", "").substringAfter("---", Skills.read(ctx, top) ?: "").trim().take(1800)
        return "\n[Installed skill matching this request: $top — follow it where it applies]\n" + body +
            "\n[End of skill excerpt. Other matching skills: " + names.drop(1).joinToString(", ").ifEmpty { "none" } + " — call use_skill for full text]"
    }

    private suspend fun planBrief(userText: String): JSONObject? {
        val r = MediaTools.run(ctx, "plan ~/dirgham/video/spec.json", JSONObject().put("brief", VideoFlow.instruction(userText)), false, 120_000L)
        val line = r.lines().firstOrNull { it.startsWith("PLAN ") } ?: return null
        return try { JSONObject(line.removePrefix("PLAN ")) } catch (_: Exception) { null }
    }

    /** مونتاج ذكي: يفرّغ الصوت بالتوقيت (ترجمة/نص)، ويفكّك «شيت العناصر» إلى قطع، ويركّب مشاهد على إيقاع الكلام. */
    private suspend fun smartMontage(atts: List<VideoFlow.Att>): JSONObject? {
        val audio = atts.firstOrNull { it.kind == "audio" } ?: return null
        val imgs = atts.filter { it.kind == "image" }
        if (imgs.isEmpty()) return null
        flow("أحلّل المرفقات: صوت ${audio.name} (${audio.sec.toInt()} ث) + ${imgs.size} صورة")
        val (chunks, err) = MediaTools.transcribeTimed(ctx, audio.name)
        if (err != null) {
            flow("تعذّر فهم الصوت: $err")
            Bus.emit("status", "⚠ لن أضع ترجمة لأني لم أفهم الصوت: $err")
            return null
        }
        flow("فهمتُ الصوت: ${chunks.size} مقطعًا (${chunks.joinToString(" ") { it.third }.take(120)}…)")
        // هل الصور «شيت عناصر»؟ نفكّكها إلى قطع
        val pieces = ArrayList<String>()
        for (im in imgs.take(3)) {
            flow("أفحص ${im.name}: هل هي لوحة عناصر متعددة؟")
            val base = "out/" + im.name.substringBeforeLast('.').take(20)
            val r = MediaTools.splitPieces(ctx, JSONObject().put("src", im.name).put("out", base).put("min_area", 0.0008).put("max", 30))
            val files = r.lines().map { it.trim().substringBefore("  ") }.filter { it.startsWith("out/") && it.endsWith(".png") }
            if (files.size >= 6) { pieces.addAll(files); flow("${im.name}: لوحة عناصر → فصلتُ ${files.size} قطعة") } else flow("${im.name}: صورة واحدة عادية")
        }
        val scenes = JSONArray()
        val total = if (audio.sec > 1) audio.sec else chunks.last().second + 1.0
        for ((i, c) in chunks.withIndex()) {
            val start = if (i == 0) 0.0 else c.first
            val end = if (i + 1 < chunks.size) chunks[i + 1].first else total
            val sc = JSONObject().put("speaker", "narrator").put("text", c.third).put("sec", (end - start).coerceAtLeast(1.5))
            if (pieces.isEmpty()) sc.put("image", imgs[i % imgs.size].name).put("pan", if (i % 2 == 0) 0.6 else -0.6)
            scenes.put(sc)
        }
        val spec = JSONObject().put("scenes", scenes).put("audio", audio.name)
        if (pieces.isNotEmpty()) spec.put("compose", true).put("pieces", JSONArray(pieces)).put("grid", true)
        flow("بنيتُ ${scenes.length()} مشهدًا بترجمة من الكلام" + (if (pieces.isNotEmpty()) " وعناصر متحركة من اللوحة" else " وتنقّل بين الصور"))
        return spec
    }

    private suspend fun runVideo(userText: String): Boolean {
        val atts = VideoFlow.parseAtts(userText)
        val charMode = VideoFlow.wantsCharacters(VideoFlow.instruction(userText)) && atts.any { it.kind == "image" }
        flow("فهمتُ الطلب: فيديو (${if (charMode) "بشخصيات من صورك" else if (atts.isNotEmpty()) "مونتاج من مرفقاتك" else "من وصف نصي"})")
        var spec = if (charMode) null else (smartMontage(atts) ?: VideoFlow.slideshow(atts))
        if (spec != null) {
            Bus.emit("status", "🎬 مونتاج مباشر من الصور" + (if (atts.any { it.kind == "audio" }) " والصوت" else "") + " (دون توليد بالنموذج، لذا يكون سريعًا)")
            val bad = atts.filter { it.kind == "image" || it.kind == "audio" }.firstOrNull { !it.where.startsWith("~/") }
            if (bad != null) {
                Bus.emit("token", "الملف ${bad.name} لم يُنقل إلى Termux. اربط جسر Termux من «الإعدادات ← Termux» ثم أعد إرفاق الملفات وأرسل الطلب.")
                return true
            }
        } else {
            // بلا صور: أولًا مصمّم حتمي يقرأ الوصف (أشكال/ألوان/عناصر/موسيقى) بلا نموذج؛ ثم النموذج للحوارات فقط
            val planned = if (atts.isEmpty() && TermuxBridge.ensureBridge(ctx, 20_000)) planBrief(userText) else null
            if (planned != null) {
                flow("صمّمتُ الفيديو من وصفك مباشرة (دون قالب جاهز)", planned.optString("summary"))
                spec = planned
            }
        }
        if (spec == null) {
            val model = pickModel(userText) ?: return false
            Bus.emit("status", "🎬 طلب فيديو: أطلب من النموذج مشاهد قصيرة فقط…")
            Crash.mark("تحميل النموذج ${model.name}")
        llm.ensureLoaded(model, 8192)
        Crash.mark("idle")
            modelName = model.name
            val sys = "You write short video scene specs. Output ONLY one JSON object, no other text:\n" +
                "{\"title\":\"...\",\"names\":{\"A\":\"name1\",\"B\":\"name2\"},\"scenes\":[{\"speaker\":\"A\",\"text\":\"...\",\"sec\":4},{\"speaker\":\"B\",\"text\":\"...\",\"sec\":4}]}\n" +
                "Use 4 to 8 scenes. speaker is A, B or narrator; use A/B only if the user asked for a conversation between two characters, otherwise use narrator only. Write the texts in the user's language (Arabic by default), each under 90 characters."
            val msgs = listOf("system" to sys, "user" to VideoFlow.instruction(userText).take(1500))
            val prompt = llm.applyTemplate(msgs) ?: chatml(msgs)
            val sb = StringBuilder()
            val co = currentCoroutineContext()
            llm.generate(prompt, 700, 0.5f) { piece -> sb.append(piece); co.isActive }
            spec = VideoFlow.extractJson(sb.toString())
            if (spec == null || (spec.optJSONArray("scenes")?.length() ?: 0) == 0) {
                Bus.emit("status", "تعذّر على النموذج كتابة مشاهد صالحة؛ أعد صياغة الطلب بجملة أوضح.")
                return true
            }
            if (charMode) VideoFlow.assignCharacters(spec, atts.filter { it.kind == "image" })
            spec.put("voice", VideoFlow.wantsVoice(VideoFlow.instruction(userText)))
        }
        val r = tools.execute("make_video", JSONObject().put("spec", spec).put("out", "video/out.mp4"))
        history.add("user" to userText.take(2000))
        val ok = r.startsWith("Video created")
        val msg = if (ok) "تم إنشاء الفيديو وأُرسل في المحادثة. اضغط «تنزيل» لحفظه." else "تعذّر إنشاء الفيديو: " + Tools.clip(r, 300)
        history.add("assistant" to msg)
        Bus.emit("token", msg)
        return true
    }

    private val NEEDS_FILE = Regex("(موقع|صفحة|html|سكربت|برنامج|لعبة|تطبيق|website|web\\s?page|\\bscript\\b|\\bgame\\b|\\bapp\\b)", RegexOption.IGNORE_CASE)
    private val HEAVY = Regex("(كود|برمج|سكربت|موقع|صفحة|html|python|code|script|build|fix|اصلح|أصلح|عدّل|عدل|github|جيت|ملف|file|اكتب|اصنع|سوي|انشئ|أنشئ|حلل|zip|apk)", RegexOption.IGNORE_CASE)

    /** توجيه النموذج حسب المهمة: النموذج السريع (إن عُيّن) للدردشة والأسئلة القصيرة، والقوي للكود والملفات والمرفقات. */
    private fun pickModel(userText: String): java.io.File? {
        val strong = LlamaEngine.activeModel(ctx)
        val fastName = Settings.fastModel(ctx)
        if (fastName.isBlank()) return strong
        val fast = LlamaEngine.listModels(ctx).firstOrNull { it.name == fastName } ?: return strong
        val simple = userText.length < 160 && !userText.contains("[attached:") && !HEAVY.containsMatchIn(userText)
        return if (simple) fast else strong
    }


    private val SKILL_REQ = Regex("(ثبّ?ت|نزّ?ل|حمّ?ل|اضف|أضف|install|add).{0,25}(مهار|skill)", RegexOption.IGNORE_CASE)

    /** تثبيت المهارات من ملف مرفق (zip/md) برمجيًا بكل ملحقاتها، وتتبّع روابط GitHub إن كان الملف قائمة. */
    private suspend fun skillInstall(userText: String): Boolean {
        val instr = VideoFlow.instruction(userText)
        val pendingF = java.io.File(ctx.filesDir, "pending_skill_links.txt")
        val cont = pendingF.exists() && Regex("(كمل|أكمل|اكمل|تابع|continue)", RegexOption.IGNORE_CASE).containsMatchIn(instr) && instr.length < 80
        val req = SKILL_REQ.containsMatchIn(instr)
        if (!cont && !req) return false
        val atts = VideoFlow.parseAtts(userText)
        if (!cont && atts.isEmpty()) return false
        val ws = java.io.File(ctx.filesDir, "workspace/inputs")
        val lines = ArrayList<String>()
        val links = LinkedHashSet<String>()
        if (cont) {
            pendingF.readLines().filter { it.isNotBlank() }.forEach { links.add(it) }
        } else {
            for (a in atts) {
                if (a.kind == "zip") {
                    val d = java.io.File(ws, a.name.substringBeforeLast('.') + "_unzipped")
                    Bus.emit("progress", "أفتّش داخل ${a.name}…")
                    lines.addAll(SkillInstaller.fromDir(ctx, d))
                    if (lines.isEmpty()) d.walkTopDown().filter { it.isFile && it.name.endsWith(".md", true) }.take(40).forEach { r ->
                        Regex("https://github\\.com/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+").findAll(r.readText().take(300000)).forEach { links.add(it.value.trimEnd('.')) }
                    }
                } else if (a.name.endsWith(".md", true)) {
                    val f = java.io.File(ws, a.name)
                    if (f.isFile) {
                        val t = f.readText()
                        if (a.name.equals("SKILL.md", true) || Regex("(?m)^name:\\s*\\S").containsMatchIn(t.take(600))) {
                            val nm = SkillInstaller.nameOf(t, f.nameWithoutExtension)
                            Skills.save(ctx, nm, t.take(80000)); lines.add(nm + " — " + Skills.description(t).take(60))
                        } else Regex("https://github\\.com/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+").findAll(t.take(300000)).forEach { links.add(it.value.trimEnd('.')) }
                    }
                }
            }
        }
        flow("فهمتُ الطلب: تثبيت مهارات من الملف المرفق (أفتّش المجلدات عن SKILL.md وملحقاتها، ثم أتتبّع روابط GitHub إن كان قائمة)")
        history.add("user" to instr.take(1500))
        var note = ""
        if (lines.isEmpty() && links.size >= 1) {
            val token = Settings.githubToken(ctx)
            val cap = if (token.isNotBlank()) 120 else 45
            val all = links.toList().filter { !it.contains("/topics") }
            val batch = all.take(cap)
            Bus.emit("progress", "أتتبّع ${batch.size} مستودعًا وأنزّل مهاراتها…")
            lines.addAll(SkillInstaller.fromRepos(ctx, batch, token) { Bus.emit("progress", it) })
            val rest = all.drop(cap)
            if (rest.isNotEmpty()) { pendingF.writeText(rest.joinToString("\n")); note = "\nبقي ${rest.size} رابطًا لم أفحصه (حد معدل GitHub بلا توكن؛ أضف توكن في الإعدادات لرفع الحد). قل «كمل» لأتابع." }
            else pendingF.delete()
            note = "\nفحصتُ ${batch.size} مستودعًا." + note
        } else if (cont) pendingF.delete()
        val msg = if (lines.isNotEmpty())
            "ثبّتُّ ${lines.size} مهارة فعلًا بملحقاتها (على الجهاز، وتعمل بلا إنترنت):\n" + lines.take(40).joinToString("\n") { "• $it" } +
                (if (lines.size > 40) "\n… و${lines.size - 40} أخرى" else "") + note + "\nتجدها في الإعدادات ← المهارات المثبّتة، وسأستعملها حين تناسب المهمة."
        else "فتّشتُ الملف ولم أجد مهارة قابلة للتثبيت (لا SKILL.md ولا روابط مستودعات)." + note
        history.add("assistant" to msg)
        Bus.emit("token", msg)
        return true
    }

    private fun lastSpec(): JSONObject? = try {
        val f = java.io.File(ctx.filesDir, "last_video_spec.json")
        if (f.exists() && System.currentTimeMillis() - f.lastModified() < 6 * 3600_000L) JSONObject(f.readText()) else null
    } catch (_: Exception) { null }

    /** تعديل فيديو سابق (استبدال شخصية/خلفية بصورة مرفقة) دون إعادة كتابة السيناريو. */
    private suspend fun runVideoEdit(userText: String, spec: JSONObject): Boolean {
        val atts = VideoFlow.parseAtts(userText)
        val imgs = atts.filter { it.kind == "image" }
        if (imgs.isEmpty()) {
            Bus.emit("token", "أي صورة تريدني أضعها؟ أرفق الصورة مع الطلب (وقل أي شخصية تستبدل إن كان في الفيديو أكثر من واحدة).")
            history.add("user" to userText.take(2000)); history.add("assistant" to "طلبتُ إرفاق الصورة.")
            return true
        }
        val msg = VideoFlow.applyEdit(spec, VideoFlow.instruction(userText), imgs)
        Bus.emit("status", "🎬 تعديل الفيديو السابق: $msg")
        val r = tools.execute("make_video", JSONObject().put("spec", spec).put("out", "video/out_v2.mp4"))
        history.add("user" to userText.take(2000))
        val ok = r.startsWith("Video created")
        val m = if (ok) "تم تعديل الفيديو ($msg) وأُرسل النسخة الجديدة في المحادثة." else "تعذّر تعديل الفيديو: " + Tools.clip(r, 300)
        history.add("assistant" to m)
        Bus.emit("token", m)
        return true
    }

    suspend fun run(userText: String, thinking: Boolean) {
        if (skillInstall(userText)) return
        val prevSpec = lastSpec()
        if (prevSpec != null && !userText.contains("[attached:") && VideoFlow.isAddToVideo(userText)) {
            val instr = VideoFlow.instruction(userText)
            flow("فهمتُ الطلب: تعديل الفيديو السابق بإضافة عنصر")
            val what = VideoFlow.addIcon(prevSpec, instr)
            history.add("user" to instr.take(1500))
            val m: String
            if (what == null) {
                m = "لا أعرف رسم هذا العنصر بنفسي. أرفق صورته (سأقصّها وأضعها في الفيديو)، أو أستطيع رسم: كرة، نجمة، قلب، شمس، قمر، شجرة، غيمة."
            } else {
                val r = tools.execute("make_video", JSONObject().put("spec", prevSpec).put("out", "video/out_v3.mp4"))
                m = if (r.startsWith("Video created")) "تم: $what، وأُرسلت النسخة الجديدة في المحادثة." else "تعذّر التعديل: " + Tools.clip(r, 300)
            }
            history.add("assistant" to m); Bus.emit("token", m)
            return
        }
        chatMode = !toolsEverUsed && !userText.contains("[attached:") && userText.length < 80 && !HEAVY.containsMatchIn(userText) &&
            !VideoFlow.isVideoRequest(userText) && history.size < 6
        if (prevSpec != null && VideoFlow.isVideoEdit(userText) && runVideoEdit(userText, prevSpec)) return
        if (VideoFlow.isVideoRequest(userText) && runVideo(userText)) return
        val model = pickModel(userText)
            ?: throw IllegalStateException("لا يوجد نموذج. افتح «الأدوات» ونزّل نموذجًا أو أضفه برابط.")
        val relevant = Skills.relevant(ctx, VideoFlow.instruction(userText), 3)
        flow("حلّلتُ الرسالة: ${if (userText.contains("[attached:")) "فيها مرفقات" else "نص فقط"}، النموذج: ${model.name}" +
            (if (relevant.isNotEmpty()) "، مهارات مناسبة: " + relevant.joinToString("، ") else ""))
        if (!llm.isLoaded() || modelName != model.name) Bus.emit("status", "تحميل ${model.name} إلى الرام…")
        llm.ensureLoaded(model, 8192)
        modelName = model.name
        run {
            val rep = llm.selfTest(ctx, false)
            if (rep.isNotEmpty()) Bus.emit("status", rep.trim())
        }

        history.add("user" to ((if (userText.length > 12000) userText.take(12000) + "\n…(قُصّ)" else userText) +
            (if (relevant.isNotEmpty()) skillBlock(relevant) else "")))
        tools.resetRun()
        var ran = 0
        var lastAnswer = ""
        var steps = 0
        var badFormat = 0
        var nudged = false
        val seen = HashMap<String, String>()
        var repeats = 0
        while (steps < MAX_STEPS && currentCoroutineContext().isActive) {
            steps++
            val answer = generateOnce(buildPrompt(!thinking), 0.6f)
            val fc = fileCall(answer)
            var truncated = false
            val call: Pair<String, JSONObject>? = if (fc != null) {
                truncated = !fc.third
                Pair(fc.first, fc.second)
            } else extractCall(answer)
            // نختصر محتوى الملف في السجل كي لا يمتلئ السياق ويبطؤ الرد
            history.add("assistant" to (if (fc != null) FILE_TAG.replace(answer) { m ->
                "<${m.groupValues[1]} path=\"${m.groupValues[2]}\">…(${m.groupValues[3].length} chars saved)…</${m.groupValues[1]}>" } else answer))
            lastAnswer = answer
            if (call == null) {
                if (ran == 0 && !nudged && !chatMode && !answer.contains("<tool_call>") && NEEDS_FILE.containsMatchIn(VideoFlow.instruction(userText))) {
                    nudged = true
                    flow("النموذج أجاب بالكلام دون إنشاء ملف", "أعيد الطلب مرة واحدة بصيغة إلزامية للملف")
                    history.add("user" to "You answered in words only, so NOTHING was created. Do the work now. Reply with ONLY the complete file in this exact format and nothing else:\n<write_file path=\"site/index.html\">\n...the full file content...\n</write_file>\n(change the path/extension if the task is not a website).")
                    continue
                }
                if (!answer.contains("<tool_call>")) break
                badFormat++
                if (badFormat > 1) { Bus.emit("status", "تعذّر فهم استدعاء الأداة"); break }
                history.add("user" to "<tool_response>Invalid call. Use exactly: <tool_call>{\"name\":\"TOOL\",\"arguments\":{...}}</tool_call></tool_response>")
                continue
            }
            val (name, args) = call
            if (name == "ask_user") {
                val q = args.optString("question").ifBlank { "هل يمكنك توضيح المطلوب؟" }
                history[history.size - 1] = "assistant" to q
                Bus.emit("token", "\n" + q)
                return
            }
            val sig = name + args.toString()
            val prev = seen[sig]
            if (prev != null) {
                repeats++
                if (repeats > 1) { Bus.emit("status", "تكرّر الاستدعاء نفسه؛ أوقفتُ الحلقة."); break }
                history.add("user" to "<tool_response>\nYou already ran this exact call. Its result was:\n${Tools.clip(prev, 600)}\nDo NOT call it again. Give the final answer to the user now, in Arabic, with no tool call.\n</tool_response>")
                continue
            }
            Bus.emit("tool", "$name " + Tools.clip(args.toString(), 140))
            var result = tools.execute(name, args).ifBlank { "(empty output)" }
            if (truncated) result += "\nWARNING: your output was cut off before the closing tag. Continue with <append_file path=\"${args.optString("path")}\"> starting exactly where the text ended, then close it."
            seen[sig] = result
            toolsEverUsed = true
            if (!result.startsWith("ERROR") && !result.startsWith("رفض")) ran++
            Bus.emit("tool", "← " + Tools.clip(result, 300))
            val next = when {
                truncated -> "Continue the file now."
                name == "use_skill" -> "The skill is loaded. Now DO the user's task following it: create the complete files with <write_file>, run them if needed, then deliver with send_file. Do not answer yet."
                name == "write_file" || name == "append_file" -> "File saved. Continue with the next step (more files, run it, or send_file to deliver). If everything is finished and delivered, answer briefly in Arabic."
                name == "send_file" -> "Delivered. Answer the user briefly in Arabic."
                else -> "Make the next call, or if the task is done answer briefly in Arabic with no tool call."
            }
            history.add("user" to "<tool_response>\n${Tools.clip(result)}\n</tool_response>\n$next")
        }
        if (steps >= MAX_STEPS) Bus.emit("status", "بلغتُ حدّ الخطوات ($MAX_STEPS). اكتب «تابع» للمواصلة.")

        // تسليم تلقائي: ما كُتب ولم يُرسل يظهر في المحادثة كبطاقة ملف (كما يسلّم Claude Code ناتجه)
        if (tools.written.isNotEmpty() && tools.sent.isEmpty()) {
            val okExt = setOf("html", "htm", "mp4", "mp3", "wav", "png", "jpg", "jpeg", "zip", "pdf", "txt", "md", "py", "js", "css", "json", "csv", "svg", "sh", "kt", "dart")
            val pick = tools.written.filter { it.substringAfterLast('.', "").lowercase() in okExt }.takeLast(3)
            for (p in pick) {
                val r = tools.execute("send_file", JSONObject().put("path", p))
                if (r.startsWith("Delivered")) Bus.emit("status", "📎 أُرسل الملف تلقائيًا: ${p.substringAfterLast('/')}")
            }
        }
        // حصيلة صادقة من التطبيق نفسه (لا من كلام النموذج)
        if (tools.written.isNotEmpty() || tools.sent.isNotEmpty()) {
            Bus.emit("status", "📋 الحصيلة الفعلية: كُتب ${tools.written.size} ملف" + (if (tools.sent.isNotEmpty()) " · أُرسل: " + tools.sent.joinToString("، ") else " · لم يُرسل شيء"))
        } else if (ran == 0 && Regex("تم (إنشاء|تثبيت|حفظ|إرسال|تصدير|تنفيذ)|أنشأت|ثبّتّ|ثبتّ|حفظت|صدّرت|created|installed|exported|saved").containsMatchIn(lastAnswer)) {
            Bus.emit("status", "⚠ لم تُنفَّذ أي أداة فعليًا في هذه المهمة؛ ما ادّعاه الرد أعلاه لم يحدث. أعد الطلب أو جرّب نموذجًا أكبر.")
        }

        // لا نُبقي سجلًّا طويلًا جدًا
        while (history.size > 24) history.removeAt(0)
    }

    /** فحص ذاتي: معلومات النموذج والنظام + توليد قصير بلا عشوائية. */
    suspend fun diagnose() {
        val model = LlamaEngine.activeModel(ctx)
            ?: throw IllegalStateException("لا يوجد نموذج للفحص.")
        Bus.emit("status", "تحميل ${model.name}…")
        llm.ensureLoaded(model, 8192)
        Bus.emit("tool", "فحص: ${model.name} (${model.length() / 1048576} MB)")
        Bus.emit("token", llm.info() + "\n\n")
        Bus.emit("token", llm.deepDiag(model) + "\n")
        Bus.emit("token", llm.selfTest(ctx, true) + "\n")
        val msgs = listOf("user" to "قل: مرحبا بك. ثم اكتب 2+2=")
        val prompt = llm.applyTemplate(msgs) ?: chatml(msgs)
        Bus.emit("token", "اختبار (بلا عشوائية):\n")
        llm.generate(prompt, 40, 0f) { Bus.emit("token", it); true }
    }
}
