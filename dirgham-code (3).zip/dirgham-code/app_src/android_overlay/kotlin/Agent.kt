package com.dirgham.code

import android.content.Context
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import org.json.JSONObject

/**
 * حلقة الوكيل: يولّد النموذج، فإن طلب أداة نفّذناها وأعدنا النتيجة إليه، ونكرر حتى يُنهي.
 * يعمل مع أي نموذج GGUF لأن القالب يُؤخذ من النموذج نفسه.
 */
class Agent(private val ctx: Context, private val llm: LlamaEngine) {

    private val tools = Tools(ctx)
    private val history = ArrayList<Pair<String, String>>() // (role, content) بلا رسالة النظام

    companion object {
        const val MAX_STEPS = 8
        const val MAX_NEW_TOKENS = 900
        const val HISTORY_CHARS = 12000
        private val TOOLS = setOf("list_files","read_file","write_file","delete_file","shell","termux_save","web_fetch","web_search",
            "github_get","github_put","github_runs","github_dispatch","list_skills","use_skill","install_skill","preview","open_app")
        private val CALL_RE = Regex("<tool_call>\\s*([\\s\\S]*?)\\s*(?:</tool_call>|\\z)")
    }

    private var modelName: String = ""

    fun clear() { history.clear() }

    private fun systemPrompt(): String {
        val skills = Skills.names(ctx).joinToString("\n") { n ->
            "- $n: " + Skills.description(Skills.read(ctx, n) ?: "")
        }
        return """You are "Dirgham Code", a local coding agent on an Android phone. Reply in the user's language (Arabic by default), briefly.
You act ONLY by calling tools. To call a tool, output exactly one line and then stop:
<tool_call>{"name":"TOOL","arguments":{...}}</tool_call>
Never use markdown code fences for tool calls. Never invent tool results; wait for <tool_response>.
After the result arrives, continue; when finished, give a short final answer with no tool call.
Use tools whenever the user asks to create/run/save files, search the web, open a URL, use GitHub, install or use a skill, or open an app.

Tools:
list_files {"path":"."} | read_file {"path":"a.txt"} | write_file {"path":"dir/a.py","content":"..."} | delete_file {"path":"a.txt"}
shell {"cmd":"python3 a.py"} (runs in Termux, user confirms) | web_fetch {"url":"https://..."} | web_search {"query":"..."}
github_get {"repo":"owner/name","path":"README.md"} | github_put {"repo":"owner/name","path":"f.txt","content":"...","message":"msg"}
github_runs {"repo":"owner/name"} | github_dispatch {"repo":"owner/name","workflow":"build-apk.yml","ref":"main"}
list_skills {} | use_skill {"name":"motion-graphics"} | install_skill {"name":"x","content":"# skill text"}
preview {"path":"a.html"} | open_app {"name":"capcut"}

Examples:
User: search the web for flutter news
<tool_call>{"name":"web_search","arguments":{"query":"flutter news"}}</tool_call>
User: write hello.py that prints hi and run it
<tool_call>{"name":"write_file","arguments":{"path":"hello.py","content":"print('hi')"}}</tool_call>
(after the result) <tool_call>{"name":"shell","arguments":{"cmd":"python3 hello.py"}}</tool_call>
User: install a skill called notes
<tool_call>{"name":"install_skill","arguments":{"name":"notes","content":"# notes\nHow to take notes..."}}</tool_call>
Before specialised work (motion graphics, Termux setup) call use_skill first.
Installed skills:
$skills"""
    }

    private fun buildPrompt(noThinkSuffix: Boolean): String {
        // نقتطع من الأقدم حتى تصغر الحصيلة، ونضمن أن تبدأ بدور user
        var start = 0
        var total = history.sumOf { it.second.length }
        while (total > HISTORY_CHARS && start < history.size - 1) {
            total -= history[start].second.length
            start++
        }
        while (start < history.size - 1 && history[start].first != "user") start++
        val msgs = ArrayList<Pair<String, String>>()
        msgs.add("system" to systemPrompt())
        for (i in start until history.size) {
            val (r, c) = history[i]
            val isLastUser = (i == history.size - 1) && r == "user"
            msgs.add(r to (if (isLastUser && noThinkSuffix && modelName.contains("qwen3", ignoreCase = true)) "$c /no_think" else c))
        }
        return llm.applyTemplate(msgs) ?: chatml(msgs)
    }

    private fun chatml(msgs: List<Pair<String, String>>): String {
        val sb = StringBuilder()
        for ((r, c) in msgs) sb.append("<|im_start|>").append(r).append('\n').append(c).append("<|im_end|>\n")
        sb.append("<|im_start|>assistant\n")
        return sb.toString()
    }

    private fun parseBody(body: String): Pair<String, JSONObject>? {
        val s = body.indexOf('{')
        val e = body.lastIndexOf('}')
        if (s < 0 || e <= s) return null
        return try {
            val j = JSONObject(body.substring(s, e + 1))
            val name = j.optString("name").ifEmpty { j.optString("tool") }
            if (name.isEmpty()) null
            else Pair(name, j.optJSONObject("arguments") ?: j.optJSONObject("parameters") ?: j.optJSONObject("args") ?: JSONObject())
        } catch (_: Exception) { null }
    }

    /** يقبل <tool_call>، أو كتلة ```json، أو كائن JSON خام باسم أداة معروفة. */
    private fun extractCall(text: String): Pair<String, JSONObject>? {
        CALL_RE.find(text)?.let { m -> parseBody(m.groupValues[1])?.let { return it } }
        Regex("```(?:json|tool_call)?\\s*([\\s\\S]*?)```").findAll(text).forEach { m ->
            parseBody(m.groupValues[1])?.let { if (it.first in TOOLS) return it }
        }
        val s = text.indexOf("{\"name\"")
        if (s >= 0) parseBody(text.substring(s))?.let { if (it.first in TOOLS) return it }
        return null
    }

    /** يولّد ردًّا واحدًا ببث الرموز للواجهة. يعيد النص المرئي (بلا تفكير) كاملًا. */
    private suspend fun generateOnce(prompt: String, temp: Float): String {
        val splitter = ThinkSplitter()
        val gate = ToolGate()
        val raw = StringBuilder()
        val co = currentCoroutineContext()

        fun handle(segs: List<Seg>) {
            for (seg in segs) {
                if (seg.think) {
                    Bus.emit("think", seg.text)
                } else {
                    raw.append(seg.text)
                    val vis = gate.feed(seg.text)
                    if (vis.isNotEmpty()) Bus.emit("token", vis)
                }
            }
        }

        llm.generate(prompt, MAX_NEW_TOKENS, temp) { piece ->
            handle(splitter.feed(piece))
            co.isActive
        }
        handle(splitter.flush())
        val tail = gate.flush()
        if (tail.isNotEmpty()) Bus.emit("token", tail)
        return raw.toString().trim()
    }

    suspend fun run(userText: String, thinking: Boolean) {
        val model = LlamaEngine.activeModel(ctx)
            ?: throw IllegalStateException("لا يوجد نموذج. افتح «الأدوات» ونزّل نموذجًا أو أضفه برابط.")
        Bus.emit("status", "تحميل ${model.name}…")
        llm.ensureLoaded(model, 8192)
        modelName = model.name
        run {
            val rep = llm.selfTest(ctx, false)
            if (rep.isNotEmpty()) Bus.emit("status", rep.trim())
        }

        history.add("user" to (if (userText.length > 12000) userText.take(12000) + "\n…(قُصّ)" else userText))
        var steps = 0
        var badFormat = 0
        while (steps < MAX_STEPS && currentCoroutineContext().isActive) {
            steps++
            val answer = generateOnce(buildPrompt(!thinking), 0.6f)
            history.add("assistant" to answer)
            val call = extractCall(answer)
            if (call == null) {
                if (!answer.contains("<tool_call>")) break
                badFormat++
                if (badFormat > 1) { Bus.emit("status", "تعذّر فهم استدعاء الأداة"); break }
                history.add("user" to "<tool_response>Invalid call. Use exactly: <tool_call>{\"name\":\"TOOL\",\"arguments\":{...}}</tool_call></tool_response>")
                continue
            }
            val (name, args) = call
            Bus.emit("tool", "$name " + Tools.clip(args.toString(), 140))
            val result = tools.execute(name, args)
            history.add("user" to "<tool_response>\n${Tools.clip(result)}\n</tool_response>")
        }
        if (steps >= MAX_STEPS) Bus.emit("status", "بلغتُ حدّ الخطوات ($MAX_STEPS). اكتب «تابع» للمواصلة.")

        // لا نُبقي سجلًّا طويلًا جدًا
        while (history.size > 24) history.removeAt(0)
    }

    /** فحص ذاتي: معلومات النموذج والنظام + توليد قصير بلا عشوائية. */
    suspend fun diagnose() {
        val model = LlamaEngine.activeModel(ctx)
            ?: throw IllegalStateException("لا يوجد نموذج للفحص.")
        Bus.emit("status", "تحميل ${model.name}…")
        llm.ensureLoaded(model, 8192)
        Bus.emit("tool", "فحص: ${model.name} (${model.length() / 1048576} MB)")
        Bus.emit("token", llm.info() + "\n\n")
        Bus.emit("token", llm.deepDiag(model) + "\n")
        Bus.emit("token", llm.selfTest(ctx, true) + "\n")
        val msgs = listOf("user" to "قل: مرحبا بك. ثم اكتب 2+2=")
        val prompt = llm.applyTemplate(msgs) ?: chatml(msgs)
        Bus.emit("token", "اختبار (بلا عشوائية):\n")
        llm.generate(prompt, 40, 0f) { Bus.emit("token", it); true }
    }
}
