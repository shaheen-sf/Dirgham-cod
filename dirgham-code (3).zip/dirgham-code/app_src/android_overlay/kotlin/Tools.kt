package com.dirgham.code

import android.content.Context
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** أدوات الوكيل. كل أداة تعيد نصًا قصيرًا يُعاد للنموذج كنتيجة. */
class Tools(private val ctx: Context) {

    private val root: File = File(ctx.filesDir, "workspace").also { it.mkdirs() }

    companion object {
        const val MAX_OUT = 2500

        val APPS = mapOf(
            "termux" to "com.termux",
            "capcut" to "com.lemon.lvoverseas",
            "كاب كات" to "com.lemon.lvoverseas",
            "elevenlabs" to "io.elevenlabs.app",
            "ايليفن لابز" to "io.elevenlabs.app"
        )

        fun clip(s: String, n: Int = MAX_OUT): String =
            if (s.length <= n) s else s.substring(0, n) + "\n…(قُصّ الإخراج، الطول الكلي ${s.length})"
    }

    private fun resolve(rel: String): File? {
        val clean = rel.trim().trimStart('/')
        val f = File(root, clean).canonicalFile
        val base = root.canonicalPath
        return if (f.path == base || f.path.startsWith(base + File.separator)) f else null
    }

    private fun str(a: JSONObject, k: String): String = a.optString(k, "")

    suspend fun execute(name: String, a: JSONObject): String {
        return try {
            when (name) {
                "list_files" -> listFiles(str(a, "path"))
                "read_file" -> readFile(str(a, "path"))
                "write_file" -> writeFile(str(a, "path"), str(a, "content"))
                "delete_file" -> deleteFile(str(a, "path"))
                "shell" -> shell(str(a, "cmd"))
                "termux_save" -> if (LocalBridge.connected()) writeFile(str(a, "path"), str(a, "content")) else termuxSave(str(a, "path"), str(a, "content"))
                "web_fetch" -> webFetch(str(a, "url"))
                "web_search" -> webSearch(str(a, "query"))
                "github_get" -> githubGet(str(a, "repo"), str(a, "path"))
                "github_put" -> githubPut(str(a, "repo"), str(a, "path"), str(a, "content"), str(a, "message"))
                "github_runs" -> githubRuns(str(a, "repo"))
                "github_dispatch" -> githubDispatch(str(a, "repo"), str(a, "workflow"), str(a, "ref"))
                "list_skills" -> listSkills()
                "use_skill" -> useSkill(str(a, "name"))
                "install_skill" -> installSkill(str(a, "name"), str(a, "url"), str(a, "content"))
                "preview" -> preview(str(a, "path"))
                "open_app" -> openApp(str(a, "name"))
                else -> "أداة غير معروفة: $name. الأدوات: list_files, read_file, write_file, delete_file, shell, termux_save, web_fetch, web_search, github_get, github_put, github_runs, github_dispatch, list_skills, use_skill, install_skill, preview, open_app"
            }
        } catch (e: SecurityException) {
            "خطأ صلاحيات: امنح التطبيق إذن تشغيل الأوامر في Termux (شاشة الأدوات)."
        } catch (e: Exception) {
            "خطأ: ${e.message}"
        }
    }

    // عند اتصال جسر Termux تكون ملفات الوكيل في ~/dirgham داخل Termux (كي يراها shell)،
    // وإلا فهي في مساحة عمل التطبيق المحلية.
    private fun termuxFs(): Boolean = LocalBridge.connected()

    private fun safeRel(p: String): String? {
        val c = p.trim().trimStart('/')
        if (c.isEmpty()) return "."
        if (c.contains("..") || c.contains("'") || c.contains("\n")) return null
        if (!Regex("^[A-Za-z0-9._/ \\-\\u0600-\\u06FF]{1,160}$").matches(c)) return null
        return c
    }

    private suspend fun tx(cmd: String, ms: Long = 60_000L): String = TermuxBridge.runCapture(ctx, cmd, ms)

    private suspend fun listFiles(path: String): String {
        if (termuxFs()) {
            val p = safeRel(path.ifBlank { "." }) ?: return "مسار غير مسموح"
            return clip(tx("mkdir -p ~/dirgham; cd ~/dirgham; ls -la -- '$p' 2>&1 | head -60"))
        }
        val d = resolve(path.ifBlank { "." }) ?: return "مسار غير مسموح"
        if (!d.exists()) return "غير موجود: $path"
        if (d.isFile) return "ملف: ${d.name} (${d.length()} بايت)"
        val items = (d.listFiles() ?: emptyArray()).sortedBy { it.name }
            .joinToString("\n") { (if (it.isDirectory) "[مجلد] " else "") + it.name + (if (it.isFile) " (${it.length()} بايت)" else "") }
        return if (items.isEmpty()) "(فارغ)" else clip(items)
    }

    private suspend fun readFile(path: String): String {
        if (termuxFs()) {
            val p = safeRel(path) ?: return "مسار غير مسموح"
            return clip(tx("head -c 20000 -- '$p' 2>&1"))
        }
        val f = resolve(path) ?: return "مسار غير مسموح"
        if (!f.isFile) return "الملف غير موجود: $path"
        return clip(f.readText())
    }

    private suspend fun writeFile(path: String, content: String): String {
        if (path.isBlank()) return "حدّد path"
        if (content.length > 200_000) return "المحتوى أكبر من 200 ألف حرف"
        if (termuxFs()) {
            val p = safeRel(path) ?: return "مسار غير مسموح (استعمل مسارًا نسبيًا بسيطًا)"
            val b64 = Base64.encodeToString(content.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
            val r = tx("mkdir -p ~/dirgham; cd ~/dirgham; mkdir -p \"\$(dirname '$p')\" && echo '$b64' | base64 -d > '$p' && echo saved")
            Bus.emit("tool", "كُتب في Termux: ~/dirgham/$p (${content.length} حرف)")
            return if (r.contains("saved")) "تم حفظ ~/dirgham/$p (${content.length} حرف)" else clip(r)
        }
        val f = resolve(path) ?: return "مسار غير مسموح"
        f.parentFile?.mkdirs()
        f.writeText(content)
        Bus.emit("tool", "كُتب: $path (${content.length} حرف)")
        return "تم حفظ $path (${content.length} حرف)"
    }

    private suspend fun deleteFile(path: String): String {
        if (termuxFs()) {
            val p = safeRel(path) ?: return "مسار غير مسموح"
            if (p == ".") return "لا يمكن حذف المجلد الجذر"
            if (!Confirm.ask("حذف في Termux", "~/dirgham/$p")) return "رفض المستخدم."
            return clip(tx("cd ~/dirgham && rm -rf -- '$p' && echo deleted"))
        }
        val f = resolve(path) ?: return "مسار غير مسموح"
        if (f == root) return "لا يمكن حذف المجلد الجذر"
        return if (f.exists() && f.deleteRecursively()) "حُذف $path" else "تعذّر الحذف أو غير موجود"
    }

    private suspend fun shell(cmd: String): String {
        if (cmd.isBlank()) return "حدّد cmd"
        if (!TermuxBridge.isInstalled(ctx)) return "Termux غير مثبّت. ثبّته من F-Droid."
        if (!TermuxBridge.available(ctx)) return "Termux غير موصول. افتح شاشة الأدوات ← Termux وشغّل أمر الجسر في Termux (أو امنح الإذن)."
        val ok = Confirm.ask("تنفيذ أمر في Termux", cmd)
        if (!ok) return "رفض المستخدم تنفيذ الأمر."
        Bus.emit("tool", "$ " + clip(cmd, 160))
        return clip(TermuxBridge.runCapture(ctx, cmd))
    }

    private suspend fun termuxSave(path: String, content: String): String {
        if (path.isBlank() || path.contains("..") || path.startsWith("/")) return "مسار غير صالح، استعمل مسارًا نسبيًا بلا .."
        if (!Regex("^[A-Za-z0-9._/-]{1,120}$").matches(path)) return "الأحرف المسموحة في المسار: حروف لاتينية وأرقام ._/-"
        if (content.length > 100_000) return "المحتوى كبير جدًا"
        if (!TermuxBridge.isInstalled(ctx)) return "Termux غير مثبّت."
        if (!TermuxBridge.hasPermission(ctx)) return "لم يُمنح إذن Termux."
        val ok = Confirm.ask("حفظ ملف في Termux", "~/dirgham/$path (${content.length} حرف)")
        if (!ok) return "رفض المستخدم."
        val b64 = Base64.encodeToString(content.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        val full = "dirgham/$path"
        val script = "mkdir -p \"\$(dirname '$full')\" && echo '$b64' | base64 -d > '$full' && echo saved:$full"
        Bus.emit("tool", "termux_save → ~/$full")
        return clip(TermuxBridge.runCapture(ctx, script, 60_000L))
    }

    private suspend fun webFetch(url: String): String = withContext(Dispatchers.IO) {
        if (!url.startsWith("https://")) return@withContext "يُسمح بروابط https فقط"
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.setRequestProperty("User-Agent", "DirghamCode/0.3")
        val code = c.responseCode
        if (code != 200) return@withContext "رد الخادم $code"
        val bytes = c.inputStream.use { it.readNBytesCompat(60_000) }
        var t = String(bytes, Charsets.UTF_8)
        if (t.contains("<html", ignoreCase = true)) {
            t = t.replace(Regex("(?is)<(script|style)[^>]*>.*?</\\1>"), " ")
                .replace(Regex("<[^>]+>"), " ")
                .replace(Regex("\\s+"), " ")
        }
        Bus.emit("tool", "web_fetch → $url")
        clip(t.trim())
    }

    private fun java.io.InputStream.readNBytesCompat(max: Int): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        val buf = ByteArray(8192)
        while (out.size() < max) {
            val n = read(buf)
            if (n < 0) break
            out.write(buf, 0, n)
        }
        return out.toByteArray()
    }

    private fun listSkills(): String {
        val names = Skills.names(ctx)
        if (names.isEmpty()) return "(لا توجد مهارات)"
        return names.joinToString("\n") { n -> "- $n: " + Skills.description(Skills.read(ctx, n) ?: "") }
    }

    private fun useSkill(name: String): String {
        val t = Skills.read(ctx, name.trim()) ?: return "لا توجد مهارة بهذا الاسم. استعمل list_skills."
        Bus.emit("tool", "مهارة: $name")
        return clip(t, 5000)
    }

    private suspend fun installSkill(name: String, url: String, content: String): String {
        if (!Regex("^[a-z0-9_-]{1,40}$").matches(name)) return "اسم المهارة: حروف لاتينية صغيرة وأرقام و - و _ فقط"
        var text = content
        if (text.isBlank() && url.isNotBlank()) {
            if (!url.startsWith("https://")) return "يُسمح بروابط https فقط"
            val ok = Confirm.ask("تثبيت مهارة من رابط", url)
            if (!ok) return "رفض المستخدم."
            text = withContext(Dispatchers.IO) {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 15000
                c.readTimeout = 20000
                c.setRequestProperty("User-Agent", "DirghamCode/0.3")
                if (c.responseCode != 200) "" else String(c.inputStream.use { it.readNBytesCompat(100_000) }, Charsets.UTF_8)
            }
            if (text.isBlank()) return "تعذّر تنزيل المهارة من الرابط"
        } else if (text.isNotBlank()) {
            val ok = Confirm.ask("تثبيت مهارة جديدة: $name", clip(text, 400))
            if (!ok) return "رفض المستخدم."
        } else {
            return "حدّد content أو url"
        }
        Skills.save(ctx, name, text)
        Bus.emit("tool", "ثُبّتت المهارة: $name")
        return "ثُبّتت المهارة $name"
    }

    private suspend fun preview(path: String): String {
        if (termuxFs()) {
            val p = safeRel(path) ?: return "مسار غير مسموح"
            val out = tx("cd ~/dirgham && base64 -w0 -- '$p' 2>&1").trim()
            val bytes = try { Base64.decode(out, Base64.DEFAULT) } catch (_: Exception) { return "تعذّر قراءة الملف: " + clip(out, 200) }
            val local = File(root, "termux_preview/$p")
            local.parentFile?.mkdirs()
            local.writeBytes(bytes)
            Bus.emit("preview", "termux_preview/$p")
            return "فُتحت المعاينة للمستخدم."
        }
        val f = resolve(path) ?: return "مسار غير مسموح"
        if (!f.isFile) return "الملف غير موجود: $path"
        Bus.emit("preview", path.trim().trimStart('/'))
        return "فُتحت المعاينة للمستخدم."
    }

    private fun openApp(name: String): String {
        val key = name.trim().lowercase()
        val pkg = APPS.entries.firstOrNull { key.contains(it.key) }?.value ?: key
        Bus.emit("openapp", pkg)
        return "طُلب فتح التطبيق $pkg"
    }

    // ---------------- بحث الويب وGitHub ----------------
    private fun unesc(s: String): String =
        s.replace(Regex("<[^>]+>"), "").replace("&amp;", "&").replace("&quot;", "\"").replace("&#x27;", "'")
            .replace("&lt;", "<").replace("&gt;", ">").replace(Regex("\\s+"), " ").trim()

    private suspend fun webSearch(query: String): String = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext "حدّد query"
        val url = "https://html.duckduckgo.com/html/?q=" + java.net.URLEncoder.encode(query, "UTF-8")
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
        val code = c.responseCode
        if (code != 200) return@withContext "رد محرك البحث $code"
        val html = String(c.inputStream.use { it.readNBytesCompat(300_000) }, Charsets.UTF_8)
        val links = Regex("class=\"result__a\"[^>]*href=\"([^\"]+)\"[^>]*>(.*?)</a>", RegexOption.DOT_MATCHES_ALL).findAll(html).toList()
        val snips = Regex("class=\"result__snippet\"[^>]*>(.*?)</a>", RegexOption.DOT_MATCHES_ALL).findAll(html).toList()
        if (links.isEmpty()) return@withContext "لا نتائج (أو تعذّر تحليل الصفحة)."
        val sb = StringBuilder()
        for (i in 0 until minOf(6, links.size)) {
            var href = links[i].groupValues[1]
            val m = Regex("uddg=([^&]+)").find(href)
            if (m != null) href = java.net.URLDecoder.decode(m.groupValues[1], "UTF-8")
            if (href.startsWith("//")) href = "https:$href"
            sb.append(i + 1).append(". ").append(unesc(links[i].groupValues[2])).append("\n   ").append(href).append('\n')
            if (i < snips.size) sb.append("   ").append(unesc(snips[i].groupValues[1])).append('\n')
        }
        Bus.emit("tool", "web_search → $query")
        clip(sb.toString(), 3500)
    }

    private val repoRe = Regex("^[A-Za-z0-9_.-]{1,60}/[A-Za-z0-9_.-]{1,100}$")

    private suspend fun gh(method: String, endpoint: String, body: JSONObject? = null): Pair<Int, String> = withContext(Dispatchers.IO) {
        val c = URL("https://api.github.com$endpoint").openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 25000
        c.requestMethod = method
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("User-Agent", "DirghamCode")
        val tok = Settings.githubToken(ctx)
        if (tok.isNotBlank()) c.setRequestProperty("Authorization", "Bearer $tok")
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val txt = stream?.use { String(it.readNBytesCompat(400_000), Charsets.UTF_8) } ?: ""
        Pair(code, txt)
    }

    private fun needToken(): String? =
        if (Settings.githubToken(ctx).isBlank()) "هذه العملية تحتاج رمز GitHub: افتح الأدوات ← GitHub والصق الرمز." else null

    private suspend fun githubGet(repo: String, path: String): String {
        if (!repoRe.matches(repo)) return "repo بصيغة owner/name"
        val p = path.trim().trimStart('/')
        if (p.contains("..")) return "مسار غير صالح"
        val (code, txt) = gh("GET", "/repos/$repo/contents/" + java.net.URI(null, null, p, null).rawPath)
        if (code != 200) return "GitHub رد $code: " + clip(txt, 300)
        Bus.emit("tool", "github_get → $repo/$p")
        return if (txt.trimStart().startsWith("[")) {
            val arr = org.json.JSONArray(txt)
            clip((0 until arr.length()).joinToString("\n") { val o = arr.getJSONObject(it); (if (o.optString("type") == "dir") "[مجلد] " else "") + o.optString("name") })
        } else {
            val o = JSONObject(txt)
            val enc = o.optString("content", "").replace("\n", "")
            if (enc.isEmpty()) "ملف بلا محتوى نصي" else clip(String(Base64.decode(enc, Base64.DEFAULT), Charsets.UTF_8), 6000)
        }
    }

    private suspend fun githubPut(repo: String, path: String, content: String, message: String): String {
        needToken()?.let { return it }
        if (!repoRe.matches(repo)) return "repo بصيغة owner/name"
        val p = path.trim().trimStart('/')
        if (p.isEmpty() || p.contains("..")) return "مسار غير صالح"
        if (content.length > 200_000) return "المحتوى كبير جدًا"
        val msg = message.ifBlank { "Update $p via Dirgham Code" }
        if (!Confirm.ask("كتابة إلى GitHub", "$repo/$p\n" + clip(content, 300))) return "رفض المستخدم."
        val ep = "/repos/$repo/contents/" + java.net.URI(null, null, p, null).rawPath
        val (c0, t0) = gh("GET", ep)
        val body = JSONObject()
            .put("message", msg)
            .put("content", Base64.encodeToString(content.toByteArray(Charsets.UTF_8), Base64.NO_WRAP))
        if (c0 == 200) body.put("sha", JSONObject(t0).optString("sha"))
        val (code, txt) = gh("PUT", ep, body)
        Bus.emit("tool", "github_put → $repo/$p")
        return if (code in 200..201) "تم الحفظ في $repo/$p" else "فشل ($code): " + clip(txt, 300)
    }

    private suspend fun githubRuns(repo: String): String {
        if (!repoRe.matches(repo)) return "repo بصيغة owner/name"
        val (code, txt) = gh("GET", "/repos/$repo/actions/runs?per_page=5")
        if (code != 200) return "GitHub رد $code: " + clip(txt, 300)
        val arr = JSONObject(txt).optJSONArray("workflow_runs") ?: return "لا توجد تشغيلات"
        Bus.emit("tool", "github_runs → $repo")
        return clip((0 until arr.length()).joinToString("\n") {
            val o = arr.getJSONObject(it)
            "#${o.optInt("run_number")} ${o.optString("name")} — ${o.optString("status")}/${o.optString("conclusion")} — ${o.optString("html_url")}"
        })
    }

    private suspend fun githubDispatch(repo: String, workflow: String, ref: String): String {
        needToken()?.let { return it }
        if (!repoRe.matches(repo)) return "repo بصيغة owner/name"
        if (!Regex("^[A-Za-z0-9_.-]{1,80}$").matches(workflow)) return "workflow: اسم الملف مثل build-apk.yml"
        val r = ref.ifBlank { "main" }
        if (!Confirm.ask("تشغيل سير عمل GitHub", "$repo / $workflow @ $r")) return "رفض المستخدم."
        val (code, txt) = gh("POST", "/repos/$repo/actions/workflows/$workflow/dispatches", JSONObject().put("ref", r))
        return if (code == 204) "بدأ التشغيل. افحص الحالة بـ github_runs." else "فشل ($code): " + clip(txt, 300)
    }
}
