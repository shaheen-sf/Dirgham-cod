package com.dirgham.code

import android.content.Context
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import org.json.JSONObject

/**
 * حلقة الوكيل: يولّد النموذج، فإن طلب أداة نفّذناها وأعدنا النتيجة إليه، ونكرر حتى يُنهي.
 * يعمل مع أي نموذج GGUF لأن القالب يُؤخذ من النموذج نفسه.
 */
class Agent(private val ctx: Context, private val llm: LlamaEngine) {

    private val tools = Tools(ctx)
    private val history = ArrayList<Pair<String, String>>() // (role, content) بلا رسالة النظام

    companion object {
        const val MAX_STEPS = 14
        const val MAX_NEW_TOKENS = 3200
        const val HISTORY_CHARS = 12000
        private val TOOLS = setOf("list_files","read_file","write_file","delete_file","shell","termux_save","web_fetch","web_search","make_video","send_file","append_file",
            "github_get","github_put","github_runs","github_dispatch","list_skills","use_skill","install_skill","preview","open_app")
        private val CALL_RE = Regex("<tool_call>\\s*([\\s\\S]*?)\\s*(?:</tool_call>|\\z)")
    }

    private var modelName: String = ""

    fun clear() { history.clear() }

    /** استرجاع محادثة محفوظة: مصفوفة JSON من {r:"user|assistant", c:"..."} */
    fun restore(json: String) {
        history.clear()
        try {
            val arr = org.json.JSONArray(json)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val r = o.optString("r")
                val c = o.optString("c")
                if ((r == "user" || r == "assistant") && c.isNotBlank()) history.add(r to c)
            }
        } catch (_: Exception) {}
        while (history.isNotEmpty() && history[0].first != "user") history.removeAt(0)
    }

    private fun systemPrompt(): String {
        val skills = Skills.names(ctx).joinToString("\n") { n ->
            "- $n: " + Skills.description(Skills.read(ctx, n) ?: "")
        }
        return """You are "Dirgham Code", a local coding agent on an Android phone. Reply in the user's language (Arabic by default), briefly.
RULES
1. You act only through tools. Never claim you did something unless a <tool_response> confirms it.
2. To CREATE or EDIT a file, use the file tag. Write the COMPLETE file, no JSON, no escaping:
<write_file path="site/index.html">
...full file content...
</write_file>
If a file is very long, write the first part, then continue next turn with <append_file path="site/index.html">...</append_file>.
3. For other tools output exactly one line and stop: <tool_call>{"name":"TOOL","arguments":{...}}</tool_call>
4. Deliver results to the user with send_file (it saves the file in Downloads and shows an Open button). Use it for any file, website, image, audio or video the user asked for.
5. Attached files are listed as [attached: name -> path]. You cannot see images/video or hear audio yourself; use shell tools (ffprobe, ffmpeg, python, unzip) to inspect or transform them.
6. When a skill is relevant, call use_skill first, then DO the work with tools following it. Reading a skill is not the work.
7. One tool call per reply. After the final tool result, answer briefly with no tool call.
8. For tasks with several steps, first write a numbered plan of 2-5 short lines, then start. To change part of an existing file use edit_file (small), not a full rewrite.
9. Skills are just text files stored on the phone; using one needs no internet. install_skill with "url" downloads a SKILL.md (needs internet); with "content" it only saves text you wrote. Never say a skill was downloaded unless you used url and the tool confirmed it.
10. If a tool result starts with ERROR, fix the problem and retry; never pretend it worked.

TOOLS (JSON form)
list_files {"path":"."} | read_file {"path":"a.txt"} | delete_file {"path":"a.txt"}
edit_file {"path":"a.html","old":"exact old text","new":"replacement"}
shell {"cmd":"python3 a.py"} (Termux, user confirms) | send_file {"path":"out/video.mp4"}
make_video {"out":"video/talk.mp4","title":"...","names":{"A":"Ahmad","B":"Sara"},"scenes":[{"speaker":"A","text":"...","sec":4},{"speaker":"B","text":"...","sec":4}]} (builds a finished MP4 and sends it; USE THIS for any video request, never write video code. A scene may have "image":"attached-name.png" (background photo with slow zoom); top-level "audio":"voice.mp3" uses an attached audio file and stretches scenes to its length)
web_fetch {"url":"https://..."} | web_search {"query":"..."}
github_get {"repo":"owner/name","path":"README.md"} | github_put {"repo":"owner/name","path":"f.txt","content":"...","message":"msg"}
github_runs {"repo":"owner/name"} | github_dispatch {"repo":"owner/name","workflow":"build-apk.yml","ref":"main"}
list_skills {} | use_skill {"name":"motion-graphics"} | install_skill {"name":"x","content":"# skill text"}
preview {"path":"a.html"} | open_app {"name":"capcut"}

EXAMPLES
User: make a page with a bouncing ball and give it to me
<write_file path="ball/index.html">
<!doctype html><html>...complete page...</html>
</write_file>
(after the result) <tool_call>{"name":"send_file","arguments":{"path":"ball/index.html"}}</tool_call>
User: make a short video where two people talk about coffee
<tool_call>{"name":"make_video","arguments":{"out":"video/coffee.mp4","title":"Coffee","names":{"A":"Ahmad","B":"Sara"},"scenes":[{"speaker":"A","text":"Do you like coffee?","sec":3},{"speaker":"B","text":"I love it every morning.","sec":3}]}}</tool_call>
User: search the web for flutter news
<tool_call>{"name":"web_search","arguments":{"query":"flutter news"}}</tool_call>
User: run hello.py
<tool_call>{"name":"shell","arguments":{"cmd":"python3 hello.py"}}</tool_call>
Installed skills:
$skills"""
    }

    private fun buildPrompt(noThinkSuffix: Boolean): String {
        // نقتطع من الأقدم حتى تصغر الحصيلة، ونضمن أن تبدأ بدور user
        var start = 0
        var total = history.sumOf { it.second.length }
        while (total > HISTORY_CHARS && start < history.size - 1) {
            total -= history[start].second.length
            start++
        }
        while (start < history.size - 1 && history[start].first != "user") start++
        val msgs = ArrayList<Pair<String, String>>()
        msgs.add("system" to systemPrompt())
        for (i in start until history.size) {
            val (r, c) = history[i]
            val isLastUser = (i == history.size - 1) && r == "user"
            msgs.add(r to (if (isLastUser && noThinkSuffix && modelName.contains("qwen3", ignoreCase = true)) "$c /no_think" else c))
        }
        return llm.applyTemplate(msgs) ?: chatml(msgs)
    }

    private fun chatml(msgs: List<Pair<String, String>>): String {
        val sb = StringBuilder()
        for ((r, c) in msgs) sb.append("<|im_start|>").append(r).append('\n').append(c).append("<|im_end|>\n")
        sb.append("<|im_start|>assistant\n")
        return sb.toString()
    }

    private fun parseBody(body: String): Pair<String, JSONObject>? {
        val s = body.indexOf('{')
        val e = body.lastIndexOf('}')
        if (s < 0 || e <= s) return null
        return try {
            val j = JSONObject(body.substring(s, e + 1))
            val name = j.optString("name").ifEmpty { j.optString("tool") }
            if (name.isEmpty()) null
            else Pair(name, j.optJSONObject("arguments") ?: j.optJSONObject("parameters") ?: j.optJSONObject("args") ?: JSONObject())
        } catch (_: Exception) { null }
    }

    private val FILE_TAG = Regex("<(write_file|append_file)\\s+path\\s*=\\s*[\"']([^\"']+)[\"']\\s*>\\n?([\\s\\S]*?)(?:</\\1>|\\z)")

    private fun fileCall(text: String): Triple<String, JSONObject, Boolean>? {
        val m = FILE_TAG.find(text) ?: return null
        var body = m.groupValues[3]
        val closed = text.contains("</" + m.groupValues[1] + ">")
        // إن لفّ النموذج المحتوى بسياج ``` نزيله
        val f = Regex("^\\s*```[A-Za-z0-9_+-]*\\n([\\s\\S]*?)\\n?```\\s*$").find(body)
        if (f != null) body = f.groupValues[1]
        return Triple(m.groupValues[1], JSONObject().put("path", m.groupValues[2]).put("content", body), closed)
    }

    /** يقبل <tool_call>، أو كتلة ```json، أو كائن JSON خام باسم أداة معروفة. */
    private fun extractCall(text: String): Pair<String, JSONObject>? {
        CALL_RE.find(text)?.let { m -> parseBody(m.groupValues[1])?.let { return it } }
        Regex("```(?:json|tool_call)?\\s*([\\s\\S]*?)```").findAll(text).forEach { m ->
            parseBody(m.groupValues[1])?.let { if (it.first in TOOLS) return it }
        }
        val s = text.indexOf("{\"name\"")
        if (s >= 0) parseBody(text.substring(s))?.let { if (it.first in TOOLS) return it }
        return null
    }

    /** يولّد ردًّا واحدًا ببث الرموز للواجهة. يعيد النص المرئي (بلا تفكير) كاملًا. */
    private suspend fun generateOnce(prompt: String, temp: Float): String {
        val splitter = ThinkSplitter()
        val gate = ToolGate()
        val raw = StringBuilder()
        var hidden = 0
        var lastProg = 0
        val co = currentCoroutineContext()

        fun handle(segs: List<Seg>) {
            for (seg in segs) {
                if (seg.think) {
                    Bus.emit("think", seg.text)
                } else {
                    raw.append(seg.text)
                    val vis = gate.feed(seg.text)
                    if (vis.isNotEmpty()) Bus.emit("token", vis)
                    if (gate.triggered) {
                        hidden += seg.text.length
                        if (hidden - lastProg >= 300 || lastProg == 0) {
                            lastProg = hidden
                            Bus.emit("progress", "يكتب… $hidden حرف")
                        }
                    }
                }
            }
        }

        var stop = false
        llm.generate(prompt, MAX_NEW_TOKENS, temp) { piece ->
            handle(splitter.feed(piece))
            // نوقف التوليد فور اكتمال الاستدعاء (توفير وقت كبير) أو إذا بدأ النموذج يختلق نتيجة الأداة
            if (!stop) {
                val tail = if (raw.length > 40) raw.substring(raw.length - 40) else raw.toString()
                if (tail.contains("</tool_call>") || tail.contains("</write_file>") || tail.contains("</append_file>") ||
                    tail.contains("<tool_response")) stop = true
            }
            co.isActive && !stop
        }
        handle(splitter.flush())
        val tail = gate.flush()
        if (tail.isNotEmpty()) Bus.emit("token", tail)
        var out = raw.toString()
        val k = out.indexOf("<tool_response")
        if (k >= 0) out = out.substring(0, k)
        return out.trim()
    }

    suspend fun run(userText: String, thinking: Boolean) {
        val model = LlamaEngine.activeModel(ctx)
            ?: throw IllegalStateException("لا يوجد نموذج. افتح «الأدوات» ونزّل نموذجًا أو أضفه برابط.")
        Bus.emit("status", "تحميل ${model.name}…")
        llm.ensureLoaded(model, 8192)
        modelName = model.name
        run {
            val rep = llm.selfTest(ctx, false)
            if (rep.isNotEmpty()) Bus.emit("status", rep.trim())
        }

        history.add("user" to (if (userText.length > 12000) userText.take(12000) + "\n…(قُصّ)" else userText))
        tools.resetRun()
        var ran = 0
        var lastAnswer = ""
        var steps = 0
        var badFormat = 0
        val seen = HashMap<String, String>()
        var repeats = 0
        while (steps < MAX_STEPS && currentCoroutineContext().isActive) {
            steps++
            val answer = generateOnce(buildPrompt(!thinking), 0.6f)
            val fc = fileCall(answer)
            var truncated = false
            val call: Pair<String, JSONObject>? = if (fc != null) {
                truncated = !fc.third
                Pair(fc.first, fc.second)
            } else extractCall(answer)
            // نختصر محتوى الملف في السجل كي لا يمتلئ السياق ويبطؤ الرد
            history.add("assistant" to (if (fc != null) FILE_TAG.replace(answer) { m ->
                "<${m.groupValues[1]} path=\"${m.groupValues[2]}\">…(${m.groupValues[3].length} chars saved)…</${m.groupValues[1]}>" } else answer))
            lastAnswer = answer
            if (call == null) {
                if (!answer.contains("<tool_call>")) break
                badFormat++
                if (badFormat > 1) { Bus.emit("status", "تعذّر فهم استدعاء الأداة"); break }
                history.add("user" to "<tool_response>Invalid call. Use exactly: <tool_call>{\"name\":\"TOOL\",\"arguments\":{...}}</tool_call></tool_response>")
                continue
            }
            val (name, args) = call
            val sig = name + args.toString()
            val prev = seen[sig]
            if (prev != null) {
                repeats++
                if (repeats > 1) { Bus.emit("status", "تكرّر الاستدعاء نفسه؛ أوقفتُ الحلقة."); break }
                history.add("user" to "<tool_response>\nYou already ran this exact call. Its result was:\n${Tools.clip(prev, 600)}\nDo NOT call it again. Give the final answer to the user now, in Arabic, with no tool call.\n</tool_response>")
                continue
            }
            Bus.emit("tool", "$name " + Tools.clip(args.toString(), 140))
            var result = tools.execute(name, args).ifBlank { "(empty output)" }
            if (truncated) result += "\nWARNING: your output was cut off before the closing tag. Continue with <append_file path=\"${args.optString("path")}\"> starting exactly where the text ended, then close it."
            seen[sig] = result
            if (!result.startsWith("ERROR") && !result.startsWith("رفض")) ran++
            Bus.emit("tool", "← " + Tools.clip(result, 300))
            val next = when {
                truncated -> "Continue the file now."
                name == "use_skill" -> "The skill is loaded. Now DO the user's task following it: create the complete files with <write_file>, run them if needed, then deliver with send_file. Do not answer yet."
                name == "write_file" || name == "append_file" -> "File saved. Continue with the next step (more files, run it, or send_file to deliver). If everything is finished and delivered, answer briefly in Arabic."
                name == "send_file" -> "Delivered. Answer the user briefly in Arabic."
                else -> "Make the next call, or if the task is done answer briefly in Arabic with no tool call."
            }
            history.add("user" to "<tool_response>\n${Tools.clip(result)}\n</tool_response>\n$next")
        }
        if (steps >= MAX_STEPS) Bus.emit("status", "بلغتُ حدّ الخطوات ($MAX_STEPS). اكتب «تابع» للمواصلة.")

        // تسليم تلقائي: ما كُتب ولم يُرسل يظهر في المحادثة كبطاقة ملف (كما يسلّم Claude Code ناتجه)
        if (tools.written.isNotEmpty() && tools.sent.isEmpty()) {
            val okExt = setOf("html", "htm", "mp4", "mp3", "wav", "png", "jpg", "jpeg", "zip", "pdf", "txt", "md", "py", "js", "css", "json", "csv", "svg", "sh", "kt", "dart")
            val pick = tools.written.filter { it.substringAfterLast('.', "").lowercase() in okExt }.takeLast(3)
            for (p in pick) {
                val r = tools.execute("send_file", JSONObject().put("path", p))
                if (r.startsWith("Delivered")) Bus.emit("status", "📎 أُرسل الملف تلقائيًا: ${p.substringAfterLast('/')}")
            }
        }
        // حصيلة صادقة من التطبيق نفسه (لا من كلام النموذج)
        if (tools.written.isNotEmpty() || tools.sent.isNotEmpty()) {
            Bus.emit("status", "📋 الحصيلة الفعلية: كُتب ${tools.written.size} ملف" + (if (tools.sent.isNotEmpty()) " · أُرسل: " + tools.sent.joinToString("، ") else " · لم يُرسل شيء"))
        } else if (ran == 0 && Regex("تم (إنشاء|تثبيت|حفظ|إرسال|تصدير|تنفيذ)|أنشأت|ثبّتّ|ثبتّ|حفظت|صدّرت|created|installed|exported|saved").containsMatchIn(lastAnswer)) {
            Bus.emit("status", "⚠ لم تُنفَّذ أي أداة فعليًا في هذه المهمة؛ ما ادّعاه الرد أعلاه لم يحدث. أعد الطلب أو جرّب نموذجًا أكبر.")
        }

        // لا نُبقي سجلًّا طويلًا جدًا
        while (history.size > 24) history.removeAt(0)
    }

    /** فحص ذاتي: معلومات النموذج والنظام + توليد قصير بلا عشوائية. */
    suspend fun diagnose() {
        val model = LlamaEngine.activeModel(ctx)
            ?: throw IllegalStateException("لا يوجد نموذج للفحص.")
        Bus.emit("status", "تحميل ${model.name}…")
        llm.ensureLoaded(model, 8192)
        Bus.emit("tool", "فحص: ${model.name} (${model.length() / 1048576} MB)")
        Bus.emit("token", llm.info() + "\n\n")
        Bus.emit("token", llm.deepDiag(model) + "\n")
        Bus.emit("token", llm.selfTest(ctx, true) + "\n")
        val msgs = listOf("user" to "قل: مرحبا بك. ثم اكتب 2+2=")
        val prompt = llm.applyTemplate(msgs) ?: chatml(msgs)
        Bus.emit("token", "اختبار (بلا عشوائية):\n")
        llm.generate(prompt, 40, 0f) { Bus.emit("token", it); true }
    }
}
