package com.dirgham.code

import android.content.Context

object Settings {
    private fun p(c: Context) = c.getSharedPreferences("dirgham", Context.MODE_PRIVATE)

    fun activeModel(c: Context): String = p(c).getString("model", "") ?: ""
    fun setActiveModel(c: Context, v: String) { p(c).edit().putString("model", v).apply() }

    fun thinking(c: Context): Boolean = p(c).getBoolean("thinking", false)
    fun setThinking(c: Context, v: Boolean) { p(c).edit().putBoolean("thinking", v).apply() }

    // ملف التشغيل المختار بالفحص الذاتي (فارغ = لم يُفحص بعد). يرتبط برقم البناء كي يُعاد الفحص بعد كل تحديث.
    fun profile(c: Context): String = p(c).getString("profile", "") ?: ""
    fun setProfile(c: Context, v: String) { p(c).edit().putString("profile", v).apply() }

    /** رمز سري ثابت لجسر Termux المحلي (يُولَّد مرة واحدة). */
    fun bridgeToken(c: Context): String {
        var v = p(c).getString("bridge_token", "") ?: ""
        if (v.length < 16) {
            val chars = "abcdefghijklmnopqrstuvwxyz0123456789"
            val r = java.security.SecureRandom()
            v = (1..24).map { chars[r.nextInt(chars.length)] }.joinToString("")
            p(c).edit().putString("bridge_token", v).apply()
        }
        return v
    }

    fun githubToken(c: Context): String = p(c).getString("github_token", "") ?: ""
    fun setGithubToken(c: Context, v: String) { p(c).edit().putString("github_token", v.trim()).apply() }
}
