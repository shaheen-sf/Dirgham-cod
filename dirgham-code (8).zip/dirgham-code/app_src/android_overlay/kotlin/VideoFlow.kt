package com.dirgham.code

import org.json.JSONArray
import org.json.JSONObject

/**
 * مسار الفيديو الحتمي: طلب الفيديو يُوجَّه برمجيًا إلى make_video (لا يترك النموذج الصغير يختار بين موقع وفيديو).
 * مع صور/صوت مرفقة يُبنى المونتاج مباشرة بلا أي توليد من النموذج (دقيقة أو أقل)، كأدوات المونتاج.
 */
object VideoFlow {
    data class Att(val name: String, val where: String, val kind: String, val sec: Double, val text: String)

    private val VIDEO = Regex("(فيديو|فديو|مونتاج|كليب|مقطع\\s+(?:فيديو|فديو)|\\bmp4\\b|\\bvideo\\b|\\bmontage\\b)", RegexOption.IGNORE_CASE)
    private val SITE = Regex("(موقع|صفحة|html|website|web\\s?page|تطبيق)", RegexOption.IGNORE_CASE)

    /** نص تعليمة المستخدم بلا أوصاف الملفات المرفقة. */
    fun instruction(t: String): String = t.substringBefore("[attached:").trim()

    fun isVideoRequest(t: String): Boolean {
        val i = instruction(t)
        return i.isNotEmpty() && VIDEO.containsMatchIn(i) && !SITE.containsMatchIn(i)
    }

    fun parseAtts(t: String): List<Att> {
        val out = ArrayList<Att>()
        val parts = t.split("[attached:").drop(1)
        for (p in parts) {
            val m = Regex("^\\s*(.+?) -> (.+?)\\]\\s*(image|video|audio|text file|zip|binary)?([\\s\\S]*)$").find(p) ?: continue
            val kind = m.groupValues[3].ifEmpty { "binary" }
            val rest = m.groupValues[4]
            val sec = Regex("([0-9]+(?:\\.[0-9]+)?) s").find(rest.take(120))?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0
            val text = if (kind == "text file") rest.substringAfter(":\n", "").trim() else ""
            out.add(Att(m.groupValues[1].trim(), m.groupValues[2].trim(), kind, sec, text))
        }
        return out
    }

    private fun sentences(s: String): List<String> =
        s.split(Regex("(?<=[.!؟?!])\\s+|\\n+")).map { it.trim() }.filter { it.length >= 4 }.take(60)

    /** مونتاج من الصور (+ صوت اختياري + نص اختياري كترجمة). يعيد null إن لم توجد صور. */
    fun slideshow(atts: List<Att>): JSONObject? {
        val imgs = atts.filter { it.kind == "image" }
        if (imgs.isEmpty()) return null
        val audio = atts.firstOrNull { it.kind == "audio" || (it.kind == "video" && false) }
        val script = atts.firstOrNull { it.kind == "text file" }?.text.orEmpty()
        val caps = sentences(script)
        val total = if (audio != null && audio.sec > 1) audio.sec else 4.0 * imgs.size
        val scenes = JSONArray()
        if (caps.isNotEmpty()) {
            val weights = caps.map { it.length.coerceAtLeast(8).toDouble() }
            val sum = weights.sum()
            caps.forEachIndexed { i, c ->
                val img = imgs[(i * imgs.size / caps.size).coerceIn(0, imgs.size - 1)]
                scenes.put(JSONObject().put("speaker", "narrator").put("text", c).put("image", img.name)
                    .put("sec", (total * weights[i] / sum).coerceAtLeast(1.5)))
            }
        } else {
            val n = if (total / imgs.size > 10) Math.ceil(total / 6.0).toInt() else imgs.size
            for (i in 0 until n) {
                scenes.put(JSONObject().put("speaker", "narrator").put("text", "")
                    .put("image", imgs[i % imgs.size].name).put("sec", total / n))
            }
        }
        val spec = JSONObject().put("scenes", scenes)
        if (audio != null) spec.put("audio", audio.name)
        return spec
    }

    /** يستخرج أول كائن JSON متوازن من ناتج النموذج. */
    fun extractJson(s: String): JSONObject? {
        val a = s.indexOf('{')
        if (a < 0) return null
        var depth = 0
        var inStr = false
        var esc = false
        for (i in a until s.length) {
            val c = s[i]
            if (inStr) { if (esc) esc = false else if (c == '\\') esc = true else if (c == '"') inStr = false; continue }
            when (c) {
                '"' -> inStr = true
                '{' -> depth++
                '}' -> { depth--; if (depth == 0) return try { JSONObject(s.substring(a, i + 1)) } catch (_: Exception) { null } }
            }
        }
        return null
    }
}
