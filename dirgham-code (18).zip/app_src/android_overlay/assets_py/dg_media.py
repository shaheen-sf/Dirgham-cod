#!/usr/bin/env python3
# Dirgham Code - أدوات وسائط: فيديو بطبقات متحركة + صور + تحليل. تعتمد Pillow فقط (و ffmpeg للفيديو).
# الاستعمال:
#   dg_media.py video spec.json out.mp4
#   dg_media.py image spec.json out.png      (يرسم المشهد الأول في نهايته)
#   dg_media.py edit  spec.json              ({"src","out","ops":[...]})
#   dg_media.py info  path                   (وصف نصي للصورة + OCR إن وُجد tesseract)
import glob, json, math, os, shutil, subprocess, sys
from PIL import Image, ImageChops, ImageDraw, ImageEnhance, ImageFilter, ImageFont, ImageOps

import unicodedata

def _build_forms():
    F = {}
    for cp in range(0xFB50, 0xFEFD):
        d = unicodedata.decomposition(chr(cp))
        if not d.startswith("<") or " " not in d: continue
        tag, rest = d.split(" ", 1)
        parts = rest.split()
        if len(parts) != 1: continue
        F.setdefault(chr(int(parts[0], 16)), {})[tag.strip("<>")] = chr(cp)
    return F
_FORMS = _build_forms()
_NOJOIN_NEXT = set("اأإآدذرزوؤءةى")   # لا تتصل بما بعدها
_LAM_ALEF = {"ا": "isolated", "أ": "isolated", "إ": "isolated", "آ": "isolated"}

def _joins_prev(c):   # يتصل بما قبله؟
    return c in _FORMS and ("final" in _FORMS[c] or "medial" in _FORMS[c])
def _is_ar(c):
    return "\u0600" <= c <= "\u06FF"

def _reshape(t):
    out = []; n = len(t); i = 0
    marks = set("\u064B\u064C\u064D\u064E\u064F\u0650\u0651\u0652\u0670")
    base = [c for c in t]
    while i < n:
        c = t[i]
        if c in marks or not _is_ar(c) or c not in _FORMS:
            out.append(c); i += 1; continue
        # سابق متصل؟
        j = len(out) - 1
        while j >= 0 and out[j] in marks: j -= 1
        prev = out[j] if j >= 0 else ""
        prev_orig = None
        # نبحث عن الحرف الأصلي السابق
        k = i - 1
        while k >= 0 and t[k] in marks: k -= 1
        prev_orig = t[k] if k >= 0 else ""
        pj = bool(prev_orig) and _is_ar(prev_orig) and prev_orig in _FORMS and prev_orig not in _NOJOIN_NEXT and ("initial" in _FORMS[prev_orig] or "medial" in _FORMS[prev_orig])
        # لام + ألف
        if c == "ل" and i + 1 < n and t[i + 1] in _LAM_ALEF:
            lig = {"ا": "\uFEFB", "أ": "\uFEF7", "إ": "\uFEF9", "آ": "\uFEF5"}[t[i + 1]]
            if pj:
                lig = chr(ord(lig) + 1)
            out.append(lig); i += 2; continue
        nj = i + 1 < n and _is_ar(t[i + 1]) and t[i + 1] in _FORMS and c not in _NOJOIN_NEXT and ("final" in _FORMS[t[i + 1]] or "medial" in _FORMS[t[i + 1]])
        f = _FORMS[c]
        form = ("medial" if pj and nj else "final" if pj else "initial" if nj else "isolated")
        out.append(f.get(form) or f.get("isolated") or c)
        i += 1
    return "".join(out)

def _bidi_visual(t):
    """ترتيب بصري مبسّط لسطر RTL: الكلمات تُعكس، وكتل اللاتيني/الأرقام تبقى بترتيبها."""
    import re
    runs = re.findall(r"[A-Za-z0-9][A-Za-z0-9.,:/%+_-]*|\s+|[^A-Za-z0-9\s]", t)
    res = []
    for r in runs:
        res.append(r if re.match(r"[A-Za-z0-9]", r) else r[::-1])
    return "".join(reversed(res))

try:
    import arabic_reshaper
    from bidi.algorithm import get_display
    def shape(s):
        return get_display(arabic_reshaper.reshape(s))
except Exception:
    def shape(s):
        if not any(_is_ar(c) for c in s):
            return s
        return _bidi_visual(_reshape(s))

HOME = os.path.expanduser("~/dirgham/")

def find_media(name):
    if not name:
        return None
    n = os.path.expanduser(str(name))
    for f in (n, os.path.join(HOME + "inputs/", n), os.path.join(HOME, n), os.path.join(HOME + "out/", n)):
        if os.path.exists(f):
            return f
    return None

def find_font():
    c = ["/system/fonts/NotoNaskhArabic-Regular.ttf", "/system/fonts/NotoSansArabic-Regular.ttf",
         "/system/fonts/NotoNaskhArabicUI-Regular.ttf", "/system/fonts/DroidNaskh-Regular.ttf"]
    c += sorted(glob.glob("/system/fonts/*Arab*.ttf")) + ["/system/fonts/Roboto-Regular.ttf",
         "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"]
    for f in c:
        if os.path.exists(f):
            return f
    return None
FP = find_font()
def set_font(name):
    global FP
    f = find_media(name)
    if f:
        FP = f; _fc.clear()
_fc = {}
def font(sz):
    sz = max(8, int(sz))
    if sz not in _fc:
        try:
            _fc[sz] = ImageFont.truetype(FP, sz, layout_engine=ImageFont.Layout.BASIC) if FP else ImageFont.load_default()  # BASIC: لا نعتمد على raqm (قد تختلف الأجهزة) فنشكّل ونعكس بأنفسنا
        except Exception:
            _fc[sz] = ImageFont.truetype(FP, sz) if FP else ImageFont.load_default()
    return _fc[sz]

def hexrgb(h, d=(24, 32, 56)):
    try:
        h = str(h).lstrip("#")
        if len(h) == 3: h = "".join(c * 2 for c in h)
        return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
    except Exception:
        return d

# ---------------- معالجة الصور ----------------
def cutout(im, thr=38):
    """إزالة الخلفية المتصلة بالحافة (للصور بلا شفافية). تحافظ على قناة ألفا إن وُجدت."""
    im = im.convert("RGBA")
    a = im.getchannel("A")
    if a.getextrema()[0] < 250:           # فيها شفافية أصلًا
        return im
    sm = im.copy(); sm.thumbnail((420, 420))
    w, h = sm.size
    px = sm.convert("RGB")
    corners = [px.getpixel(p) for p in ((0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1))]
    bg = tuple(sorted(c[i] for c in corners)[len(corners) // 2] for i in range(3))
    diff = ImageChops.difference(px, Image.new("RGB", (w, h), bg)).convert("L")
    fg = diff.point(lambda v: 255 if v > thr else 0)
    mask = fg.copy()
    for x in range(w):
        for y in (0, h - 1):
            if mask.getpixel((x, y)) == 0: ImageDraw.floodfill(mask, (x, y), 128)
    for y in range(h):
        for x in (0, w - 1):
            if mask.getpixel((x, y)) == 0: ImageDraw.floodfill(mask, (x, y), 128)
    alpha = mask.point(lambda v: 0 if v == 128 else 255)
    alpha = alpha.filter(ImageFilter.MinFilter(3)).filter(ImageFilter.GaussianBlur(1.2))
    alpha = alpha.resize(im.size, Image.BILINEAR)
    out = im.copy(); out.putalpha(alpha)
    return out

def autocrop(im, pad=4):
    im = im.convert("RGBA")
    bb = im.getchannel("A").point(lambda v: 255 if v > 12 else 0).getbbox()
    if not bb:
        return im
    x0, y0, x1, y1 = bb
    return im.crop((max(0, x0 - pad), max(0, y0 - pad), min(im.width, x1 + pad), min(im.height, y1 + pad)))

def crop_box(im, box):
    x, y, w, h = [float(v) for v in box]
    if max(x, y, w, h) <= 1.0:
        x, y, w, h = x * im.width, y * im.height, w * im.width, h * im.height
    return im.crop((int(x), int(y), int(x + w), int(y + h)))

def rounded(im, r):
    im = im.convert("RGBA")
    m = Image.new("L", im.size, 0)
    ImageDraw.Draw(m).rounded_rectangle([0, 0, im.width - 1, im.height - 1], radius=int(r), fill=255)
    im.putalpha(ImageChops.multiply(im.getchannel("A"), m))
    return im

def apply_ops(im, ops):
    for o in ops or []:
        k = o.get("op")
        if k == "crop": im = crop_box(im, o["box"])
        elif k == "autocrop": im = autocrop(im)
        elif k == "cutout": im = cutout(im, float(o.get("thr", 38)))
        elif k == "resize":
            w, h = o.get("w"), o.get("h")
            if w and not h: h = int(im.height * float(w) / im.width)
            if h and not w: w = int(im.width * float(h) / im.height)
            im = im.resize((int(w), int(h)), Image.LANCZOS)
        elif k == "fit":
            im = ImageOps.contain(im, (int(o["w"]), int(o["h"])))
        elif k == "rotate": im = im.convert("RGBA").rotate(float(o.get("deg", 0)), expand=True, resample=Image.BICUBIC)
        elif k == "flip": im = ImageOps.mirror(im)
        elif k == "brightness": im = ImageEnhance.Brightness(im.convert("RGB")).enhance(float(o.get("v", 1)))
        elif k == "contrast": im = ImageEnhance.Contrast(im.convert("RGB")).enhance(float(o.get("v", 1)))
        elif k == "blur": im = im.filter(ImageFilter.GaussianBlur(float(o.get("r", 2))))
        elif k == "rounded": im = rounded(im, float(o.get("r", 24)))
        elif k == "gray": im = ImageOps.grayscale(im).convert("RGBA")
    return im

_img_cache = {}
def load_img(src, ops=None, key=None):
    k = key or (src, json.dumps(ops, sort_keys=True))
    if k in _img_cache:
        return _img_cache[k]
    f = find_media(src)
    if not f:
        _img_cache[k] = None
        return None
    im = Image.open(f)
    if max(im.size) > 1800:
        im.thumbnail((1800, 1800))
    im = apply_ops(im.convert("RGBA"), ops)
    _img_cache[k] = im
    return im

# ---------------- الرسم ----------------
def ease(name, p):
    p = max(0.0, min(1.0, p))
    if name == "in": return p * p
    if name == "out": return 1 - (1 - p) * (1 - p)
    if name == "inout": return 3 * p * p - 2 * p * p * p
    if name == "back": c = 1.70158; return 1 + (c + 1) * (p - 1) ** 3 + c * (p - 1) ** 2
    return p

def prop(L, name, default, t):
    v = L.get(name, default)
    for a in L.get("anim", []) or []:
        if a.get("p") != name: continue
        t0, t1 = float(a.get("t0", 0)), float(a.get("t1", 1))
        if t < t0: v = a.get("from", v) if v == L.get(name, default) else v; continue
        p = 1.0 if t1 <= t0 else (t - t0) / (t1 - t0)
        e = ease(a.get("ease", "inout"), p)
        f, to = float(a.get("from", default)), float(a.get("to", default))
        v = f + (to - f) * e
    if name == "loop":
        pass
    return v

def paste_center(base, tile, cx, cy, alpha=1.0, rot=0.0):
    if rot:
        tile = tile.rotate(rot, expand=True, resample=Image.BICUBIC)
    if alpha < 0.999:
        tile = tile.copy(); tile.putalpha(tile.getchannel("A").point(lambda v: int(v * alpha)))
    base.paste(tile, (int(cx - tile.width / 2), int(cy - tile.height / 2)), tile)

def wrap(text, f, maxw, dr):
    words, lines, cur = str(text).split(), [], []
    for w in words:
        t = " ".join(cur + [w])
        if cur and dr.textlength(shape(t), font=f) > maxw:
            lines.append(" ".join(cur)); cur = [w]
        else:
            cur.append(w)
    if cur: lines.append(" ".join(cur))
    return lines

def text_tile(text, size, color, maxw):
    f = font(size)
    tmp = ImageDraw.Draw(Image.new("RGBA", (4, 4)))
    lines = wrap(text, f, maxw, tmp)
    lh = int(size * 1.4)
    wd = int(max([tmp.textlength(shape(l), font=f) for l in lines] + [10])) + 8
    tile = Image.new("RGBA", (wd, lh * len(lines) + 8), (0, 0, 0, 0))
    d = ImageDraw.Draw(tile)
    for k, l in enumerate(lines):
        s = shape(l); w = d.textlength(s, font=f)
        d.text(((wd - w) / 2, 4 + k * lh), s, font=f, fill=color + (255,))
    return tile

def draw_icon(name, size, col=None):
    """أيقونات مرسومة: ball star heart sun moon tree cloud (RGBA بحجم size)."""
    S = int(size) * 2
    tile = Image.new("RGBA", (S, S), (0, 0, 0, 0)); d = ImageDraw.Draw(tile)
    c = S / 2
    if name == "ball":
        d.ellipse([4, 4, S - 4, S - 4], fill=(250, 250, 250, 255), outline=(30, 30, 30, 255), width=max(3, S // 40))
        pent = [(c + math.cos(math.radians(a)) * S * 0.16, c + math.sin(math.radians(a)) * S * 0.16) for a in range(-90, 270, 72)]
        d.polygon(pent, fill=(25, 25, 25, 255))
        for a in range(-90, 270, 72):
            x, y = c + math.cos(math.radians(a)) * S * 0.30, c + math.sin(math.radians(a)) * S * 0.30
            x2, y2 = c + math.cos(math.radians(a)) * S * 0.46, c + math.sin(math.radians(a)) * S * 0.46
            d.line([(x, y), (x2, y2)], fill=(25, 25, 25, 255), width=max(3, S // 45))
            d.ellipse([x2 - S * 0.07, y2 - S * 0.07, x2 + S * 0.07, y2 + S * 0.07], fill=(25, 25, 25, 255))
    elif name == "star":
        pts = []
        for k in range(10):
            r = S * (0.47 if k % 2 == 0 else 0.2); a = math.radians(-90 + k * 36)
            pts.append((c + math.cos(a) * r, c + math.sin(a) * r))
        d.polygon(pts, fill=(255, 205, 60, 255), outline=(200, 140, 20, 255))
    elif name == "heart":
        d.ellipse([S * 0.08, S * 0.12, S * 0.52, S * 0.56], fill=(235, 60, 90, 255))
        d.ellipse([S * 0.48, S * 0.12, S * 0.92, S * 0.56], fill=(235, 60, 90, 255))
        d.polygon([(S * 0.1, S * 0.44), (S * 0.9, S * 0.44), (c, S * 0.92)], fill=(235, 60, 90, 255))
    elif name == "sun":
        for a in range(0, 360, 30):
            x, y = c + math.cos(math.radians(a)) * S * 0.46, c + math.sin(math.radians(a)) * S * 0.46
            d.line([(c + math.cos(math.radians(a)) * S * 0.34, c + math.sin(math.radians(a)) * S * 0.34), (x, y)], fill=(255, 190, 40, 255), width=max(4, S // 28))
        d.ellipse([S * 0.2, S * 0.2, S * 0.8, S * 0.8], fill=(255, 205, 70, 255))
    elif name == "moon":
        d.ellipse([S * 0.1, S * 0.1, S * 0.9, S * 0.9], fill=(250, 235, 170, 255))
        d.ellipse([S * 0.3, S * 0.02, S * 1.0, S * 0.8], fill=(0, 0, 0, 0))
        m = Image.new("L", (S, S), 255); ImageDraw.Draw(m).ellipse([S * 0.32, S * 0.04, S * 1.02, S * 0.78], fill=0)
        tile.putalpha(ImageChops.multiply(tile.getchannel("A"), m))
    elif name == "tree":
        d.rectangle([c - S * 0.06, S * 0.55, c + S * 0.06, S * 0.95], fill=(110, 75, 40, 255))
        for k, (y, r) in enumerate(((0.22, 0.3), (0.38, 0.34), (0.54, 0.38))):
            d.polygon([(c, S * (y - 0.18)), (c - S * r, S * (y + 0.2)), (c + S * r, S * (y + 0.2))], fill=(40, 140 + k * 15, 70, 255))
    elif name == "cloud":
        for (x0, y0, x1, y1) in ((0.1, 0.4, 0.5, 0.8), (0.3, 0.2, 0.7, 0.7), (0.5, 0.38, 0.92, 0.8), (0.2, 0.5, 0.82, 0.82)):
            d.ellipse([S * x0, S * y0, S * x1, S * y1], fill=(245, 248, 255, 255))
    elif name in ("lion", "tiger"):
        L_ = name == "lion"
        B = (222, 170, 90, 255) if L_ else (240, 140, 40, 255); D = (140, 90, 40, 255) if L_ else (30, 25, 20, 255)
        d.ellipse([S * 0.10, S * 0.36, S * 0.66, S * 0.70], fill=B)
        for lx in (0.16, 0.28, 0.46, 0.56):
            d.rounded_rectangle([S * lx, S * 0.60, S * (lx + 0.08), S * 0.88], radius=int(S * 0.03), fill=B)
        d.line([(S * 0.12, S * 0.46), (S * 0.02, S * 0.30), (S * 0.06, S * 0.22)], fill=D, width=max(3, int(S * 0.03)))
        if L_: d.ellipse([S * 0.52, S * 0.10, S * 0.96, S * 0.56], fill=(150, 95, 40, 255))      # اللبدة
        d.ellipse([S * 0.58, S * 0.18, S * 0.90, S * 0.52], fill=B)                               # الرأس
        if not L_:
            for k in range(4): d.line([(S * (0.22 + k * 0.1), S * 0.38), (S * (0.26 + k * 0.1), S * 0.52)], fill=D, width=max(3, int(S * 0.03)))
            for k in range(3): d.line([(S * (0.66 + k * 0.06), S * 0.20), (S * (0.68 + k * 0.06), S * 0.28)], fill=D, width=max(2, int(S * 0.02)))
            d.polygon([(S * 0.60, S * 0.20), (S * 0.62, S * 0.08), (S * 0.70, S * 0.18)], fill=B)
            d.polygon([(S * 0.80, S * 0.18), (S * 0.86, S * 0.08), (S * 0.88, S * 0.22)], fill=B)
        d.ellipse([S * 0.76, S * 0.34, S * 0.94, S * 0.48], fill=(245, 230, 205, 255))
        d.ellipse([S * 0.88, S * 0.35, S * 0.94, S * 0.40], fill=(30, 20, 20, 255))
        d.ellipse([S * 0.72, S * 0.27, S * 0.77, S * 0.32], fill=(20, 20, 20, 255))
    elif name == "dog":
        B = (176, 120, 70, 255); D = (120, 78, 42, 255)
        d.ellipse([S * 0.18, S * 0.36, S * 0.70, S * 0.68], fill=B)                      # الجسم
        for lx in (0.24, 0.34, 0.54, 0.62):                                               # الأرجل
            d.rounded_rectangle([S * lx, S * 0.58, S * (lx + 0.07), S * 0.86], radius=int(S * 0.03), fill=D)
        d.polygon([(S * 0.20, S * 0.44), (S * 0.04, S * 0.26), (S * 0.09, S * 0.50)], fill=B)   # الذيل
        d.ellipse([S * 0.56, S * 0.18, S * 0.90, S * 0.50], fill=B)                       # الرأس
        d.ellipse([S * 0.74, S * 0.32, S * 0.98, S * 0.48], fill=(215, 170, 120, 255))    # الخطم
        d.ellipse([S * 0.92, S * 0.33, S * 0.98, S * 0.39], fill=(25, 25, 25, 255))       # الأنف
        d.ellipse([S * 0.54, S * 0.14, S * 0.68, S * 0.40], fill=D)                       # الأذن
        d.ellipse([S * 0.74, S * 0.26, S * 0.79, S * 0.31], fill=(20, 20, 20, 255))       # العين
    else:
        d.ellipse([S * 0.2, S * 0.2, S * 0.8, S * 0.8], fill=(255, 140, 60, 255))
    return tile.resize((int(size), int(size)), Image.LANCZOS)

def draw_layer(im, L, t, W, H):
    typ = L.get("type", "rect")
    x = float(prop(L, "x", 0.5, t)) * W; y = float(prop(L, "y", 0.5, t)) * H
    if L.get("bob"): y += abs(math.sin(t * 3.2)) * -float(L["bob"]) * H
    face_left = False
    for o in L.get("osc", []) or []:   # حركة جيبية: {"p":"x|y|scale|alpha","amp":0.2,"hz":0.5,"ph":0}
        ang = 6.2832 * float(o.get("hz", 0.5)) * t + float(o.get("ph", 0))
        v = math.sin(ang) * float(o.get("amp", 0.1))
        pp = o.get("p")
        if pp == "x": x += v * W; face_left = math.cos(ang) * float(o.get("amp", 0.1)) < 0
        elif pp == "y": y += v * H
    sc = float(prop(L, "scale", 1.0, t)); al = float(prop(L, "alpha", 1.0, t)); rot = float(prop(L, "rot", 0.0, t))
    rot += float(L.get("spin", 0)) * t
    for o in L.get("osc", []) or []:
        v = math.sin(6.2832 * float(o.get("hz", 0.5)) * t + float(o.get("ph", 0))) * float(o.get("amp", 0.1))
        if o.get("p") == "scale": sc *= 1 + v
        elif o.get("p") == "alpha": al = max(0.0, min(1.0, al + v))
    w = float(L.get("w", 0.2)) * W * sc; h = float(L.get("h", 0.2)) * H * sc
    col = hexrgb(L.get("color", "#ffffff"))
    if typ in ("rect", "ellipse"):
        iw, ih = max(2, int(w)), max(2, int(h))
        tile = Image.new("RGBA", (iw, ih), (0, 0, 0, 0)); d = ImageDraw.Draw(tile)
        if typ == "rect":
            d.rounded_rectangle([0, 0, iw - 1, ih - 1], radius=int(float(L.get("radius", 0)) * min(iw, ih)), fill=col + (255,))
        else:
            d.ellipse([0, 0, iw - 1, ih - 1], fill=col + (255,))
        paste_center(im, tile, x, y, al, rot)
    elif typ in ("ring", "tri"):
        iw, ih = max(4, int(w)), max(4, int(h))
        tile = Image.new("RGBA", (iw, ih), (0, 0, 0, 0)); d = ImageDraw.Draw(tile)
        lw = max(2, int(float(L.get("lw", 0.012)) * min(iw, ih) * 4))
        if typ == "ring":
            d.ellipse([lw // 2, lw // 2, iw - 1 - lw // 2, ih - 1 - lw // 2], outline=col + (255,), width=lw)
        else:
            d.polygon([(iw / 2, lw), (lw, ih - lw), (iw - lw, ih - lw)], outline=col + (255,), fill=(col + (255,)) if L.get("fill") else None)
            if not L.get("fill"): d.line([(iw / 2, lw), (lw, ih - lw), (iw - lw, ih - lw), (iw / 2, lw)], fill=col + (255,), width=lw)
        paste_center(im, tile, x, y, al, rot)
    elif typ == "icon":
        ic = draw_icon(L.get("name", "star"), max(8, min(w, h)))
        if L.get("face") and face_left: ic = ImageOps.mirror(ic)
        paste_center(im, ic, x, y, al, rot)
    elif typ == "text":
        size = float(L.get("size", 0.06)) * H * sc
        tile = text_tile(L.get("text", ""), size, col, float(L.get("w", 0.8)) * W)
        paste_center(im, tile, x, y, al, rot)
    elif typ == "image":
        src = load_img(L.get("src"), L.get("ops"))
        if src is None: return
        tile = src
        if L.get("crop"): tile = crop_box(tile, L["crop"])
        if L.get("cutout"): tile = autocrop(cutout(tile))
        tw, th = tile.size
        if L.get("fit", "contain") == "cover":
            s = max(w / tw, h / th)
        else:
            s = min(w / tw, h / th) if (L.get("w") and L.get("h")) else (w / tw if L.get("w") else h / th)
        tile = tile.resize((max(2, int(tw * s)), max(2, int(th * s))), Image.BILINEAR)
        if bool(L.get("flip")) ^ bool(L.get("face") and face_left): tile = ImageOps.mirror(tile)
        paste_center(im, tile, x, y, al, rot)

def gradient(c1, c2, W, H):
    im = Image.new("RGB", (W, H), c1); px = ImageDraw.Draw(im)
    for y in range(H):
        t = y / H
        px.line([(0, y), (W, y)], fill=tuple(int(c1[i] * (1 - t) + c2[i] * t) for i in range(3)))
    return im

def cover(im, w, h, z=1.0, px=0.0):
    """تغطية الإطار بالصورة؛ px من -1 إلى 1 يزيح القصّ أفقيًا (حركة تنقّل)."""
    sw, sh = im.size
    s = max(w / sw, h / sh) * z
    nw, nh = int(sw * s) + 1, int(sh * s) + 1
    r = im.resize((nw, nh), Image.BILINEAR)
    x, y = (nw - w) // 2 + int(px * max(0, (nw - w) // 2)), (nh - h) // 2
    x = max(0, min(nw - w, x))
    return r.crop((x, y, x + w, y + h))

_pieces_cache = {}
def load_pieces(spec):
    k = json.dumps(spec.get("pieces") or [])
    if k in _pieces_cache: return _pieces_cache[k]
    bg, props = None, []
    for p in spec.get("pieces") or []:
        im = load_img(p, None, key=("piece", p))
        if im is None: continue
        if im.width / max(1, im.height) > 1.4 and im.width * im.height > 0.04 * 1e6 and bg is None and im.width > 300:
            bg = (im if bg is None else bg)
        props.append(im)
    if bg is None and props: bg = max(props, key=lambda i: i.width * i.height)
    props = [p for p in props if p is not bg]
    _pieces_cache[k] = (bg, props)
    return bg, props

def draw_compose(im, spec, idx, t, W, H):
    """يركّب مشهدًا من القطع المفصولة: خلفية + عناصر تظهر بالتتابع بحركة ارتداد وطفو. حتمي حسب رقم المشهد."""
    import random
    bg, props = load_pieces(spec)
    if not props and bg is None: return
    rnd = random.Random(idx * 104729 + 7)
    if bg is not None and idx % 3 == 0:
        im.paste(cover(bg.convert("RGB"), W, H, 1.0 + 0.04 * t / 4, math.sin(idx) * 0.3), (0, 0))
    if not props: return
    n = min(len(props), rnd.randint(3, 5))
    chosen = [props[(idx * 3 + k * 5 + rnd.randint(0, 2)) % len(props)] for k in range(n)]
    xs = sorted(rnd.uniform(0.1, 0.9) for _ in range(n))
    for k, p in enumerate(chosen):
        t0 = 0.25 + k * 0.35
        a = min(1.0, max(0.0, (t - t0) / 0.45))
        if a <= 0: continue
        e = ease("back", a)
        hh = rnd.uniform(0.2, 0.36) * H
        sc = hh / max(1, p.height)
        if p.width * sc > W * 0.4: sc = W * 0.4 / p.width
        tile = p.resize((max(2, int(p.width * sc * e)), max(2, int(p.height * sc * e))), Image.BILINEAR)
        cx = xs[k] * W; base = rnd.uniform(0.62, 0.88) * H
        bob = math.sin(t * 2.2 + k) * H * 0.008
        tile.putalpha(tile.getchannel("A").point(lambda v, a=a: int(v * a)))
        im.paste(tile, (int(cx - tile.width / 2), int(base - tile.height + bob)), tile)

PALS = [((22, 32, 64), (70, 30, 40)), ((18, 48, 58), (20, 20, 50)), ((50, 28, 60), (20, 30, 60)),
        ((60, 36, 20), (24, 24, 48)), ((20, 54, 44), (16, 28, 50)), ((40, 40, 70), (60, 24, 30))]
ACC = [(255, 140, 60), (255, 200, 90), (80, 210, 170), (120, 160, 255), (240, 90, 120)]

def grid_frame(im, W, H, accent=(255, 140, 60)):
    d = ImageDraw.Draw(im, "RGBA")
    step = max(24, W // 24)
    for x in range(0, W, step): d.line([(x, 0), (x, H)], fill=(255, 255, 255, 22))
    for y in range(0, H, step): d.line([(0, y), (W, y)], fill=(255, 255, 255, 22))
    m = int(W * 0.02)
    d.rectangle([m, m, W - m, H - m], outline=(255, 200, 90, 110), width=2)

def decor(im, idx, t, W, H):
    """زخارف متحركة تلقائية تنوّع المشاهد: دوائر عائمة + شريط لوني (لا تحتاج مواصفات من النموذج)."""
    import random
    rnd = random.Random(idx * 7919 + 13)
    lay = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    for k in range(5):
        r = rnd.uniform(0.04, 0.12) * H
        bx, by = rnd.uniform(0.05, 0.95) * W, rnd.uniform(0.1, 0.9) * H
        ph = rnd.uniform(0, 6.28); sp = rnd.uniform(0.6, 1.4)
        x = bx + math.sin(t * sp + ph) * W * 0.03; y = by + math.cos(t * sp * 0.8 + ph) * H * 0.04
        c = ACC[(idx + k) % len(ACC)]
        d.ellipse([x - r, y - r, x + r, y + r], fill=c + (46,))
    c = ACC[idx % len(ACC)]
    w = min(1.0, t / 0.6) * W * 0.28
    d.rounded_rectangle([W * 0.06, H * 0.075, W * 0.06 + w, H * 0.075 + 8], radius=4, fill=c + (255,))
    im.paste(lay, (0, 0), lay)

COL = {"A": (255, 140, 60), "B": (60, 200, 170)}
def drawn_character(im, cx, base, col, t, talking, W, H):
    d = ImageDraw.Draw(im)
    bob = math.sin(t * 6) * (H * 0.008)
    hr = H * 0.085; by = base + bob
    d.rounded_rectangle([cx - hr * 1.1, by - hr * 0.2, cx + hr * 1.1, by + hr * 2.0], radius=int(hr * 0.5), fill=col)
    d.ellipse([cx - hr, by - hr * 2.2, cx + hr, by - hr * 0.2], fill=(250, 220, 190))
    for ex in (-0.38, 0.38):
        d.ellipse([cx + ex * hr - 6, by - hr * 1.4 - 6, cx + ex * hr + 6, by - hr * 1.4 + 6], fill=(30, 30, 40))
    m = (abs(math.sin(t * 14)) * hr * 0.25 + 3) if talking else 3
    d.ellipse([cx - hr * 0.3, by - hr * 0.8, cx + hr * 0.3, by - hr * 0.8 + m * 2], fill=(120, 40, 40))

def char_image(spec, sp):
    c = (spec.get("characters") or {}).get(sp) or {}
    if not c.get("image"):
        return None
    k = ("char", c["image"], json.dumps(c.get("crop")))
    if k in _img_cache:
        return _img_cache[k]
    im = load_img(c["image"], None, key=("raw", c["image"]))
    if im is None:
        return None
    if c.get("crop"): im = crop_box(im, c["crop"])
    if not c.get("keep_bg"): im = cutout(im)
    im = autocrop(im)
    _img_cache[k] = im
    return im

def render_frame(spec, sc, t, n_total, W, H, photo=None, black=None, idx=0):
    if spec.get("style") == "stick":
        return render_stick(spec, sc, t, n_total, W, H, idx)
    pal = PALS[idx % len(PALS)]
    bgc = hexrgb(sc.get("bg"), pal[0]) if sc.get("bg") else pal[0]
    if photo is not None:
        z0, z1 = (sc.get("zoom") or [1.0, 1.08])
        pan = float(sc.get("pan", 0)) * (-1 + 2 * (t / max(0.01, n_total)))
        im = Image.blend(cover(photo, W, H, z0 + (z1 - z0) * (t / max(0.01, n_total)), pan), black, 0.38)
    else:
        im = gradient(bgc, pal[1] if not sc.get("bg") else tuple(max(0, c - 30) for c in bgc), W, H)
        if spec.get("grid"): grid_frame(im, W, H)
        if not sc.get("plain"): decor(im, idx, t, W, H)
        if spec.get("compose"): draw_compose(im, spec, idx, t, W, H)
    sp = str(sc.get("speaker", "narrator")); text = str(sc.get("text", ""))
    names = spec.get("names") or {}
    if sp in ("A", "B") and not sc.get("no_characters"):
        for who, cx in (("A", W * 0.2), ("B", W * 0.8)):
            if sc.get("solo") and who != sp: continue
            ci = char_image(spec, who)
            talking = (sp == who)
            if ci is not None:
                ch = H * 0.62
                s = ch / ci.height
                s *= 1.0 + (0.025 * math.sin(t * 14) if talking else 0.0)
                tile = ci.resize((max(2, int(ci.width * s)), max(2, int(ci.height * s))), Image.BILINEAR)
                if who == "B": tile = ImageOps.mirror(tile)
                bob = math.sin(t * 6) * H * 0.008
                im.paste(tile, (int(cx - tile.width / 2), int(H * 0.93 - tile.height + bob)), tile)
            else:
                drawn_character(im, cx, H * 0.62, COL[who], t, talking, W, H)
        nm = names.get(sp, sp)
        d = ImageDraw.Draw(im); s = shape(str(nm)); f = font(H * 0.04)
        d.text((W * (0.2 if sp == "A" else 0.8) - d.textlength(s, font=f) / 2, H * 0.94), s, font=f, fill=(240, 240, 240))
    for L in sc.get("layers", []) or []:
        try: draw_layer(im, L, t, W, H)
        except Exception: pass
    if text.strip():
        d = ImageDraw.Draw(im)
        F = font(H * 0.058)
        maxw = W * (0.5 if sp in ("A", "B") else 0.86)
        lines = wrap(text, F, maxw, d)
        lh = int(H * 0.058 * 1.5)
        bh = lh * len(lines) + 30; bw = max([d.textlength(shape(l), font=F) for l in lines] + [40]) + 50
        a = min(1.0, t / 0.5)
        bx = (W - bw) / 2
        by = (H * 0.95 - bh) if (photo is not None or spec.get("compose") or spec.get("subs")) else (H * 0.14 + (1 - a) * 25)
        d.rounded_rectangle([bx, by, bx + bw, by + bh], radius=26, fill=(255, 255, 255))
        for k, l in enumerate(lines):
            s = shape(l); w = d.textlength(s, font=F)
            d.text(((W - w) / 2, by + 15 + k * lh), s, font=F, fill=(25, 25, 35))
    return im


# ---------------- ستيكمان بمفاصل + هوية ضرغام البصرية ----------------
# الهوية: فحمي مائل للكحلي، إبراز ناري، ذهبي للعناصر التقنية، نقوش حضرمية (معينات ومثلثات)، ومرجع شخصية ضرغام.
ID = {"charcoal": (14, 16, 21), "navy": (17, 26, 43), "text": (242, 244, 248), "fire": (255, 106, 26), "gold": (242, 184, 60),
      "skin": (241, 218, 202), "cream": (234, 223, 204), "black": (26, 24, 24), "bronze": (139, 107, 74), "trim": (138, 128, 118),
      "line": (236, 238, 244), "ink": (22, 24, 32)}
POSES = ["idle", "talk", "wave", "point", "point_up", "shrug", "think", "surprised", "cheer", "sad", "angry", "hold", "walk", "run", "clap", "bow", "dance"]
EXPS = ["neutral", "happy", "sad", "shock", "angry", "smirk", "laugh", "think"]
PROPS = ["none", "calendar", "trophy", "clock", "mirror", "book", "bulb", "heart", "star", "coin", "phone", "hourglass", "key", "question", "exclaim", "door", "map", "money"]
SETS = ["room", "city", "night", "desert", "office", "plain"]
LOOKS = ["young", "old", "kid", "dirgham"]

def pose_angles(name, t, talk):
    P = dict(torso=0.0, head=0.0, rs=8.0, re=12.0, ls=8.0, le=12.0, rh=6.0, rk=6.0, lh=6.0, lk=6.0, dy=0.0, dx=0.0)
    s = math.sin; w = t * 2 * math.pi
    if name == "idle" and talk: name = "talk"
    if name == "idle": P.update(dy=0.5 * s(w * 0.9), re=12 + 3 * s(w * 0.9), le=12 + 3 * s(w * 0.9))
    elif name == "talk": P.update(rs=55 + 18 * s(w * 1.7), re=60, ls=12, head=2 * s(w * 2.1), dy=0.4 * s(w * 1.3))
    elif name == "wave": P.update(rs=150, re=28 * s(w * 2.2))
    elif name == "point": P.update(rs=95, re=0, torso=-3)
    elif name == "point_up": P.update(rs=168, re=0)
    elif name == "shrug": P.update(rs=40, ls=40, re=95, le=95, head=6, dy=-1.2 * abs(s(w * 0.8)))
    elif name == "think": P.update(rs=60, re=130, head=-6, ls=10)
    elif name == "surprised": P.update(rs=135, ls=135, re=20, le=20, torso=-4, dy=-0.8 + 0.3 * s(w * 6))
    elif name == "cheer":
        j = abs(s(w * 1.5)); P.update(rs=165, ls=165, re=10 * s(w * 3), le=10 * s(w * 3), dy=-9 * j, rk=8 + 30 * j, lk=8 + 30 * j)
    elif name == "sad": P.update(torso=6, head=14, rs=4, ls=4, re=6, le=6)
    elif name == "angry": P.update(rs=35, ls=35, re=110, le=110, torso=8, dx=0.5 * s(w * 9))
    elif name == "hold": P.update(rs=55, ls=55, re=70, le=70)
    elif name == "walk":
        a = 22 * s(w * 1.2); P.update(rh=a, lh=-a, rk=6 + max(0, 18 * s(w * 1.2 + 1.5)), lk=6 + max(0, 18 * s(w * 1.2 + 4.6)), rs=10 - 0.8 * a, ls=10 + 0.8 * a, dy=-0.8 * abs(s(w * 1.2)))
    elif name == "run":
        a = 34 * s(w * 2.0); P.update(rh=a, lh=-a, rk=10 + max(0, 40 * s(w * 2.0 + 1.5)), lk=10 + max(0, 40 * s(w * 2.0 + 4.6)), rs=45 - a, ls=45 + a, re=80, le=80, torso=10, dy=-2.2 * abs(s(w * 2.0)))
    elif name == "clap": P.update(rs=48, ls=48, re=100 - 35 * abs(s(w * 3)), le=100 - 35 * abs(s(w * 3)))
    elif name == "bow": P.update(torso=32, head=10, rs=4, ls=4)
    elif name == "dance":
        k = s(w * 1.5); P.update(rs=100 + 60 * k, ls=100 - 60 * k, re=15, le=15, dx=2 * s(w * 0.75), torso=6 * k, rh=10 * k, lh=-10 * k, dy=-1.2 * abs(k))
    return P

def _lim(x, y, ang, L):
    a = math.radians(ang); return (x + L * math.sin(a), y + L * math.cos(a))

def _limb(d, p1, p2, w, col):
    d.line([p1, p2], fill=col, width=max(1, int(w)))
    r = w / 2.0
    for q in (p1, p2): d.ellipse([q[0] - r, q[1] - r, q[0] + r, q[1] + r], fill=col)

def _face(d, c, r, u, exp, talk, t, ang, ink, brow_col):
    ca, sa = math.cos(math.radians(ang)), math.sin(math.radians(ang))
    def Pt(x, y): return (c[0] + (x * ca - y * sa) * u, c[1] + (x * sa + y * ca) * u)
    lw = max(2, int(0.55 * u))
    ex = 3.4; ey = -0.8
    def dot(x, y, rr=0.95):
        q = Pt(x, y); d.ellipse([q[0] - rr * u, q[1] - rr * u, q[0] + rr * u, q[1] + rr * u], fill=ink)
    def arc_eye(x, y, up=True):
        q = Pt(x, y); b = [q[0] - 1.5 * u, q[1] - 1.2 * u, q[0] + 1.5 * u, q[1] + 1.2 * u]
        d.arc(b, 200 if up else 20, 340 if up else 160, fill=ink, width=lw)
    mouth_open = (math.sin(t * 15) * 0.5 + 0.5) if talk else None
    if exp in ("happy", "laugh"): arc_eye(-ex, ey); arc_eye(ex, ey)
    elif exp == "shock":
        for sx in (-ex, ex):
            q = Pt(sx, ey); d.ellipse([q[0] - 1.7 * u, q[1] - 1.7 * u, q[0] + 1.7 * u, q[1] + 1.7 * u], outline=ink, width=lw)
            dot(sx, ey, 0.55)
    else:
        dot(-ex, ey); dot(ex, ey)
    if exp == "sad":
        for sx, k in ((-ex, 1), (ex, -1)): d.line([Pt(sx - 1.6 * k, ey - 2.6), Pt(sx + 1.6 * k, ey - 3.8)], fill=brow_col, width=lw)
    elif exp == "angry":
        for sx, k in ((-ex, 1), (ex, -1)): d.line([Pt(sx - 1.8 * k, ey - 3.6), Pt(sx + 1.8 * k, ey - 2.2)], fill=brow_col, width=lw)
    elif exp == "think":
        d.line([Pt(ex - 1.6, ey - 3.2), Pt(ex + 1.6, ey - 3.8)], fill=brow_col, width=lw)
    my = 3.6
    if mouth_open is not None and exp not in ("shock",):
        h = 0.5 + 1.9 * mouth_open; q1 = Pt(-1.8, my - h / 2); q2 = Pt(1.8, my + h)
        d.ellipse([min(q1[0], q2[0]), min(q1[1], q2[1]), max(q1[0], q2[0]), max(q1[1], q2[1])], fill=(120, 40, 44))
    elif exp == "happy": d.arc([Pt(-2.6, my - 2)[0], Pt(0, my - 2.2)[1], Pt(2.6, my)[0], Pt(0, my + 1.6)[1]], 10, 170, fill=ink, width=lw)
    elif exp == "laugh":
        q1 = Pt(-2.6, my - 1.2); q2 = Pt(2.6, my + 2.6); d.pieslice([q1[0], q1[1] - 1.2 * u, q2[0], q2[1]], 0, 180, fill=(120, 40, 44), outline=ink)
    elif exp == "sad": d.arc([Pt(-2.2, my)[0], Pt(0, my)[1], Pt(2.2, my)[0], Pt(0, my + 2.4)[1]], 200, 340, fill=ink, width=lw)
    elif exp == "shock":
        q = Pt(0, my + 0.6); d.ellipse([q[0] - 1.2 * u, q[1] - 1.5 * u, q[0] + 1.2 * u, q[1] + 1.5 * u], fill=(120, 40, 44), outline=ink)
    elif exp == "angry": d.line([Pt(-2.2, my + 0.6), Pt(-0.7, my), Pt(0.7, my + 0.6), Pt(2.2, my)], fill=ink, width=lw)
    elif exp == "smirk": d.line([Pt(-2.0, my + 0.4), Pt(1.0, my + 0.4), Pt(2.4, my - 0.7)], fill=ink, width=lw)
    else: d.line([Pt(-1.8, my + 0.2), Pt(1.8, my + 0.2)], fill=ink, width=lw)

def draw_prop(d, name, cx, cy, u, t):
    """أدوات مرسومة بتصميمنا (مركزها cx,cy وحجمها ~16 وحدة)."""
    g, f, k, cr, tx = ID["gold"], ID["fire"], ID["ink"], ID["cream"], ID["text"]
    def R(x, y): return (cx + x * u, cy + y * u)
    def box(x0, y0, x1, y1, **kw): d.rectangle([R(x0, y0), R(x1, y1)], **kw)
    lw = max(2, int(0.5 * u))
    if name == "calendar":
        box(-7, -8, 7, 8, fill=cr, outline=k, width=lw); box(-7, -8, 7, -4, fill=f, outline=k, width=lw)
        for i in range(3):
            for j in range(3):
                q = R(-4 + i * 4, -1 + j * 3.2); d.ellipse([q[0] - 0.7 * u, q[1] - 0.7 * u, q[0] + 0.7 * u, q[1] + 0.7 * u], fill=k)
        d.line([R(-7, -4), R(7, 8)], fill=(200, 40, 40), width=lw + 1)
    elif name == "trophy":
        d.polygon([R(-6, -8), R(6, -8), R(4, 1), R(-4, 1)], fill=g, outline=k)
        d.arc([R(-10, -7)[0], R(-10, -7)[1], R(-4, 0)[0], R(-4, 0)[1]], 90, 270, fill=g, width=lw)
        d.arc([R(4, -7)[0], R(4, -7)[1], R(10, 0)[0], R(10, 0)[1]], 270, 90, fill=g, width=lw)
        box(-1, 1, 1, 5, fill=g); box(-4, 5, 4, 8, fill=g, outline=k)
    elif name == "clock":
        d.ellipse([R(-8, -8), R(8, 8)], fill=cr, outline=k, width=lw)
        a = t * 3; d.line([R(0, 0), R(5 * math.sin(a), -5 * math.cos(a))], fill=k, width=lw); d.line([R(0, 0), R(0, -3.5)], fill=k, width=lw)
    elif name == "mirror":
        d.ellipse([R(-7, -10), R(7, 4)], fill=(150, 200, 230), outline=g, width=lw + 1); box(-1, 4, 1, 9, fill=g)
        d.line([R(-3, -6), R(0, -8)], fill=(255, 255, 255), width=lw)
    elif name == "book":
        box(-8, -6, 8, 6, fill=(60, 90, 160), outline=k, width=lw); box(-6, -4, 6, 4, fill=cr); d.line([R(0, -4), R(0, 4)], fill=k, width=lw)
    elif name == "bulb":
        d.ellipse([R(-6, -9), R(6, 3)], fill=g, outline=k, width=lw); box(-3, 3, 3, 7, fill=ID["trim"], outline=k)
        for a in range(-60, 61, 40):
            r0, r1 = 8, 11; q0 = R(r0 * math.sin(math.radians(a)), -3 - r0 * math.cos(math.radians(a))); q1 = R(r1 * math.sin(math.radians(a)), -3 - r1 * math.cos(math.radians(a)))
            d.line([q0, q1], fill=g, width=lw)
    elif name == "heart":
        d.ellipse([R(-7, -6), R(0, 1)], fill=(230, 60, 90)); d.ellipse([R(0, -6), R(7, 1)], fill=(230, 60, 90)); d.polygon([R(-7, -2), R(7, -2), R(0, 8)], fill=(230, 60, 90))
    elif name == "star":
        pts = []
        for i in range(10):
            rr = 9 if i % 2 == 0 else 4; a = math.radians(-90 + i * 36 + t * 30); pts.append(R(rr * math.cos(a), rr * math.sin(a)))
        d.polygon(pts, fill=g, outline=k)
    elif name == "coin":
        d.ellipse([R(-7, -7), R(7, 7)], fill=g, outline=k, width=lw); d.ellipse([R(-4, -4), R(4, 4)], outline=k, width=lw)
    elif name == "phone":
        d.rounded_rectangle([R(-4.5, -8), R(4.5, 8)], radius=int(u), fill=k, outline=tx, width=lw); box(-3.3, -6, 3.3, 5, fill=(90, 160, 230))
    elif name == "hourglass":
        d.polygon([R(-5, -8), R(5, -8), R(0, 0)], fill=g, outline=k); d.polygon([R(-5, 8), R(5, 8), R(0, 0)], fill=cr, outline=k); box(-6, -9, 6, -8, fill=k); box(-6, 8, 6, 9, fill=k)
    elif name == "key":
        d.ellipse([R(-8, -4), R(-1, 3)], outline=g, width=lw + 1); d.line([R(-1, 0), R(9, 0)], fill=g, width=lw + 1); d.line([R(6, 0), R(6, 4)], fill=g, width=lw + 1); d.line([R(9, 0), R(9, 3)], fill=g, width=lw + 1)
    elif name in ("question", "exclaim"):
        ch = "?" if name == "question" else "!"
        ff = font(int(u * 18)); sx = shape(ch); w = d.textlength(sx, font=ff); d.text((cx - w / 2, cy - u * 11), sx, font=ff, fill=f)
    elif name == "door":
        box(-6, -11, 6, 11, fill=(110, 72, 48), outline=k, width=lw); box(-4, -9, 4, 0, outline=k, width=lw); q = R(3, 2); d.ellipse([q[0] - 0.8 * u, q[1] - 0.8 * u, q[0] + 0.8 * u, q[1] + 0.8 * u], fill=g)
    elif name == "map":
        d.polygon([R(-9, -6), R(-3, -8), R(3, -6), R(9, -8), R(9, 6), R(3, 8), R(-3, 6), R(-9, 8)], fill=cr, outline=k)
        d.line([R(-6, 2), R(-1, -2), R(3, 1), R(7, -3)], fill=f, width=lw)
    elif name == "money":
        d.ellipse([R(-7, -4), R(7, 9)], fill=(70, 150, 90), outline=k, width=lw); d.polygon([R(-4, -4), R(0, -9), R(4, -4)], fill=(70, 150, 90), outline=k)
        ff = font(int(u * 9)); d.text((cx - u * 2, cy - u * 3), "$", font=ff, fill=cr)

def draw_figure(d, hip, u, look, P, exp, talk, t, flip, accent, prop=None):
    """يرسم شخصية واحدة على d. hip = موضع الحوض بالبكسل؛ u = وحدة البكسل لكل وحدة هيكل."""
    sx = -1.0 if flip else 1.0
    tor = math.radians(P["torso"])
    hx, hy = hip[0] + P["dx"] * u * sx, hip[1] + P["dy"] * u
    def T(x, y):   # إحداثي محلي متعلق بالجذع (يدور مع الميل)
        return (hx + sx * (x * math.cos(tor) - y * math.sin(tor)) * u, hy + (x * math.sin(tor) + y * math.cos(tor)) * u)
    def W2(x, y): return (hx + sx * x * u, hy + y * u)
    kid = look == "kid"; dirg = look == "dirgham"
    k = 0.8 if kid else (0.85 if dirg else 1.0)
    LW = max(3, int(2.0 * u)); line = ID["line"]
    leg = 13 if dirg else 20 * k; arm1, arm2 = 17 * k, 15 * k
    hr = 13 if dirg else (11 if kid else 9)
    sh = T(0, -27 * k)
    # أرجل
    for side, hh, kk in ((1, P["rh"], P["rk"]), (-1, P["lh"], P["lk"])):
        a1 = side * (hh + 2) * sx
        hp = W2(side * 3.2, 0)
        kn = _lim(hp[0], hp[1], a1, leg * u)
        ft = _lim(kn[0], kn[1], a1 - side * kk * sx, leg * u)
        colL = ID["black"] if dirg else line
        _limb(d, hp, kn, LW * (1.25 if dirg else 1), colL); _limb(d, kn, ft, LW * (1.25 if dirg else 1), colL)
        if dirg:
            d.rounded_rectangle([ft[0] - 3.4 * u, ft[1] - 0.6 * u, ft[0] + 3.4 * u, ft[1] + 1.8 * u], radius=int(u), fill=ID["black"], outline=ID["bronze"], width=max(1, int(0.5 * u)))
        else:
            fx = 1 if not flip else -1
            d.ellipse([min(ft[0] - 2 * u * fx, ft[0] + 2.6 * u * fx), ft[1] - 1 * u, max(ft[0] - 2 * u * fx, ft[0] + 2.6 * u * fx), ft[1] + 1.4 * u], fill=(90, 62, 46))
    # جذع
    nk = T(0, -30 * k)
    if dirg:
        # عباءة سوداء بحواف مزخرفة + ثوب كريمي + حزام + سيف (مرجع شخصية ضرغام)
        sway = 1.4 * math.sin(t * 3.1)
        tp = -27 * k
        robe = [T(-11, tp), T(11, tp), T(15 + sway, 2), T(19 + sway, 11), T(-19 - sway, 11), T(-15 - sway, 2)]
        d.polygon(robe, fill=ID["black"])
        d.polygon([T(-5.5, tp), T(5.5, tp), T(9.5, 11), T(-9.5, 11)], fill=ID["cream"])
        for sd in (-1, 1):
            d.line([T(sd * 11, tp), T(sd * 15, 2), T(sd * 19, 11)], fill=ID["trim"], width=max(2, int(1.3 * u)))
            for j in range(4):
                q = T(sd * (12 + j * 1.9), tp + 7 + j * 5); d.ellipse([q[0] - 0.7 * u, q[1] - 0.7 * u, q[0] + 0.7 * u, q[1] + 0.7 * u], fill=ID["trim"])
        d.line([T(-11.5, -5), T(11.5, -5)], fill=(50, 44, 44), width=max(3, int(2.6 * u)))
        q = T(-1, -5); d.ellipse([q[0] - 2 * u, q[1] - 2 * u, q[0] + 2 * u, q[1] + 2 * u], fill=ID["bronze"], outline=ID["black"])
        d.line([T(8, -6), T(13.5, 8)], fill=ID["bronze"], width=max(2, int(1.6 * u))); d.line([T(7.4, -8), T(9.2, -4)], fill=ID["black"], width=max(2, int(1.8 * u)))
        d.polygon([T(-11, tp - 2), T(11, tp - 2), T(8, tp + 3), T(-8, tp + 3)], fill=(34, 32, 32))   # وشاح العنق
        d.line([T(-8, tp), T(8, tp)], fill=(60, 56, 54), width=max(1, int(0.7 * u)))
    else:
        _limb(d, T(0, 0), nk, LW, line)
        if look == "young":   # وشاح ناري
            d.line([T(-4, -27), T(4, -27)], fill=accent, width=max(3, int(2.4 * u)))
            d.polygon([T(2, -27), T(5, -27), T(7, -17), T(3.5, -18)], fill=accent)
        elif look == "old":
            d.line([T(-4, -4), T(4, -4)], fill=ID["trim"], width=max(3, int(1.6 * u)))
    # أذرع
    hands = {}
    for side, ss, ee in ((1, P["rs"], P["re"]), (-1, P["ls"], P["le"])):
        a1 = side * ss * sx
        shp = T(side * 3.0, -27 * k)
        el = _lim(shp[0], shp[1], a1, arm1 * u)
        wr = _lim(el[0], el[1], a1 + side * ee * sx, arm2 * u)
        if dirg:
            _limb(d, shp, el, LW * 1.9, ID["black"]); _limb(d, el, wr, LW * 1.9, ID["black"])
            c0 = _lim(el[0], el[1], a1 + side * ee * sx, arm2 * 0.62 * u)
            _limb(d, c0, wr, LW * 1.35, ID["cream"])
            d.ellipse([wr[0] - 2.2 * u, wr[1] - 2.2 * u, wr[0] + 2.2 * u, wr[1] + 2.2 * u], fill=ID["skin"])
        else:
            _limb(d, shp, el, LW, line); _limb(d, el, wr, LW, line)
            d.ellipse([wr[0] - 1.6 * u, wr[1] - 1.6 * u, wr[0] + 1.6 * u, wr[1] + 1.6 * u], fill=ID["skin"], outline=ID["ink"])
        hands[side] = wr
    # رأس
    ha = P["torso"] + P["head"]
    hc = _lim(nk[0], nk[1], 180 + ha * sx, (hr + 1.5) * u)
    if dirg:
        d.ellipse([hc[0] - 12 * u, hc[1] - 4.5 * u, hc[0] - 9.2 * u, hc[1] + 1.5 * u], fill=ID["skin"]); d.ellipse([hc[0] + 9.2 * u, hc[1] - 4.5 * u, hc[0] + 12 * u, hc[1] + 1.5 * u], fill=ID["skin"])
    d.ellipse([hc[0] - hr * u, hc[1] - hr * u, hc[0] + hr * u, hc[1] + hr * u], fill=ID["skin"] if dirg else (248, 242, 232), outline=ID["ink"], width=max(2, int(0.6 * u)))
    if dirg:
        # وجه فارغ كالمرجع: لا ملامح؛ شعر أمامي مسنّن + عمامة من شرائح سوداء متراكبة
        for i, cx_ in enumerate((-7, -3.5, 0, 3.5, 7)):
            d.polygon([(hc[0] + (cx_ - 2.2) * u, hc[1] - 6.4 * u), (hc[0] + (cx_ + 2.2) * u, hc[1] - 6.4 * u), (hc[0] + (cx_ + (0.6 if i % 2 else -0.6)) * u, hc[1] - 1.0 * u)], fill=(24, 22, 22))
        cols = [(40, 37, 36), (24, 22, 22), (54, 50, 48), (30, 28, 27), (46, 42, 40)]
        for i in range(7):
            a = math.radians(-14 + i * 5 + 4 * math.sin(t * 1.3 + i))
            cxo, cyo = hc[0] + 1.2 * u * math.sin(a * 3), hc[1] - 10.5 * u
            d.ellipse([cxo - (17 - i * 0.9) * u, cyo - (12.5 - i * 0.9) * u + i * 0.8 * u, cxo + (17 - i * 0.9) * u, cyo + (6 - i * 0.2) * u], fill=cols[i % 5])
        for j in range(5):
            y0 = hc[1] - 21 * u + j * 3.4 * u
            d.arc([hc[0] - 15 * u, y0, hc[0] + 15 * u, y0 + 11 * u], 190 + j * 6, 350 - j * 6, fill=(70, 65, 62), width=max(1, int(0.55 * u)))
        tail = 3.0 * math.sin(t * 2.6)
        d.polygon([(hc[0] + 12 * u, hc[1] - 6 * u), (hc[0] + 16 * u, hc[1] - 3 * u), (hc[0] + (19 + tail) * u, hc[1] + 7 * u), (hc[0] + (14 + tail) * u, hc[1] + 5 * u)], fill=(30, 28, 27))
        if talk:   # لا فم: وهج ذهبي نابض حول الرأس يدل على أنه يتكلم
            gl = int(28 + 22 * math.sin(t * 12) ** 2)
            d.arc([hc[0] - 15 * u, hc[1] - 15 * u, hc[0] + 15 * u, hc[1] + 15 * u], 20, 160, fill=ID["gold"] + (gl * 4,), width=max(2, int(0.9 * u)))
    else:
        _face(d, hc, hr, u, exp, talk, t, ha * sx, ID["ink"], ID["ink"])
        if look == "young":
            for i in range(5): d.polygon([(hc[0] + (-6 + i * 3) * u, hc[1] - 7.2 * u), (hc[0] + (-3.6 + i * 3) * u, hc[1] - 7.2 * u), (hc[0] + (-4.6 + i * 3 + 0.8 * math.sin(t * 2 + i)) * u, hc[1] - 11.5 * u)], fill=ID["ink"], outline=line)
        elif look == "old":
            for i in range(6):
                q = (hc[0] + (-7 + i * 2.8) * u, hc[1] - 8.2 * u); d.arc([q[0] - 1.6 * u, q[1] - 2 * u, q[0] + 1.6 * u, q[1] + 1.2 * u], 180, 360, fill=(205, 205, 212), width=max(2, int(0.8 * u)))
            d.polygon([(hc[0] - 6.5 * u, hc[1] + 3 * u), (hc[0] + 6.5 * u, hc[1] + 3 * u), (hc[0] + 3 * u, hc[1] + 12 * u), (hc[0] - 3 * u, hc[1] + 12 * u)], fill=(215, 215, 222))
            _face(d, hc, hr, u, exp, talk, t, ha * sx, ID["ink"], ID["ink"])
        elif look == "kid":
            d.arc([hc[0] - 4 * u, hc[1] - 13 * u, hc[0] + 4 * u, hc[1] - 6 * u], 180, 360, fill=ID["ink"], width=max(2, int(1.2 * u)))
    if prop and prop[0] != "none":
        which = prop[1]
        w_ = hands.get(1 if which in ("A", "R") else -1) if which in ("hand", "A", "B") else None
        return hands
    return hands

def stage_bg(kind, W, H, idx):
    """خلفية ثابتة بالهوية: فحمي→كحلي + نقوش حضرمية + عنصر مكان."""
    im = gradient(ID["charcoal"], ID["navy"], W, H)
    lay = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    floor = int(H * 0.72)
    # معينات حضرمية خافتة
    st = max(40, W // 9)
    for gy in range(0, H, st):
        for gx in range(-st, W + st, st):
            ox = (st // 2) if (gy // st) % 2 else 0
            cx, cy = gx + ox, gy + st // 2; r = st * 0.22
            d.polygon([(cx, cy - r), (cx + r, cy), (cx, cy + r), (cx - r, cy)], outline=ID["gold"] + (20,))
    if kind == "city":
        import random as _r; rnd = _r.Random(idx + 5); x = -10
        while x < W:
            bw = rnd.randint(int(W * 0.10), int(W * 0.18)); bh = rnd.randint(int(H * 0.22), int(H * 0.42))
            d.rectangle([x, floor - bh, x + bw, floor], fill=(30, 38, 58, 255))
            for k in range(0, bw - 14, 16):
                d.polygon([(x + k, floor - bh), (x + k + 8, floor - bh - 10), (x + k + 16, floor - bh)], fill=(30, 38, 58, 255))
            for wy in range(floor - bh + 20, floor - 20, 34):
                for wx in range(x + 12, x + bw - 12, 24):
                    d.rectangle([wx, wy, wx + 8, wy + 14], fill=(242, 184, 60, 150 if rnd.random() < 0.45 else 40))
            x += bw + rnd.randint(4, 14)
    elif kind == "night" or kind == "desert":
        import random as _r; rnd = _r.Random(idx + 9)
        for _ in range(40): q = (rnd.randint(0, W), rnd.randint(0, int(H * 0.5))); d.ellipse([q[0], q[1], q[0] + 3, q[1] + 3], fill=(255, 255, 255, rnd.randint(90, 220)))
        d.ellipse([W * 0.7, H * 0.09, W * 0.7 + 90, H * 0.09 + 90], fill=(242, 232, 200, 230))
        if kind == "desert":
            d.polygon([(0, floor), (W * 0.3, floor - H * 0.07), (W * 0.65, floor - H * 0.02), (W, floor - H * 0.08), (W, floor)], fill=(60, 44, 40, 255))
    elif kind == "room":
        d.rectangle([W * 0.68, floor - H * 0.36, W * 0.92, floor], fill=(80, 54, 40, 255), outline=(30, 20, 16, 255), width=4)
        d.ellipse([W * 0.08, H * 0.14, W * 0.08 + 80, H * 0.14 + 80], fill=(234, 223, 204, 255), outline=(22, 24, 32, 255), width=4)
        d.line([(W * 0.08 + 40, H * 0.14 + 40), (W * 0.08 + 40, H * 0.14 + 12)], fill=(22, 24, 32, 255), width=4); d.line([(W * 0.08 + 40, H * 0.14 + 40), (W * 0.08 + 62, H * 0.14 + 48)], fill=(22, 24, 32, 255), width=4)
    elif kind == "office":
        d.rectangle([W * 0.1, floor - H * 0.2, W * 0.5, floor - H * 0.17], fill=(70, 58, 52, 255)); d.rectangle([W * 0.12, floor - H * 0.17, W * 0.14, floor], fill=(70, 58, 52, 255)); d.rectangle([W * 0.46, floor - H * 0.17, W * 0.48, floor], fill=(70, 58, 52, 255))
        d.rectangle([W * 0.62, H * 0.16, W * 0.9, H * 0.3], fill=(50, 70, 100, 200), outline=(242, 184, 60, 160), width=3)
    d.rectangle([0, floor, W, H], fill=(10, 12, 17, 255)); d.line([(0, floor), (W, floor)], fill=ID["gold"] + (120,), width=3)
    # شريط مثلثات حضرمي أعلى الشاشة وأسفلها
    tw = max(18, W // 28)
    for x in range(0, W, tw):
        d.polygon([(x, 0), (x + tw, 0), (x + tw / 2, tw * 0.7)], fill=ID["gold"] + (70,))
        d.polygon([(x, H), (x + tw, H), (x + tw / 2, H - tw * 0.7)], fill=ID["gold"] + (70,))
    im = im.convert("RGBA"); im.alpha_composite(lay)
    return im.convert("RGB"), floor

_bg_cache = {}

def render_stick(spec, sc, t, secs, W, H, idx=0):
    kind = str(sc.get("set") or spec.get("set") or "plain")
    if kind not in SETS: kind = "plain"
    key = (kind, W, H, idx if kind in ("city", "night", "desert") else 0)
    if key not in _bg_cache:
        if len(_bg_cache) > 8: _bg_cache.clear()
        _bg_cache[key] = stage_bg(kind, W, H, idx)
    bg, floor = _bg_cache[key]
    im = bg.copy()
    looks = spec.get("looks") if isinstance(spec.get("looks"), dict) else {}
    sp = str(sc.get("speaker", "narrator"))
    fh = H * 0.40; u = fh / 100.0
    pre = min(1.0, t / 0.35); pre = 1 - (1 - pre) ** 3
    prop = str(sc.get("prop", "none")); prop_at = str(sc.get("prop_at", "center"))
    chars = []
    for who, cxr, flip in (("A", 0.27, False), ("B", 0.73, True)):
        if sc.get("solo") and who != sp and sp in ("A", "B"): continue
        if who == "B" and sc.get("only_a"): continue
        pose = str(sc.get("pose_" + who.lower(), "idle")); pose = pose if pose in POSES else "idle"
        exp = str(sc.get("exp_" + who.lower(), "neutral")); exp = exp if exp in EXPS else "neutral"
        look = str(looks.get(who, "young" if who == "A" else "old")); look = look if look in LOOKS else "young"
        chars.append((who, cxr, flip, pose, exp, look))
    tw, th = int(W * 0.60), int(fh * 1.34)
    held = {}
    for who, cxr, flip, pose, exp, look in chars:
        S = 2
        layer = Image.new("RGBA", (tw * S, th * S), (0, 0, 0, 0)); d = ImageDraw.Draw(layer)
        talk = (sp == who)
        P = pose_angles(pose, t, talk)
        uu = u * S * (0.88 + 0.12 * pre)
        footy = th * S - 0.08 * fh * S
        hip = (tw * S / 2, footy - (26 if look == "dirgham" else 40 * (0.8 if look == "kid" else 1.0)) * uu)
        if talk: P["dy"] = P.get("dy", 0) - 0.5 * abs(math.sin(t * 7))
        accent = ID["fire"] if look == "young" else ID["gold"]
        hands = draw_figure(d, hip, uu, look, P, exp, talk, t, flip, accent)
        if prop != "none" and prop_at == who:
            hnd = hands.get(1) or hands.get(-1)
            if hnd: draw_prop(d, prop, hnd[0], hnd[1] - 7 * uu, uu * 0.8, t)
        # ظل أرضي
        sh = Image.new("RGBA", (tw * S, th * S), (0, 0, 0, 0)); sd = ImageDraw.Draw(sh)
        sd.ellipse([tw * S / 2 - 14 * uu, footy - 1.5 * uu, tw * S / 2 + 14 * uu, footy + 2.5 * uu], fill=(0, 0, 0, 110))
        sh.alpha_composite(layer); layer = sh
        tile = layer.resize((tw, th), Image.LANCZOS)
        x0 = int(W * cxr - tw / 2); y0 = int(floor + fh * 0.12 - th + (1 - pre) * 40)
        im.paste(tile, (x0, y0), tile)
    if prop != "none" and prop_at not in ("A", "B"):
        S = 2; pw = int(fh * 0.6)
        layer = Image.new("RGBA", (pw * S, pw * S), (0, 0, 0, 0)); d = ImageDraw.Draw(layer)
        draw_prop(d, prop, pw * S / 2, pw * S / 2, u * S * 1.5, t)
        tile = layer.resize((pw, pw), Image.LANCZOS)
        im.paste(tile, (int(W / 2 - pw / 2), int(floor - fh * 0.95 + 6 * math.sin(t * 2.4) - (1 - pre) * 30)), tile)
    ov = Image.new("RGBA", (W, H), (0, 0, 0, 0)); od = ImageDraw.Draw(ov)
    label = str(sc.get("label", "")).strip()
    if label:
        F = font(H * 0.034); s_ = shape(label); w_ = od.textlength(s_, font=F) + 56; h_ = H * 0.034 * 1.9
        x0 = (W - w_) / 2; y0 = H * 0.07 - (1 - pre) * 20
        od.rounded_rectangle([x0, y0, x0 + w_, y0 + h_], radius=int(h_ / 2), fill=ID["navy"] + (225,), outline=ID["fire"] + (255,), width=3)
        od.text((x0 + 28, y0 + h_ * 0.16), s_, font=F, fill=ID["text"])
    text = str(sc.get("text", "")).strip()
    if text:
        F = font(H * 0.040); lines = wrap(text, F, W * 0.84, od); lh = int(H * 0.040 * 1.55)
        bh = lh * len(lines) + 34; bw = max([od.textlength(shape(l), font=F) for l in lines] + [40]) + 56
        bx = (W - bw) / 2; by = H * 0.80 - bh / 2 + (1 - pre) * 20
        od.rounded_rectangle([bx, by, bx + bw, by + bh], radius=26, fill=ID["charcoal"] + (225,), outline=ID["gold"] + (255,), width=3)
        for k_, l in enumerate(lines):
            s_ = shape(l); w_ = od.textlength(s_, font=F)
            od.text(((W - w_) / 2, by + 17 + k_ * lh), s_, font=F, fill=ID["text"])
    im = im.convert("RGBA"); im.alpha_composite(ov)
    return im.convert("RGB")

# ---------------- مصمّم الفيديو من الوصف (بلا نموذج لغوي) + موسيقى مولَّدة ----------------
import zlib, wave, struct, re as _re, random as _rnd

_AR_DIG = str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789")
COLORS = [  # (كلمات، hex، اسم)
    (("اخضر", "أخضر", "خضراء", "خضرا", "green"), "#33e07a", "أخضر"),
    (("احمر", "أحمر", "حمراء", "red"), "#ff4a4a", "أحمر"),
    (("ازرق", "أزرق", "زرقاء", "blue"), "#4a8dff", "أزرق"),
    (("اصفر", "أصفر", "صفراء", "yellow"), "#ffd93a", "أصفر"),
    (("برتقالي", "برتقالية", "orange"), "#ff8c3c", "برتقالي"),
    (("بنفسجي", "بنفسجية", "purple", "violet"), "#a56bff", "بنفسجي"),
    (("وردي", "زهري", "pink"), "#ff7ab8", "وردي"),
    (("ابيض", "أبيض", "بيضاء", "white"), "#f4f4f4", "أبيض"),
    (("ذهبي", "ذهبية", "gold"), "#e8b84a", "ذهبي"),
    (("فيروزي", "سماوي", "cyan", "turquoise"), "#35d8d0", "فيروزي"),
]
MOODS = [
    (("حزين", "حزن", "كئيب", "شجي", "sad", "melanch"), "sad", "حزينة"),
    (("سعيد", "فرح", "مرح", "مبهج", "happy", "joy"), "happy", "مرحة"),
    (("حماس", "ملحمي", "اكشن", "أكشن", "epic", "action"), "epic", "حماسية"),
    (("هادئ", "هادي", "هدوء", "استرخاء", "calm", "relax"), "calm", "هادئة"),
]
ICON_WORDS = [
    (("كلب", "كلاب", "جرو", "dog", "puppy"), "dog", "كلب"),
    (("كرة", "كره", "ball"), "ball", "كرة"),
    (("قمر", "moon"), "moon", "قمر"),
    (("شمس", "sun"), "sun", "شمس"),
    (("نجمة", "نجوم", "نجمه", "star"), "star", "نجمة"),
    (("قلب", "قلوب", "heart"), "heart", "قلب"),
    (("شجرة", "شجره", "اشجار", "أشجار", "tree"), "tree", "شجرة"),
    (("غيمة", "غيوم", "سحاب", "cloud"), "cloud", "غيمة"),
]

def _has(text, words):
    return any(w in text for w in words)

def _mix(h, k, base=(8, 14, 12)):
    c = hexrgb(h); return "#%02x%02x%02x" % tuple(int(base[i] + (c[i] - base[i]) * k) for i in range(3))

def synth_music(mood, secs, path):
    """موسيقى بسيطة مولَّدة برمجيًا: وسادة وترية + باص + أرپيج، ثم صدى. wav أحادي 22 كيلوهرتز."""
    from array import array
    sr = 22050; N = int(secs * sr)
    P = {"sad": (62, [(57, "m"), (53, "M"), (60, "M"), (52, "M")], "q"),
         "happy": (112, [(60, "M"), (55, "M"), (57, "m"), (53, "M")], "e"),
         "calm": (72, [(60, "M"), (57, "m"), (53, "M"), (55, "M")], "q"),
         "epic": (126, [(57, "m"), (53, "M"), (60, "M"), (55, "M")], "e")}
    bpm, prog, grid = P.get(mood, P["calm"])
    beat = 60.0 / bpm
    mix = [0.0] * N
    def hz(m): return 440.0 * 2 ** ((m - 69) / 12.0)
    def add(m, start, dur, amp, attack, tau, harm):
        o = int(start * sr)
        if o >= N: return
        n = min(int(dur * sr), N - o); f = hz(m); w = 6.2832 * f / sr
        for i in range(n):
            tt = i / sr
            env = min(1.0, tt / attack) * math.exp(-tt / tau)
            if tt > dur - 0.15: env *= max(0.0, (dur - tt) / 0.15)
            v = math.sin(w * i)
            for k, a in harm: v += a * math.sin(w * i * k)
            mix[o + i] += v * env * amp
    bar = 4 * beat; nbar = int(secs / bar) + 1
    for b in range(nbar):
        root, q = prog[b % len(prog)]
        ints = (0, 3, 7) if q == "m" else (0, 4, 7)
        t0 = b * bar
        for iv in ints: add(root + iv, t0, bar * 1.05, 0.10, 0.35, 6.0, [(2, 0.25)])
        add(root - 12, t0, bar, 0.16, 0.05, 1.8, [(2, 0.3)])
        if mood == "epic":
            for j in range(8): add(root - 12, t0 + j * beat / 2, beat / 2, 0.10, 0.01, 0.2, [(2, 0.5)])
        tones = [root + 12 + iv for iv in ints] + [root + 24]
        pat = [2, 1, 0, 1] if mood == "sad" else [0, 1, 2, 3, 2, 1, 0, 1]
        step = beat if grid == "q" else beat / 2
        for j in range(int(bar / step)):
            add(tones[pat[j % len(pat)]], t0 + j * step, step * 1.6, 0.13 if mood != "sad" else 0.17, 0.008, 0.55, [(2, 0.2), (3, 0.08)])
    d = int(0.32 * sr); fb = 0.38
    for i in range(d, N): mix[i] += mix[i - d] * fb
    pk = max(1e-9, max(abs(v) for v in mix)); g = 0.85 / pk
    fade = int(min(2.0, secs * 0.2) * sr)
    out = array("h")
    for i, v in enumerate(mix):
        e = min(1.0, (N - i) / fade) if i > N - fade else 1.0
        e *= min(1.0, i / (0.05 * sr))
        out.append(int(max(-1, min(1, v * g * e)) * 30000))
    with wave.open(path, "wb") as wf:
        wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(sr); wf.writeframes(out.tobytes())

def _geo(rnd, kinds, cols, W, H, amul, total):
    """طبقات هندسية متحركة. الإحداثيات نسبية؛ الأشكال المربعة تُصحَّح بنسبة الشاشة."""
    ar = W / H; L = []
    def C(): return rnd.choice(cols)
    if "line" in kinds:
        for k in range(8):
            y = rnd.uniform(0.08, 0.92); rot = rnd.choice([0, 0, 0, 8, -8, 20, -20, 45, -45, 90])
            L.append({"type": "rect", "x": rnd.uniform(0.2, 0.8), "y": y, "w": rnd.uniform(0.35, 0.9), "h": 0.006, "color": C(), "rot": rot,
                      "alpha": amul * rnd.uniform(0.55, 1.0),
                      "anim": [{"p": "alpha", "t0": 0.0, "t1": 0.5 + k * 0.15, "from": 0.0, "to": amul * 0.9, "ease": "out"}],
                      "osc": [{"p": "y", "amp": rnd.uniform(0.02, 0.07), "hz": rnd.uniform(0.15, 0.5), "ph": rnd.uniform(0, 6)},
                              {"p": "x", "amp": rnd.uniform(0.02, 0.09), "hz": rnd.uniform(0.1, 0.35), "ph": rnd.uniform(0, 6)}]})
    if "circle" in kinds:
        for k in range(6):
            r = rnd.uniform(0.10, 0.30)
            L.append({"type": "ring", "x": rnd.uniform(0.1, 0.9), "y": rnd.uniform(0.15, 0.85), "w": r / ar, "h": r, "color": C(), "lw": 0.012,
                      "alpha": amul * 0.95, "anim": [{"p": "alpha", "t0": 0.0, "t1": 0.6, "from": 0.0, "to": amul * 0.95, "ease": "out"}],
                      "osc": [{"p": "scale", "amp": rnd.uniform(0.08, 0.2), "hz": rnd.uniform(0.2, 0.6), "ph": rnd.uniform(0, 6)},
                              {"p": "x", "amp": rnd.uniform(0.01, 0.05), "hz": rnd.uniform(0.1, 0.3), "ph": rnd.uniform(0, 6)}]})
        for k in range(4):
            r = rnd.uniform(0.05, 0.16)
            L.append({"type": "ellipse", "x": rnd.uniform(0.05, 0.95), "y": rnd.uniform(0.1, 0.9), "w": r / ar, "h": r, "color": C(),
                      "alpha": amul * 0.35, "osc": [{"p": "y", "amp": rnd.uniform(0.03, 0.08), "hz": rnd.uniform(0.2, 0.5), "ph": rnd.uniform(0, 6)}]})
    if "square" in kinds:
        for k in range(5):
            r = rnd.uniform(0.08, 0.22)
            L.append({"type": "rect", "x": rnd.uniform(0.1, 0.9), "y": rnd.uniform(0.15, 0.85), "w": r / ar, "h": r, "color": C(),
                      "alpha": amul * rnd.uniform(0.3, 0.6), "spin": rnd.choice([-1, 1]) * rnd.uniform(15, 50),
                      "osc": [{"p": "x", "amp": 0.03, "hz": rnd.uniform(0.1, 0.3), "ph": rnd.uniform(0, 6)}]})
    if "tri" in kinds:
        for k in range(4):
            r = rnd.uniform(0.1, 0.24)
            L.append({"type": "tri", "x": rnd.uniform(0.1, 0.9), "y": rnd.uniform(0.15, 0.85), "w": r / ar, "h": r, "color": C(), "lw": 0.012,
                      "alpha": amul * 0.9, "spin": rnd.choice([-1, 1]) * rnd.uniform(20, 60)})
    return L

def plan_brief(text):
    t = text.translate(_AR_DIG).lower()
    m = _re.search(r"(\d+(?:\.\d+)?)\s*(ثانية|ثانيه|ثواني|ثوان|ث\b|sec|second|s\b|دقيقة|دقيقه|دقائق|min)", t)
    dur = 10.0
    if m:
        dur = float(m.group(1)) * (60 if m.group(2).startswith(("دقيق", "دقائ", "min")) else 1)
    dur = max(4.0, min(60.0, dur))
    cols = []; cnames = []
    for words, hx, nm in COLORS:
        if _has(t, words): cols.append(hx); cnames.append(nm)
    kinds = []
    if _has(t, ("خطوط", "خط ", "خطين", "line")): kinds.append("line")
    if _has(t, ("دواير", "دوائر", "دائرة", "دايرة", "دايره", "دائره", "حلقة", "حلقات", "circle", "ring")): kinds.append("circle")
    if _has(t, ("مربع", "مربعات", "square")): kinds.append("square")
    if _has(t, ("مثلث", "مثلثات", "triang")): kinds.append("tri")
    if not kinds and ("هندس" in t or "geometr" in t or "اشكال" in t or "أشكال" in t):
        for k in ("line", "circle", "square", "tri"):
            if k not in kinds: kinds.append(k)
    icons = []
    for words, nm, ar in ICON_WORDS:
        if _has(t, words): icons.append((nm, ar))
    theme = None
    if _has(t, ("غابة", "غابه", "غابات", "forest", "jungle", "أدغال", "ادغال")): theme = "forest"
    elif _has(t, ("صحراء", "صحرا", "desert")): theme = "desert"
    elif _has(t, ("بحر", "شاطئ", "sea", "ocean", "beach")): theme = "sea"
    elif _has(t, ("ليل", "night", "نجوم")): theme = "night"
    for words, nm, ar in (((("أسد", "اسد", "أسود", "lion"), "lion", "أسد"), (("نمر", "نمور", "tiger"), "tiger", "نمر"))):
        if _has(t, words): icons.append((nm, ar))
    talk = _has(t, ("يتحدث", "يتكلم", "يشرح", "يحكي", "يقول", "يروي", "تعليق", "talking", "narrat", "explain"))
    mood = None; mname = ""
    for words, mk, ar in MOODS:
        if _has(t, words): mood, mname = mk, ar; break
    wants_music = _has(t, ("موسيق", "لحن", "music", "أغني", "اغني", "مزيكا"))
    title = None
    mt = _re.search(r"[«\"“]([^»\"”]{2,60})[»\"”]", text) or _re.search(r"بعنوان\s+(\S+(?:\s+\S+){0,4})", text)
    if mt: title = mt.group(1).strip()
    if not (kinds or icons or wants_music or cols or theme):
        return None
    if not kinds and not icons and not theme: kinds = ["line", "circle"]
    if not cols: cols = ["#ff8c3c", "#35d8d0", "#ffd93a", "#a56bff"]
    vertical = _has(t, ("عمودي", "ريلز", "تيك توك", "reels", "tiktok", "vertical", "شورتس", "shorts"))
    W, H = (720, 1280) if vertical else (960, 540)
    seed = zlib.crc32(text.encode("utf-8"))
    nsc = max(1, int(math.ceil(dur / 12.0))); each = dur / nsc
    bg = _mix(cols[0], 0.14)
    tbg = {"forest": ("#2f8f4e", "#1f5f35", "#174d2a"), "desert": ("#f3c66f", "#d9a441", "#b9852c"),
           "sea": ("#4aa8e8", "#1b6fb5", "#bfe6ff"), "night": ("#0b1030", "#162040", "#2a3b66")}
    sunny = any(n == "sun" for n, _ in icons) or _has(t, ("مشمس", "نهار", "ملعب", "حديقة", "sunny"))
    gcol, gline = _mix(cols[0], 0.35, (6, 10, 8)), cols[0]
    if sunny and not cnames:
        bg, gcol, gline = "#7fcdff", "#3f9d4b", "#2f7d3a"
    if theme:
        bg, gcol, gline = tbg[theme]
    scenes = []
    for si in range(nsc):
        rnd = _rnd.Random(seed + si * 101)
        layers = _geo(rnd, kinds, cols, W, H, 0.5 if icons else 1.0, each)
        has_dog = any(n == "dog" for n, _ in icons)
        if icons or theme:
            layers.append({"type": "rect", "x": 0.5, "y": 0.86, "w": 1.0, "h": 0.28, "color": gcol, "alpha": 1.0})
            layers.append({"type": "rect", "x": 0.5, "y": 0.725, "w": 1.0, "h": 0.006, "color": gline, "alpha": 0.9})
        slot = 0
        if theme == "forest":
            for k, tx in enumerate((0.42, 0.55, 0.72, 0.9) if talk else (0.06, 0.2, 0.36, 0.55, 0.72, 0.9)):
                layers.append({"type": "icon", "name": "tree", "x": tx, "y": 0.56 + 0.03 * (k % 2), "w": 0.34 * H / W, "h": 0.34, "alpha": 0.95,
                               "osc": [{"p": "x", "amp": 0.004, "hz": 0.3, "ph": k}]})
        if theme == "night":
            layers.append({"type": "icon", "name": "moon", "x": 0.85, "y": 0.2, "w": 0.2 * H / W, "h": 0.2})
            for k in range(8):
                layers.append({"type": "icon", "name": "star", "x": rnd.uniform(0.05, 0.95), "y": rnd.uniform(0.05, 0.5), "w": 0.05 * H / W, "h": 0.05,
                               "osc": [{"p": "alpha", "amp": 0.4, "hz": rnd.uniform(0.3, 1.0), "ph": k}]})
        if theme == "desert" and not any(n == "sun" for n, _ in icons):
            layers.append({"type": "icon", "name": "sun", "x": 0.15, "y": 0.2, "w": 0.2 * H / W, "h": 0.2, "spin": 10})
        aslot = 0
        for nm, ar in icons:
            if nm in ("lion", "tiger"):
                ax = (0.66 if talk else 0.3) + 0.2 * aslot; aslot += 1
                layers.append({"type": "icon", "name": nm, "x": min(0.88, ax), "y": 0.6, "w": 0.3 * H / W, "h": 0.3, "bob": 0.012,
                               "osc": [{"p": "x", "amp": 0.02, "hz": 0.25, "ph": aslot}]})
                continue
            if nm == "dog":
                layers.append({"type": "icon", "name": "dog", "x": 0.5, "y": 0.60, "w": 0.34 * H / W, "h": 0.34, "face": True, "bob": 0.02,
                               "osc": [{"p": "x", "amp": 0.28, "hz": 0.22, "ph": si}], "anim": [{"p": "alpha", "t0": 0, "t1": 0.5, "from": 0, "to": 1}]})
            elif nm == "ball":
                layers.append({"type": "icon", "name": "ball", "x": 0.5, "y": 0.64, "w": 0.1 * H / W, "h": 0.1, "bob": 0.16, "spin": 220,
                               "osc": [{"p": "x", "amp": 0.34 if has_dog else 0.25, "hz": 0.22, "ph": si + 0.45}]})
            else:
                px = [0.15, 0.85, 0.5, 0.3, 0.7][slot % 5]; py = [0.2, 0.22, 0.12, 0.35, 0.3][slot % 5]; slot += 1
                big = 0.18 if nm in ("moon", "sun") else 0.13
                layers.append({"type": "icon", "name": nm, "x": px, "y": py, "w": big * H / W, "h": big,
                               "osc": [{"p": "y", "amp": 0.02, "hz": 0.3, "ph": slot}], "spin": 12 if nm in ("star", "sun") else 0})
        if title:
            layers.append({"type": "text", "text": title, "x": 0.5, "y": 0.14, "size": 0.085, "w": 0.9, "color": "#ffffff",
                           "anim": [{"p": "alpha", "t0": 0.2, "t1": 1.0, "from": 0, "to": 1}]})
        scenes.append({"speaker": "narrator", "text": "", "sec": each, "bg": bg, "plain": True, "layers": layers})
    spec = {"scenes": scenes, "w": W, "h": H, "fps": 24}
    parts = ["المدة %d ثانية" % round(dur)]
    if kinds: parts.append("أشكال: " + "، ".join({"line": "خطوط", "circle": "دوائر", "square": "مربعات", "tri": "مثلثات"}[k] for k in kinds))
    if cnames: parts.append("الألوان: " + "، ".join(cnames))
    if icons: parts.append("عناصر: " + "، ".join(a for _, a in icons))
    if wants_music or mood:
        mood = mood or "calm"; parts.append("موسيقى " + (mname or "هادئة"))
        pth = os.path.join(HOME + "out/", "music_%s.wav" % mood); os.makedirs(HOME + "out/", exist_ok=True)
        synth_music(mood, dur, pth); spec["audio"] = pth
    if theme: parts.append("المكان: " + {"forest": "غابة", "desert": "صحراء", "sea": "بحر", "night": "ليل"}[theme])
    if talk: spec["talk"] = True
    spec["summary"] = " • ".join(parts)
    return spec

# ---------------- الأوامر ----------------
def cmd_video(spec, out):
    if spec.get("font"): set_font(spec["font"])
    if spec.get("format") == "vertical": spec.setdefault("w", 720); spec.setdefault("h", 1280)
    if spec.get("style") == "stick": spec.setdefault("w", 720); spec.setdefault("h", 1280); spec.setdefault("fps", 20)
    W = int(spec.get("w", 960)); H = int(spec.get("h", 540)); FPS = int(spec.get("fps", 24))
    scenes = [x for x in (spec.get("scenes") or []) if isinstance(x, dict)]
    spec["scenes"] = scenes
    if not scenes: sys.exit("no scenes")
    for x in scenes:   # تنقية مواصفات النموذج اللغوي: أنواع خاطئة/قيم فارغة
        m = _re.search(r"\d+(?:\.\d+)?", str(x.get("sec", 4)).translate(_AR_DIG))
        x["sec"] = min(30.0, float(m.group(0))) if m else 4.0
        x["text"] = "" if x.get("text") is None else str(x.get("text"))
        x["speaker"] = str(x.get("speaker") or "narrator")
        x["layers"] = [l for l in (x.get("layers") or []) if isinstance(l, dict)]
    if not isinstance(spec.get("names"), dict): spec["names"] = {}
    spec["title"] = "" if spec.get("title") is None else str(spec["title"])
    dur = [max(1.5, float(s.get("sec", 4))) for s in scenes]
    audio = find_media(spec.get("audio")) if spec.get("audio") else None
    if audio:
        try:
            d = float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                                               "-of", "csv=p=0", audio]).decode().strip())
            tot = sum(dur)
            if d > tot: dur = [x * d / tot for x in dur]
        except Exception:
            audio = None
    cmd = ["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-"]
    if audio: cmd += ["-i", audio]
    cmd += ["-c:v", "libx264", "-preset", "veryfast", "-pix_fmt", "yuv420p", "-movflags", "+faststart"]
    if audio: cmd += ["-c:a", "aac", "-shortest"]
    cmd += [out]
    pipe = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    prev = [None]
    def emit(img):
        prev[0] = img; pipe.stdin.write(img.tobytes())
    title = spec.get("title", "")
    if title and spec.get("style") != "stick":
        bg = gradient((20, 24, 44), (60, 30, 20), W, H)
        for i in range(int(FPS * 2)):
            a = min(1.0, i / (FPS * 0.8)); im = bg.copy(); d = ImageDraw.Draw(im)
            s = shape(title); f = font(H * 0.09); w = d.textlength(s, font=f)
            d.text(((W - w) / 2, H * 0.4 + (1 - a) * 30), s, font=f, fill=tuple(int(255 * a) for _ in range(3)))
            emit(im)
    black = Image.new("RGB", (W, H), (0, 0, 0))
    for si, (sc, secs) in enumerate(zip(scenes, dur)):
        photo = None
        if sc.get("image"):
            p = load_img(sc["image"], None, key=("raw", sc["image"]))
            if p is not None: photo = p.convert("RGB")
        n = int(secs * FPS)
        for i in range(n):
            t = i / FPS
            im = render_frame(spec, sc, t, secs, W, H, photo, black, si)
            if prev[0] is not None and i < FPS * 0.4:
                im = Image.blend(prev[0], im, (i + 1) / (FPS * 0.4))
            emit(im)
    pipe.stdin.close(); pipe.wait()
    if pipe.returncode != 0 or not os.path.exists(out):
        sys.exit("ffmpeg failed")
    print("OK", out, os.path.getsize(out))

def cmd_image(spec, out):
    if spec.get("font"): set_font(spec["font"])
    W = int(spec.get("w", 1024)); H = int(spec.get("h", 576))
    sc = (spec.get("scenes") or [spec])[0]
    photo = None
    if sc.get("image"):
        p = load_img(sc["image"], None, key=("raw", sc["image"]))
        if p is not None: photo = p.convert("RGB")
    secs = float(sc.get("sec", 3))
    im = render_frame(spec, sc, secs, secs, W, H, photo, Image.new("RGB", (W, H), (0, 0, 0)))
    im.save(out)
    print("OK", out, os.path.getsize(out))

def cmd_edit(spec):
    f = find_media(spec.get("src"))
    if not f: sys.exit("source not found: %s" % spec.get("src"))
    im = Image.open(f).convert("RGBA")
    im = apply_ops(im, spec.get("ops"))
    out = os.path.expanduser(spec.get("out") or "edited.png")
    if not os.path.isabs(out) and not out.startswith("~"): out = os.path.join(HOME, out)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    if out.lower().endswith((".jpg", ".jpeg")): im = im.convert("RGB")
    im.save(out)
    print("OK", out, "%dx%d" % im.size)

def cmd_pieces(spec):
    """يفصل شيت شخصية/عناصر إلى قطع مستقلة (مكوّنات متصلة) ويحفظ كل قطعة PNG شفاف."""
    f = find_media(spec.get("src"))
    if not f: sys.exit("source not found: %s" % spec.get("src"))
    im = cutout(Image.open(f).convert("RGBA"))
    W, H = im.size
    sc = min(1.0, 500.0 / max(W, H))
    m = im.getchannel("A").resize((max(1, int(W * sc)), max(1, int(H * sc)))).point(lambda v: 255 if v > 40 else 0)
    gap = int(spec.get("gap", 3))
    md = m.filter(ImageFilter.MaxFilter(2 * gap + 1)) if gap > 0 else m
    w, h = md.size; px = md.load(); seen = bytearray(w * h); boxes = []
    for y0 in range(h):
        for x0 in range(w):
            if px[x0, y0] and not seen[y0 * w + x0]:
                st = [(x0, y0)]; seen[y0 * w + x0] = 1; x1 = x2 = x0; y1 = y2 = y0; n = 0
                while st:
                    x, y = st.pop(); n += 1
                    x1 = min(x1, x); x2 = max(x2, x); y1 = min(y1, y); y2 = max(y2, y)
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        a, b = x + dx, y + dy
                        if 0 <= a < w and 0 <= b < h and px[a, b] and not seen[b * w + a]:
                            seen[b * w + a] = 1; st.append((a, b))
                boxes.append((n, x1, y1, x2, y2))
    minA = float(spec.get("min_area", 0.002)) * w * h
    boxes = sorted([b for b in boxes if b[0] >= minA], key=lambda b: (b[2] // max(1, h // 6), b[1]))[:int(spec.get("max", 24))]
    pre = spec.get("out") or "out/piece"
    if not os.path.isabs(pre) and not pre.startswith("~"): pre = os.path.join(HOME, pre)
    os.makedirs(os.path.dirname(pre), exist_ok=True)
    rows = []
    for k, (n, x1, y1, x2, y2) in enumerate(boxes, 1):
        box = (int(x1 / sc), int(y1 / sc), int((x2 + 1) / sc), int((y2 + 1) / sc))
        p = "%s_%d.png" % (pre, k); autocrop(im.crop(box)).save(p)
        rows.append("%s  %dx%d  at(x,y,w,h fractions)=%.2f,%.2f,%.2f,%.2f" % (os.path.relpath(p, HOME), box[2] - box[0], box[3] - box[1], box[0] / W, box[1] / H, (box[2] - box[0]) / W, (box[3] - box[1]) / H))
    print("OK %d pieces" % len(rows)); print("\n".join(rows))

def cmd_info(path):
    f = find_media(path)
    if not f: sys.exit("not found: %s" % path)
    im = Image.open(f)
    w, h = im.size
    rgba = im.convert("RGBA")
    has_alpha = rgba.getchannel("A").getextrema()[0] < 250
    small = rgba.convert("RGB"); small.thumbnail((160, 160))
    q = small.quantize(5).convert("RGB")
    cols = sorted(q.getcolors(), reverse=True)
    dom = ", ".join("#%02x%02x%02x(%d%%)" % (c[0], c[1][0], c[1][1], c[1][2]) if False else "#%02x%02x%02x(%d%%)" % (c[1][0], c[1][1], c[1][2], 100 * c[0] // (q.width * q.height)) for c in cols)
    lum = sum(ImageOps.grayscale(small).getdata()) / (small.width * small.height)
    sub = autocrop(cutout(rgba))
    bb = rgba.getchannel("A").point(lambda v: 255 if v > 12 else 0).getbbox()
    cut = cutout(rgba); cb = cut.getchannel("A").point(lambda v: 255 if v > 12 else 0).getbbox()
    lines = ["size %dx%d, mode %s, transparent background: %s" % (w, h, im.mode, "yes" if has_alpha else "no"),
             "dominant colors: " + dom, "brightness: %.0f/255" % lum]
    if cb:
        lines.append("subject box (fractions x,y,w,h): %.2f,%.2f,%.2f,%.2f" % (cb[0] / w, cb[1] / h, (cb[2] - cb[0]) / w, (cb[3] - cb[1]) / h))
    if shutil.which("tesseract"):
        try:
            t = subprocess.check_output(["tesseract", f, "stdout", "-l", "ara+eng"], stderr=subprocess.DEVNULL, timeout=60).decode().strip()
            lines.append("text found (OCR): " + (t[:600] if t else "none"))
        except Exception:
            lines.append("OCR failed")
    else:
        lines.append("OCR unavailable (install: pkg install tesseract)")
    print("\n".join(lines))

if __name__ == "__main__":
    a = sys.argv
    if len(a) < 3: sys.exit("usage: dg_media.py video|image|edit|info ...")
    if a[1] == "info":
        cmd_info(a[2])
    elif a[1] == "plan":
        b = json.load(open(a[2], encoding="utf-8")).get("brief", "")
        p = plan_brief(b)
        print("PLAN " + json.dumps(p, ensure_ascii=True) if p else "NOPLAN")
    else:
        spec = json.load(open(a[2], encoding="utf-8"))
        if a[1] == "video": cmd_video(spec, a[3])
        elif a[1] == "image": cmd_image(spec, a[3])
        elif a[1] == "edit": cmd_edit(spec)
        elif a[1] == "pieces": cmd_pieces(spec)
        else: sys.exit("unknown command")
