package com.dirgham.code

import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * جسر محلي بديل عن إذن RUN_COMMAND: خادم HTTP صغير على 127.0.0.1 داخل التطبيق.
 * سكربت صغير يعمل داخل Termux يسحب الأوامر (poll) وينفّذها ثم يرسل النتيجة.
 * لا يحتاج أي إذن أندرويد. الرمز السري جزء من المسار، والاستماع على الحلقة المحلية فقط.
 */
object LocalBridge {
    class Job(val id: String, val cmd: String) {
        val done = CountDownLatch(1)
        @Volatile var out: String = ""
        @Volatile var code: Int = -1
    }

    @Volatile private var server: ServerSocket? = null
    @Volatile var port: Int = 0
        private set
    @Volatile var token: String = ""
        private set
    @Volatile private var lastPoll = 0L
    /** مجلدا التبادل: inbox (ملفات المستخدم إلى Termux) و outbox (نتائج Termux إلى المستخدم). */
    @Volatile var inDir: java.io.File? = null
    @Volatile var outDir: java.io.File? = null
    fun setDirs(root: java.io.File) {
        inDir = java.io.File(root, "inputs").also { it.mkdirs() }
        outDir = java.io.File(root, "outbox").also { it.mkdirs() }
    }
    fun cleanName(n: String): String = n.replace(Regex("[^A-Za-z0-9._\\u0600-\\u06FF -]"), "_").trim().take(120).ifEmpty { "file" }
    fun url(route: String): String = "http://127.0.0.1:$port/$token/$route"
    private val pending = LinkedBlockingQueue<Job>()
    private val jobs = ConcurrentHashMap<String, Job>()
    private val ids = AtomicInteger(0)

    fun connected(): Boolean = System.currentTimeMillis() - lastPoll < 90_000

    /** ينتظر حتى ظهور نبضة من Termux (قد يتأخر عند خمول الجهاز). */
    suspend fun awaitConnected(ms: Long): Boolean {
        val end = System.currentTimeMillis() + ms
        while (System.currentTimeMillis() < end) {
            if (connected()) return true
            kotlinx.coroutines.delay(500)
        }
        return connected()
    }

    fun installCommand(): String = "curl -fsS http://127.0.0.1:$port/$token/bridge.sh | bash"

    @Synchronized
    fun start(preferredPort: Int, tok: String): Boolean {
        if (server != null && !server!!.isClosed) return true
        token = tok
        val s = try {
            ServerSocket(preferredPort, 16, InetAddress.getByName("127.0.0.1"))
        } catch (_: Exception) {
            try { ServerSocket(0, 16, InetAddress.getByName("127.0.0.1")) } catch (_: Exception) { return false }
        }
        server = s
        port = s.localPort
        Thread({
            while (!s.isClosed) {
                val c = try { s.accept() } catch (_: Exception) { break }
                Thread({ handle(c) }, "dg-bridge-conn").apply { isDaemon = true }.start()
            }
        }, "dg-bridge").apply { isDaemon = true }.start()
        return true
    }

    @Synchronized
    fun stop() {
        try { server?.close() } catch (_: Exception) {}
        server = null
    }

    /** ينفّذ أمرًا عبر Termux. يعيد (رمز الخروج، الإخراج) أو null عند انتهاء المهلة. */
    fun run(cmd: String, timeoutSec: Int): Pair<Int, String>? {
        val j = Job("j" + ids.incrementAndGet(), cmd)
        jobs[j.id] = j
        pending.add(j)
        val ok = j.done.await(timeoutSec.toLong(), TimeUnit.SECONDS)
        jobs.remove(j.id)
        pending.remove(j)
        return if (ok) Pair(j.code, j.out) else null
    }

    private fun script(): String {
        val s = """#!/data/data/com.termux/files/usr/bin/bash
mkdir -p ~/.dirgham ~/dirgham
[ -f ~/.dirgham/pid ] && kill "§(cat ~/.dirgham/pid)" 2>/dev/null
cat > ~/.dirgham/loop.sh <<'LOOP'
#!/data/data/com.termux/files/usr/bin/bash
B="http://127.0.0.1:@PORT@/@TOKEN@"
echo §§ > ~/.dirgham/pid
command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock
while true; do
  R=§(curl -s -m 40 -w '\n%{http_code}' "§B/poll") || { sleep 2; continue; }
  CODE="§{R##*§'\n'}"
  BODY="§{R%§'\n'*}"
  [ "§CODE" = "200" ] || { sleep 1; continue; }
  ID="§{BODY%%§'\n'*}"
  CMD="§{BODY#*§'\n'}"
  OUT=§(cd ~/dirgham 2>/dev/null || cd ~; timeout 600 bash -c "§CMD" 2>&1)
  RC=§?
  printf '%s' "§OUT" | curl -s -m 60 -X POST --data-binary @- "§B/result/§ID?code=§RC" >/dev/null
done
LOOP
chmod +x ~/.dirgham/loop.sh
nohup bash ~/.dirgham/loop.sh > ~/.dirgham/log 2>&1 &
echo "تم تشغيل جسر ضرغام كود. ارجع للتطبيق."
"""
        return s.replace('§', '$').replace("@PORT@", port.toString()).replace("@TOKEN@", token)
    }

    private fun readLine(i: BufferedInputStream): String? {
        val b = ByteArrayOutputStream()
        while (true) {
            val x = i.read()
            if (x < 0) return if (b.size() == 0) null else b.toString("UTF-8")
            if (x == '\n'.code) return b.toString("UTF-8").trimEnd('\r')
            b.write(x)
        }
    }

    private fun reply(c: Socket, status: String, body: ByteArray = ByteArray(0)) {
        val h = "HTTP/1.1 $status\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: ${body.size}\r\nConnection: close\r\n\r\n"
        c.getOutputStream().apply { write(h.toByteArray()); write(body); flush() }
    }

    private fun handle(c: Socket) {
        try {
            c.soTimeout = 60_000
            val i = BufferedInputStream(c.getInputStream())
            val req = readLine(i) ?: return
            val parts = req.split(" ")
            if (parts.size < 2) return
            val method = parts[0]
            val full = parts[1]
            var len = 0
            while (true) {
                val h = readLine(i) ?: break
                if (h.isEmpty()) break
                if (h.startsWith("Content-Length:", ignoreCase = true)) len = h.substring(15).trim().toIntOrNull() ?: 0
            }
            val path = full.substringBefore('?')
            val query = if (full.contains('?')) full.substringAfter('?') else ""
            val prefix = "/$token/"
            if (!path.startsWith(prefix)) { reply(c, "404 Not Found"); return }
            val route = path.substring(prefix.length)

            // رفع ملف من Termux (يُكتب مباشرة على القرص بلا تحميله في الذاكرة)
            if (method == "PUT" && route.startsWith("upload/")) {
                val dir = outDir
                if (dir == null) { reply(c, "503 Service Unavailable"); return }
                val name = cleanName(java.net.URLDecoder.decode(route.removePrefix("upload/"), "UTF-8"))
                val f = java.io.File(dir, name)
                c.soTimeout = 300_000
                f.outputStream().use { o ->
                    var left = len.toLong()
                    val buf = ByteArray(64 * 1024)
                    while (left > 0) {
                        val n = i.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                        if (n < 0) break
                        o.write(buf, 0, n); left -= n
                    }
                }
                reply(c, "200 OK")
                return
            }
            // تنزيل ملف مرفق إلى Termux
            if (method == "GET" && route.startsWith("file/")) {
                val dir = inDir
                val name = cleanName(java.net.URLDecoder.decode(route.removePrefix("file/"), "UTF-8"))
                val f = if (dir == null) null else java.io.File(dir, name)
                if (f == null || !f.isFile) { reply(c, "404 Not Found"); return }
                val h = "HTTP/1.1 200 OK\r\nContent-Type: application/octet-stream\r\nContent-Length: ${f.length()}\r\nConnection: close\r\n\r\n"
                val os = c.getOutputStream()
                os.write(h.toByteArray())
                f.inputStream().use { it.copyTo(os, 64 * 1024) }
                os.flush()
                return
            }
            val body = if (len > 0) ByteArray(len).also { var o = 0; while (o < len) { val n = i.read(it, o, len - o); if (n < 0) break; o += n } } else ByteArray(0)

            when {
                method == "GET" && route == "bridge.sh" -> reply(c, "200 OK", script().toByteArray())
                method == "GET" && route == "poll" -> {
                    lastPoll = System.currentTimeMillis()
                    val j = pending.poll(25, TimeUnit.SECONDS)
                    lastPoll = System.currentTimeMillis()
                    if (j == null) reply(c, "204 No Content")
                    else reply(c, "200 OK", (j.id + "\n" + j.cmd).toByteArray())
                }
                method == "POST" && route.startsWith("result/") -> {
                    val id = route.removePrefix("result/")
                    val code = query.split("&").firstOrNull { it.startsWith("code=") }?.substring(5)?.toIntOrNull() ?: -1
                    val j = jobs[id]
                    if (j != null) { j.out = String(body, Charsets.UTF_8); j.code = code; j.done.countDown() }
                    reply(c, "200 OK")
                }
                else -> reply(c, "404 Not Found")
            }
        } catch (_: Exception) {
        } finally {
            try { c.close() } catch (_: Exception) {}
        }
    }
}
