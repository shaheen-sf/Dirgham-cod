package com.dirgham.code

import android.content.Context
import androidx.annotation.Keep
import java.io.File

@Keep
fun interface TokenCallback {
    fun onToken(piece: String): Boolean // false = إيقاف التوليد
}

/**
 * غلاف llama.cpp يعمل مع أي نموذج GGUF ويستخدم قالب المحادثة المضمّن في النموذج.
 * نموذج واحد فقط في الذاكرة في كل مرة. الملفات في التخزين الداخلي للتطبيق (أسرع وأسلم من mmap على التخزين المشترك).
 */
@Keep
class LlamaEngine private constructor(private val ctx: Context) {

    companion object {
        val nativeOk: Boolean = try {
            System.loadLibrary("llama_jni"); true
        } catch (_: UnsatisfiedLinkError) { false }

        @Volatile
        private var inst: LlamaEngine? = null

        fun shared(c: Context): LlamaEngine =
            inst ?: synchronized(this) { inst ?: LlamaEngine(c.applicationContext).also { inst = it } }

        fun modelsDir(c: Context): File = File(c.filesDir, "models").also { it.mkdirs() }

        fun listModels(c: Context): List<File> =
            (modelsDir(c).listFiles() ?: emptyArray())
                .filter { it.isFile && it.name.endsWith(".gguf", ignoreCase = true) }
                .sortedBy { it.name.lowercase() }

        fun activeModel(c: Context): File? {
            val want = Settings.activeModel(c)
            val all = listModels(c)
            return all.firstOrNull { it.name == want } ?: all.firstOrNull()
        }

        /** نسخ ما نُزِّل بالإصدار السابق من المجلد الخارجي إلى الداخلي مرة واحدة. */
        fun migrateOld(c: Context) {
            val old = File(c.getExternalFilesDir(null), "models")
            if (!old.isDirectory) return
            val dst = modelsDir(c)
            old.listFiles()?.forEach { f ->
                if (f.isFile && f.name.endsWith(".gguf", ignoreCase = true)) {
                    val t = File(dst, f.name)
                    if (!t.exists()) {
                        try { f.copyTo(t); f.delete() } catch (_: Exception) { t.delete() }
                    }
                }
            }
        }

        fun isGguf(f: File): Boolean = try {
            f.inputStream().use { s ->
                val b = ByteArray(4)
                s.read(b) == 4 && String(b, Charsets.ISO_8859_1) == "GGUF"
            }
        } catch (_: Exception) { false }
    }

    private var loadedPath: String? = null
    private var handle: Long = 0L

    private external fun nativeLoad(path: String, nCtx: Int, nThreads: Int): Long
    private external fun nativeTemplate(h: Long, roles: Array<String>, contents: Array<String>, addAss: Boolean): String?
    private external fun nativeInfo(h: Long): String
    private external fun nativeGenerate(h: Long, prompt: String, maxTokens: Int, temp: Float, cb: TokenCallback): Int
    private external fun nativeFree(h: Long)
    private external fun nativeAbort()
    private external fun nativeComputeCheck(threads: Int): String
    private external fun nativeProbe(h: Long, text: String): String
    private external fun nativeSetProfile(h: Long, threads: Int, kvF32: Boolean, nBatch: Int)

    /** ملف تشغيل: خيوط، دقة المخبأ، حجم الدفعة. */
    data class Profile(val name: String, val threads: Int, val kvF32: Boolean, val nBatch: Int)

    private fun profiles(): List<Profile> {
        val cores = Runtime.getRuntime().availableProcessors()
        val t = bigCores()
        return listOf(
            Profile("افتراضي ($t خيوط)", t, false, 512),
            Profile("خيط واحد", 1, false, 512),
            Profile("مخبأ كامل الدقة", t, true, 512),
            Profile("دفعات صغيرة", t, false, 8),
            Profile("خيط واحد + مخبأ كامل + دفعات صغيرة", 1, true, 8),
        )
    }

    private fun parseProfile(s: String): Profile? {
        val a = s.split("|")
        if (a.size != 4) return null
        return Profile(a[0], minOf(a[1].toIntOrNull() ?: return null, 4), a[2] == "1", a[3].toIntOrNull() ?: return null)
    }

    private fun encode(p: Profile) = "${p.name}|${p.threads}|${if (p.kvF32) 1 else 0}|${p.nBatch}"

    private fun applyProfile(p: Profile) { nativeSetProfile(handle, p.threads, p.kvF32, p.nBatch) }

    /** تقرير تشخيص كامل: بصمة الملف، الحساب الرياضي، الرموز، واحتمالات الرمز التالي. */
    @Synchronized
    fun deepDiag(file: File): String {
        val sb = StringBuilder()
        try {
            val md = java.security.MessageDigest.getInstance("SHA-256")
            file.inputStream().use { s ->
                val b = ByteArray(1 shl 20)
                while (true) { val n = s.read(b); if (n < 0) break; md.update(b, 0, n) }
            }
            sb.append("حجم الملف: ").append(file.length()).append(" بايت\nSHA-256: ")
                .append(md.digest().joinToString("") { "%02x".format(it) }).append("\n")
        } catch (e: Throwable) { sb.append("تعذّر حساب البصمة: ").append(e.message).append('\n') }
        sb.append("\nاختبار الحساب (بلا نموذج):\n").append(nativeComputeCheck(4)).append("\n")
        if (handle != 0L) {
            sb.append("\nفحص الرموز لجملة The capital of France is:\n")
            sb.append(nativeProbe(handle, "The capital of France is")).append('\n')
        }
        return sb.toString()
    }

    /** يولّد جملة قصيرة بلا عشوائية ويتحقق أن الناتج سليم (يحتوي Paris). */
    private fun probe(): String {
        val sb = StringBuilder()
        try {
            nativeGenerate(handle, "The capital of France is", 10, 0f, TokenCallback { sb.append(it); true })
        } catch (e: Throwable) { sb.append("[خطأ: ${e.message}]") }
        return sb.toString()
    }

    /**
     * الفحص الذاتي: يجرّب ملفات التشغيل بالترتيب ويختار أول ما يعطي ناتجًا سليمًا.
     * يعيد تقريرًا نصيًا. force=true يتجاهل النتيجة المحفوظة.
     */
    @Synchronized
    fun selfTest(ctx: android.content.Context, force: Boolean): String {
        if (handle == 0L) return "لا يوجد نموذج محمّل"
        val saved = if (force) null else parseProfile(Settings.profile(ctx))
        if (saved != null) { applyProfile(saved); return "" }
        val sb = StringBuilder("فحص ذاتي للنموذج:\n")
        var chosen: Profile? = null
        for (p in profiles()) {
            applyProfile(p)
            val out = probe()
            val ok = out.contains("Paris", ignoreCase = true)
            sb.append(if (ok) "✔ " else "✘ ").append(p.name).append(" ← ").append(out.trim().replace("\n", " ").take(60)).append('\n')
            if (ok) { chosen = p; break }
        }
        if (chosen != null) {
            Settings.setProfile(ctx, encode(chosen))
            sb.append("اختير: ").append(chosen.name).append('\n')
        } else {
            applyProfile(profiles()[0])
            sb.append("لم ينجح أي ملف تشغيل: الخلل في بناء المكتبة الأصلية أو النموذج نفسه.\n\n")
            loadedPath?.let { sb.append(deepDiag(File(it))) }
        }
        return sb.toString()
    }

    /** 4 خيوط تناسب الأنوية الكبيرة في المعالجات الحديثة؛ الأنوية الصغيرة تُبطئ الحساب المتوازي. */
    private fun bigCores(): Int = (Runtime.getRuntime().availableProcessors() / 2).coerceIn(2, 4)

    private fun cpuHasDotprod(): Boolean = try {
        java.io.File("/proc/cpuinfo").readText().contains("asimddp")
    } catch (_: Exception) { true }

    @Synchronized
    fun ensureLoaded(file: File, nCtx: Int = 4096) {
        check(cpuHasDotprod()) { "المعالج لا يدعم dotprod الذي بُني عليه التطبيق (يلزم Snapdragon 888 / Exynos 2100 أو أحدث)." }
        check(nativeOk) { "المكتبة الأصلية llama_jni غير موجودة في هذا الـ APK" }
        require(file.exists()) { "النموذج غير موجود: ${file.name}" }
        require(isGguf(file)) { "الملف ليس GGUF صالحًا (ربما تنزيل ناقص): ${file.name}" }
        if (loadedPath == file.absolutePath && handle != 0L) return
        unload()
        val threads = bigCores()
        handle = nativeLoad(file.absolutePath, nCtx, threads)
        check(handle != 0L) { "فشل تحميل النموذج (الذاكرة غير كافية أو بنية غير مدعومة)" }
        loadedPath = file.absolutePath
        // الفحص الذاتي مرة واحدة (يُحفظ الناتج)؛ يستدعيه الوكيل بعد التحميل
    }

    /** يطبّق قالب المحادثة المضمّن في النموذج. null إن لم يوجد قالب. */
    @Synchronized
    fun applyTemplate(messages: List<Pair<String, String>>): String? {
        if (handle == 0L) return null
        val roles = Array(messages.size) { messages[it].first }
        val contents = Array(messages.size) { messages[it].second }
        return nativeTemplate(handle, roles, contents, true)
    }

    @Synchronized
    fun info(): String = nativeInfo(handle)

    fun isLoaded(): Boolean = handle != 0L

    /** يقطع أي معالجة/توليد جارٍ فورًا (حتى أثناء قراءة الموجّه الطويل). */
    fun abort() { try { nativeAbort() } catch (_: Throwable) {} }

    fun generate(prompt: String, maxTokens: Int, temp: Float, onToken: (String) -> Boolean): Int {
        check(handle != 0L) { "لا يوجد نموذج محمّل" }
        val t0 = System.nanoTime()
        return nativeGenerate(handle, prompt, maxTokens, temp, TokenCallback { s ->
            if (s.startsWith("\u0001")) {                       // تقدّم المعالجة الأولية
                val el = (System.nanoTime() - t0) / 1e9
                val p = s.substring(1).split('/')
                val done = p.getOrNull(0)?.toIntOrNull() ?: 0
                Bus.emit("progress", "يقرأ الموجّه… ${s.substring(1)} رمز" + (if (el > 1) " (${"%.0f".format(done / el)} رمز/ث)" else ""))
                true
            } else onToken(s)
        })
    }

    @Synchronized
    fun unload() {
        if (handle != 0L) nativeFree(handle)
        handle = 0L
        loadedPath = null
    }
}
