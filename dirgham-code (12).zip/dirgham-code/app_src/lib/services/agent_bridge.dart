import 'dart:convert';
import 'dart:async';
import 'package:flutter/services.dart';

/// جسر Flutter ⇄ Kotlin. كل العمل الثقيل يجري في خدمة أندرويد الأمامية.
class AgentBridge {
  static const _cmd = MethodChannel('dirgham/agent');
  static const _events = EventChannel('dirgham/agent_events');

  static final Stream<Map<dynamic, dynamic>> _shared =
      _events.receiveBroadcastStream().cast<Map<dynamic, dynamic>>().asBroadcastStream();

  /// token | think | tool | status | confirm | transcript | final | voice_end |
  /// dl | preview | openapp | done | error
  Stream<Map<dynamic, dynamic>> get events => _shared;

  Future<void> startService() => _cmd.invokeMethod('startService');
  Future<void> submitTask(String prompt) => _cmd.invokeMethod('submitTask', {'prompt': prompt});
  Future<void> cancel() => _cmd.invokeMethod('cancel');
  Future<void> newChat() => _cmd.invokeMethod('newChat');
  Future<void> restoreChat(String json) => _cmd.invokeMethod('restoreChat', {'json': json});

  Future<void> startListening() => _cmd.invokeMethod('startListening');
  Future<void> stopListening() => _cmd.invokeMethod('stopListening');
  Future<void> speak(String text) => _cmd.invokeMethod('speak', {'text': text});
  Future<void> stopSpeak() => _cmd.invokeMethod('stopSpeak');

  Future<void> confirmResult(String id, bool ok) =>
      _cmd.invokeMethod('confirmResult', {'id': id, 'ok': ok});

  Future<void> download(String url, String name) =>
      _cmd.invokeMethod('download', {'url': url, 'name': name});
  Future<void> cancelDownload(String name) => _cmd.invokeMethod('cancelDownload', {'name': name});
  Future<String> downloadStates() async => (await _cmd.invokeMethod('downloadStates')) as String;

  Future<List<Map<String, dynamic>>> listModels() async {
    final r = await _cmd.invokeMethod('listModels') as List<dynamic>;
    return r.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<void> setActiveModel(String name) => _cmd.invokeMethod('setActiveModel', {'name': name});
  Future<void> deleteModel(String name) => _cmd.invokeMethod('deleteModel', {'name': name});
  Future<String> modelsDir() async => (await _cmd.invokeMethod('modelsDir')) as String;
  Future<bool> nativeOk() async => (await _cmd.invokeMethod('nativeOk')) == true;

  Future<bool> getThinking() async => (await _cmd.invokeMethod('getThinking')) == true;
  Future<void> setThinking(bool on) => _cmd.invokeMethod('setThinking', {'on': on});

  Future<String> bridgeCommand() async => ((await _cmd.invokeMethod('bridgeCommand')) as String?) ?? '';
  Future<bool> bridgeConnected() async => (await _cmd.invokeMethod('bridgeConnected')) == true;
  Future<void> setGithubToken(String t) => _cmd.invokeMethod('setGithubToken', {'token': t});
  Future<bool> hasGithubToken() async => (await _cmd.invokeMethod('hasGithubToken')) == true;
  Future<void> setMediaSettings({required String elevenKey, required String elevenVoice, required int idleMin, required String fastModel}) =>
      _cmd.invokeMethod('setMediaSettings', {'elevenKey': elevenKey, 'elevenVoice': elevenVoice, 'idleMin': idleMin, 'fastModel': fastModel});
  Future<String> lastCrash() async => ((await _cmd.invokeMethod('lastCrash')) ?? '') as String;
  Future<void> setLocalCmds(String tts, String img) => _cmd.invokeMethod('setLocalCmds', {'tts': tts, 'img': img});
  Future<Map<String, dynamic>> getLocalCmds() async => Map<String, dynamic>.from(await _cmd.invokeMethod('getLocalCmds') as Map);
  Future<Map<String, dynamic>> getMediaSettings() async =>
      Map<String, dynamic>.from(await _cmd.invokeMethod('getMediaSettings') as Map);
  Future<bool> termuxInstalled() async => (await _cmd.invokeMethod('termuxInstalled')) == true;
  Future<bool> termuxPermissionGranted() async =>
      (await _cmd.invokeMethod('termuxPermissionGranted')) == true;
  Future<void> requestTermuxPermission() => _cmd.invokeMethod('requestTermuxPermission');
  Future<void> openAppSettings() => _cmd.invokeMethod('openAppSettings');
  Future<void> termuxTest() => _cmd.invokeMethod('termuxTest');
  Future<bool> openApp(String pkg) async => (await _cmd.invokeMethod('openApp', {'pkg': pkg})) == true;
  Future<List<Map<String, dynamic>>> listSkills() async {
    final s = (await _cmd.invokeMethod('listSkills')) as String? ?? '[]';
    return (jsonDecode(s) as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<String> readSkill(String n) async => ((await _cmd.invokeMethod('readSkill', {'name': n})) as String?) ?? '';
  Future<bool> deleteSkill(String n) async => (await _cmd.invokeMethod('deleteSkill', {'name': n})) == true;
  Future<String> saveFile(String path, String name, String mime) async =>
      ((await _cmd.invokeMethod('saveFile', {'path': path, 'name': name, 'mime': mime})) as String?) ?? '';
  Future<String> importFile(String path, String name) async =>
      ((await _cmd.invokeMethod('importFile', {'path': path, 'name': name})) as String?) ?? '';
  Future<bool> openUri(String uri, String mime, bool share) async =>
      (await _cmd.invokeMethod('openUri', {'uri': uri, 'mime': mime, 'share': share})) == true;
  Future<void> openPreview(String path) => _cmd.invokeMethod('openPreview', {'path': path});
}
