#!/usr/bin/env python3
# Dirgham Code - أدوات وسائط: فيديو بطبقات متحركة + صور + تحليل. تعتمد Pillow فقط (و ffmpeg للفيديو).
# الاستعمال:
#   dg_media.py video spec.json out.mp4
#   dg_media.py image spec.json out.png      (يرسم المشهد الأول في نهايته)
#   dg_media.py edit  spec.json              ({"src","out","ops":[...]})
#   dg_media.py info  path                   (وصف نصي للصورة + OCR إن وُجد tesseract)
import glob, json, math, os, shutil, subprocess, sys
from PIL import Image, ImageChops, ImageDraw, ImageEnhance, ImageFilter, ImageFont, ImageOps

import unicodedata

def _build_forms():
    F = {}
    for cp in range(0xFB50, 0xFEFD):
        d = unicodedata.decomposition(chr(cp))
        if not d.startswith("<") or " " not in d: continue
        tag, rest = d.split(" ", 1)
        parts = rest.split()
        if len(parts) != 1: continue
        F.setdefault(chr(int(parts[0], 16)), {})[tag.strip("<>")] = chr(cp)
    return F
_FORMS = _build_forms()
_NOJOIN_NEXT = set("اأإآدذرزوؤءةى")   # لا تتصل بما بعدها
_LAM_ALEF = {"ا": "isolated", "أ": "isolated", "إ": "isolated", "آ": "isolated"}

def _joins_prev(c):   # يتصل بما قبله؟
    return c in _FORMS and ("final" in _FORMS[c] or "medial" in _FORMS[c])
def _is_ar(c):
    return "\u0600" <= c <= "\u06FF"

def _reshape(t):
    out = []; n = len(t); i = 0
    marks = set("\u064B\u064C\u064D\u064E\u064F\u0650\u0651\u0652\u0670")
    base = [c for c in t]
    while i < n:
        c = t[i]
        if c in marks or not _is_ar(c) or c not in _FORMS:
            out.append(c); i += 1; continue
        # سابق متصل؟
        j = len(out) - 1
        while j >= 0 and out[j] in marks: j -= 1
        prev = out[j] if j >= 0 else ""
        prev_orig = None
        # نبحث عن الحرف الأصلي السابق
        k = i - 1
        while k >= 0 and t[k] in marks: k -= 1
        prev_orig = t[k] if k >= 0 else ""
        pj = bool(prev_orig) and _is_ar(prev_orig) and prev_orig in _FORMS and prev_orig not in _NOJOIN_NEXT and ("initial" in _FORMS[prev_orig] or "medial" in _FORMS[prev_orig])
        # لام + ألف
        if c == "ل" and i + 1 < n and t[i + 1] in _LAM_ALEF:
            lig = {"ا": "\uFEFB", "أ": "\uFEF7", "إ": "\uFEF9", "آ": "\uFEF5"}[t[i + 1]]
            if pj:
                lig = chr(ord(lig) + 1)
            out.append(lig); i += 2; continue
        nj = i + 1 < n and _is_ar(t[i + 1]) and t[i + 1] in _FORMS and c not in _NOJOIN_NEXT and ("final" in _FORMS[t[i + 1]] or "medial" in _FORMS[t[i + 1]])
        f = _FORMS[c]
        form = ("medial" if pj and nj else "final" if pj else "initial" if nj else "isolated")
        out.append(f.get(form) or f.get("isolated") or c)
        i += 1
    return "".join(out)

def _bidi_visual(t):
    """ترتيب بصري مبسّط لسطر RTL: الكلمات تُعكس، وكتل اللاتيني/الأرقام تبقى بترتيبها."""
    import re
    runs = re.findall(r"[A-Za-z0-9][A-Za-z0-9.,:/%+_-]*|\s+|[^A-Za-z0-9\s]", t)
    res = []
    for r in runs:
        res.append(r if re.match(r"[A-Za-z0-9]", r) else r[::-1])
    return "".join(reversed(res))

try:
    import arabic_reshaper
    from bidi.algorithm import get_display
    def shape(s):
        return get_display(arabic_reshaper.reshape(s))
except Exception:
    def shape(s):
        if not any(_is_ar(c) for c in s):
            return s
        return _bidi_visual(_reshape(s))

HOME = os.path.expanduser("~/dirgham/")

def find_media(name):
    if not name:
        return None
    n = os.path.expanduser(str(name))
    for f in (n, os.path.join(HOME + "inputs/", n), os.path.join(HOME, n), os.path.join(HOME + "out/", n)):
        if os.path.exists(f):
            return f
    return None

def find_font():
    c = ["/system/fonts/NotoNaskhArabic-Regular.ttf", "/system/fonts/NotoSansArabic-Regular.ttf",
         "/system/fonts/NotoNaskhArabicUI-Regular.ttf", "/system/fonts/DroidNaskh-Regular.ttf"]
    c += sorted(glob.glob("/system/fonts/*Arab*.ttf")) + ["/system/fonts/Roboto-Regular.ttf",
         "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"]
    for f in c:
        if os.path.exists(f):
            return f
    return None
FP = find_font()
def set_font(name):
    global FP
    f = find_media(name)
    if f:
        FP = f; _fc.clear()
_fc = {}
def font(sz):
    sz = max(8, int(sz))
    if sz not in _fc:
        _fc[sz] = ImageFont.truetype(FP, sz) if FP else ImageFont.load_default()
    return _fc[sz]

def hexrgb(h, d=(24, 32, 56)):
    try:
        h = str(h).lstrip("#")
        if len(h) == 3: h = "".join(c * 2 for c in h)
        return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
    except Exception:
        return d

# ---------------- معالجة الصور ----------------
def cutout(im, thr=38):
    """إزالة الخلفية المتصلة بالحافة (للصور بلا شفافية). تحافظ على قناة ألفا إن وُجدت."""
    im = im.convert("RGBA")
    a = im.getchannel("A")
    if a.getextrema()[0] < 250:           # فيها شفافية أصلًا
        return im
    sm = im.copy(); sm.thumbnail((420, 420))
    w, h = sm.size
    px = sm.convert("RGB")
    corners = [px.getpixel(p) for p in ((0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1))]
    bg = tuple(sorted(c[i] for c in corners)[len(corners) // 2] for i in range(3))
    diff = ImageChops.difference(px, Image.new("RGB", (w, h), bg)).convert("L")
    fg = diff.point(lambda v: 255 if v > thr else 0)
    mask = fg.copy()
    for x in range(w):
        for y in (0, h - 1):
            if mask.getpixel((x, y)) == 0: ImageDraw.floodfill(mask, (x, y), 128)
    for y in range(h):
        for x in (0, w - 1):
            if mask.getpixel((x, y)) == 0: ImageDraw.floodfill(mask, (x, y), 128)
    alpha = mask.point(lambda v: 0 if v == 128 else 255)
    alpha = alpha.filter(ImageFilter.MinFilter(3)).filter(ImageFilter.GaussianBlur(1.2))
    alpha = alpha.resize(im.size, Image.BILINEAR)
    out = im.copy(); out.putalpha(alpha)
    return out

def autocrop(im, pad=4):
    im = im.convert("RGBA")
    bb = im.getchannel("A").point(lambda v: 255 if v > 12 else 0).getbbox()
    if not bb:
        return im
    x0, y0, x1, y1 = bb
    return im.crop((max(0, x0 - pad), max(0, y0 - pad), min(im.width, x1 + pad), min(im.height, y1 + pad)))

def crop_box(im, box):
    x, y, w, h = [float(v) for v in box]
    if max(x, y, w, h) <= 1.0:
        x, y, w, h = x * im.width, y * im.height, w * im.width, h * im.height
    return im.crop((int(x), int(y), int(x + w), int(y + h)))

def rounded(im, r):
    im = im.convert("RGBA")
    m = Image.new("L", im.size, 0)
    ImageDraw.Draw(m).rounded_rectangle([0, 0, im.width - 1, im.height - 1], radius=int(r), fill=255)
    im.putalpha(ImageChops.multiply(im.getchannel("A"), m))
    return im

def apply_ops(im, ops):
    for o in ops or []:
        k = o.get("op")
        if k == "crop": im = crop_box(im, o["box"])
        elif k == "autocrop": im = autocrop(im)
        elif k == "cutout": im = cutout(im, float(o.get("thr", 38)))
        elif k == "resize":
            w, h = o.get("w"), o.get("h")
            if w and not h: h = int(im.height * float(w) / im.width)
            if h and not w: w = int(im.width * float(h) / im.height)
            im = im.resize((int(w), int(h)), Image.LANCZOS)
        elif k == "fit":
            im = ImageOps.contain(im, (int(o["w"]), int(o["h"])))
        elif k == "rotate": im = im.convert("RGBA").rotate(float(o.get("deg", 0)), expand=True, resample=Image.BICUBIC)
        elif k == "flip": im = ImageOps.mirror(im)
        elif k == "brightness": im = ImageEnhance.Brightness(im.convert("RGB")).enhance(float(o.get("v", 1)))
        elif k == "contrast": im = ImageEnhance.Contrast(im.convert("RGB")).enhance(float(o.get("v", 1)))
        elif k == "blur": im = im.filter(ImageFilter.GaussianBlur(float(o.get("r", 2))))
        elif k == "rounded": im = rounded(im, float(o.get("r", 24)))
        elif k == "gray": im = ImageOps.grayscale(im).convert("RGBA")
    return im

_img_cache = {}
def load_img(src, ops=None, key=None):
    k = key or (src, json.dumps(ops, sort_keys=True))
    if k in _img_cache:
        return _img_cache[k]
    f = find_media(src)
    if not f:
        _img_cache[k] = None
        return None
    im = Image.open(f)
    if max(im.size) > 1800:
        im.thumbnail((1800, 1800))
    im = apply_ops(im.convert("RGBA"), ops)
    _img_cache[k] = im
    return im

# ---------------- الرسم ----------------
def ease(name, p):
    p = max(0.0, min(1.0, p))
    if name == "in": return p * p
    if name == "out": return 1 - (1 - p) * (1 - p)
    if name == "inout": return 3 * p * p - 2 * p * p * p
    if name == "back": c = 1.70158; return 1 + (c + 1) * (p - 1) ** 3 + c * (p - 1) ** 2
    return p

def prop(L, name, default, t):
    v = L.get(name, default)
    for a in L.get("anim", []) or []:
        if a.get("p") != name: continue
        t0, t1 = float(a.get("t0", 0)), float(a.get("t1", 1))
        if t < t0: v = a.get("from", v) if v == L.get(name, default) else v; continue
        p = 1.0 if t1 <= t0 else (t - t0) / (t1 - t0)
        e = ease(a.get("ease", "inout"), p)
        f, to = float(a.get("from", default)), float(a.get("to", default))
        v = f + (to - f) * e
    if name == "loop":
        pass
    return v

def paste_center(base, tile, cx, cy, alpha=1.0, rot=0.0):
    if rot:
        tile = tile.rotate(rot, expand=True, resample=Image.BICUBIC)
    if alpha < 0.999:
        tile = tile.copy(); tile.putalpha(tile.getchannel("A").point(lambda v: int(v * alpha)))
    base.paste(tile, (int(cx - tile.width / 2), int(cy - tile.height / 2)), tile)

def wrap(text, f, maxw, dr):
    words, lines, cur = str(text).split(), [], []
    for w in words:
        t = " ".join(cur + [w])
        if cur and dr.textlength(shape(t), font=f) > maxw:
            lines.append(" ".join(cur)); cur = [w]
        else:
            cur.append(w)
    if cur: lines.append(" ".join(cur))
    return lines

def text_tile(text, size, color, maxw):
    f = font(size)
    tmp = ImageDraw.Draw(Image.new("RGBA", (4, 4)))
    lines = wrap(text, f, maxw, tmp)
    lh = int(size * 1.4)
    wd = int(max([tmp.textlength(shape(l), font=f) for l in lines] + [10])) + 8
    tile = Image.new("RGBA", (wd, lh * len(lines) + 8), (0, 0, 0, 0))
    d = ImageDraw.Draw(tile)
    for k, l in enumerate(lines):
        s = shape(l); w = d.textlength(s, font=f)
        d.text(((wd - w) / 2, 4 + k * lh), s, font=f, fill=color + (255,))
    return tile

def draw_layer(im, L, t, W, H):
    typ = L.get("type", "rect")
    x = float(prop(L, "x", 0.5, t)) * W; y = float(prop(L, "y", 0.5, t)) * H
    sc = float(prop(L, "scale", 1.0, t)); al = float(prop(L, "alpha", 1.0, t)); rot = float(prop(L, "rot", 0.0, t))
    w = float(L.get("w", 0.2)) * W * sc; h = float(L.get("h", 0.2)) * H * sc
    col = hexrgb(L.get("color", "#ffffff"))
    if typ in ("rect", "ellipse"):
        iw, ih = max(2, int(w)), max(2, int(h))
        tile = Image.new("RGBA", (iw, ih), (0, 0, 0, 0)); d = ImageDraw.Draw(tile)
        if typ == "rect":
            d.rounded_rectangle([0, 0, iw - 1, ih - 1], radius=int(float(L.get("radius", 0)) * min(iw, ih)), fill=col + (255,))
        else:
            d.ellipse([0, 0, iw - 1, ih - 1], fill=col + (255,))
        paste_center(im, tile, x, y, al, rot)
    elif typ == "text":
        size = float(L.get("size", 0.06)) * H * sc
        tile = text_tile(L.get("text", ""), size, col, float(L.get("w", 0.8)) * W)
        paste_center(im, tile, x, y, al, rot)
    elif typ == "image":
        src = load_img(L.get("src"), L.get("ops"))
        if src is None: return
        tile = src
        if L.get("crop"): tile = crop_box(tile, L["crop"])
        if L.get("cutout"): tile = autocrop(cutout(tile))
        tw, th = tile.size
        if L.get("fit", "contain") == "cover":
            s = max(w / tw, h / th)
        else:
            s = min(w / tw, h / th) if (L.get("w") and L.get("h")) else (w / tw if L.get("w") else h / th)
        tile = tile.resize((max(2, int(tw * s)), max(2, int(th * s))), Image.BILINEAR)
        if L.get("flip"): tile = ImageOps.mirror(tile)
        paste_center(im, tile, x, y, al, rot)

def gradient(c1, c2, W, H):
    im = Image.new("RGB", (W, H), c1); px = ImageDraw.Draw(im)
    for y in range(H):
        t = y / H
        px.line([(0, y), (W, y)], fill=tuple(int(c1[i] * (1 - t) + c2[i] * t) for i in range(3)))
    return im

def cover(im, w, h, z=1.0, px=0.0):
    """تغطية الإطار بالصورة؛ px من -1 إلى 1 يزيح القصّ أفقيًا (حركة تنقّل)."""
    sw, sh = im.size
    s = max(w / sw, h / sh) * z
    nw, nh = int(sw * s) + 1, int(sh * s) + 1
    r = im.resize((nw, nh), Image.BILINEAR)
    x, y = (nw - w) // 2 + int(px * max(0, (nw - w) // 2)), (nh - h) // 2
    x = max(0, min(nw - w, x))
    return r.crop((x, y, x + w, y + h))

_pieces_cache = {}
def load_pieces(spec):
    k = json.dumps(spec.get("pieces") or [])
    if k in _pieces_cache: return _pieces_cache[k]
    bg, props = None, []
    for p in spec.get("pieces") or []:
        im = load_img(p, None, key=("piece", p))
        if im is None: continue
        if im.width / max(1, im.height) > 1.4 and im.width * im.height > 0.04 * 1e6 and bg is None and im.width > 300:
            bg = (im if bg is None else bg)
        props.append(im)
    if bg is None and props: bg = max(props, key=lambda i: i.width * i.height)
    props = [p for p in props if p is not bg]
    _pieces_cache[k] = (bg, props)
    return bg, props

def draw_compose(im, spec, idx, t, W, H):
    """يركّب مشهدًا من القطع المفصولة: خلفية + عناصر تظهر بالتتابع بحركة ارتداد وطفو. حتمي حسب رقم المشهد."""
    import random
    bg, props = load_pieces(spec)
    if not props and bg is None: return
    rnd = random.Random(idx * 104729 + 7)
    if bg is not None and idx % 3 == 0:
        im.paste(cover(bg.convert("RGB"), W, H, 1.0 + 0.04 * t / 4, math.sin(idx) * 0.3), (0, 0))
    if not props: return
    n = min(len(props), rnd.randint(3, 5))
    chosen = [props[(idx * 3 + k * 5 + rnd.randint(0, 2)) % len(props)] for k in range(n)]
    xs = sorted(rnd.uniform(0.1, 0.9) for _ in range(n))
    for k, p in enumerate(chosen):
        t0 = 0.25 + k * 0.35
        a = min(1.0, max(0.0, (t - t0) / 0.45))
        if a <= 0: continue
        e = ease("back", a)
        hh = rnd.uniform(0.2, 0.36) * H
        sc = hh / max(1, p.height)
        if p.width * sc > W * 0.4: sc = W * 0.4 / p.width
        tile = p.resize((max(2, int(p.width * sc * e)), max(2, int(p.height * sc * e))), Image.BILINEAR)
        cx = xs[k] * W; base = rnd.uniform(0.62, 0.88) * H
        bob = math.sin(t * 2.2 + k) * H * 0.008
        tile.putalpha(tile.getchannel("A").point(lambda v, a=a: int(v * a)))
        im.paste(tile, (int(cx - tile.width / 2), int(base - tile.height + bob)), tile)

PALS = [((22, 32, 64), (70, 30, 40)), ((18, 48, 58), (20, 20, 50)), ((50, 28, 60), (20, 30, 60)),
        ((60, 36, 20), (24, 24, 48)), ((20, 54, 44), (16, 28, 50)), ((40, 40, 70), (60, 24, 30))]
ACC = [(255, 140, 60), (255, 200, 90), (80, 210, 170), (120, 160, 255), (240, 90, 120)]

def grid_frame(im, W, H, accent=(255, 140, 60)):
    d = ImageDraw.Draw(im, "RGBA")
    step = max(24, W // 24)
    for x in range(0, W, step): d.line([(x, 0), (x, H)], fill=(255, 255, 255, 22))
    for y in range(0, H, step): d.line([(0, y), (W, y)], fill=(255, 255, 255, 22))
    m = int(W * 0.02)
    d.rectangle([m, m, W - m, H - m], outline=(255, 200, 90, 110), width=2)

def decor(im, idx, t, W, H):
    """زخارف متحركة تلقائية تنوّع المشاهد: دوائر عائمة + شريط لوني (لا تحتاج مواصفات من النموذج)."""
    import random
    rnd = random.Random(idx * 7919 + 13)
    lay = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    for k in range(5):
        r = rnd.uniform(0.04, 0.12) * H
        bx, by = rnd.uniform(0.05, 0.95) * W, rnd.uniform(0.1, 0.9) * H
        ph = rnd.uniform(0, 6.28); sp = rnd.uniform(0.6, 1.4)
        x = bx + math.sin(t * sp + ph) * W * 0.03; y = by + math.cos(t * sp * 0.8 + ph) * H * 0.04
        c = ACC[(idx + k) % len(ACC)]
        d.ellipse([x - r, y - r, x + r, y + r], fill=c + (46,))
    c = ACC[idx % len(ACC)]
    w = min(1.0, t / 0.6) * W * 0.28
    d.rounded_rectangle([W * 0.06, H * 0.075, W * 0.06 + w, H * 0.075 + 8], radius=4, fill=c + (255,))
    im.paste(lay, (0, 0), lay)

COL = {"A": (255, 140, 60), "B": (60, 200, 170)}
def drawn_character(im, cx, base, col, t, talking, W, H):
    d = ImageDraw.Draw(im)
    bob = math.sin(t * 6) * (H * 0.008)
    hr = H * 0.085; by = base + bob
    d.rounded_rectangle([cx - hr * 1.1, by - hr * 0.2, cx + hr * 1.1, by + hr * 2.0], radius=int(hr * 0.5), fill=col)
    d.ellipse([cx - hr, by - hr * 2.2, cx + hr, by - hr * 0.2], fill=(250, 220, 190))
    for ex in (-0.38, 0.38):
        d.ellipse([cx + ex * hr - 6, by - hr * 1.4 - 6, cx + ex * hr + 6, by - hr * 1.4 + 6], fill=(30, 30, 40))
    m = (abs(math.sin(t * 14)) * hr * 0.25 + 3) if talking else 3
    d.ellipse([cx - hr * 0.3, by - hr * 0.8, cx + hr * 0.3, by - hr * 0.8 + m * 2], fill=(120, 40, 40))

def char_image(spec, sp):
    c = (spec.get("characters") or {}).get(sp) or {}
    if not c.get("image"):
        return None
    k = ("char", c["image"], json.dumps(c.get("crop")))
    if k in _img_cache:
        return _img_cache[k]
    im = load_img(c["image"], None, key=("raw", c["image"]))
    if im is None:
        return None
    if c.get("crop"): im = crop_box(im, c["crop"])
    if not c.get("keep_bg"): im = cutout(im)
    im = autocrop(im)
    _img_cache[k] = im
    return im

def render_frame(spec, sc, t, n_total, W, H, photo=None, black=None, idx=0):
    pal = PALS[idx % len(PALS)]
    bgc = hexrgb(sc.get("bg"), pal[0]) if sc.get("bg") else pal[0]
    if photo is not None:
        z0, z1 = (sc.get("zoom") or [1.0, 1.08])
        pan = float(sc.get("pan", 0)) * (-1 + 2 * (t / max(0.01, n_total)))
        im = Image.blend(cover(photo, W, H, z0 + (z1 - z0) * (t / max(0.01, n_total)), pan), black, 0.38)
    else:
        im = gradient(bgc, pal[1] if not sc.get("bg") else tuple(max(0, c - 30) for c in bgc), W, H)
        if spec.get("grid"): grid_frame(im, W, H)
        if not sc.get("plain"): decor(im, idx, t, W, H)
        if spec.get("compose"): draw_compose(im, spec, idx, t, W, H)
    sp = str(sc.get("speaker", "narrator")); text = str(sc.get("text", ""))
    names = spec.get("names") or {}
    if sp in ("A", "B") and not sc.get("no_characters"):
        for who, cx in (("A", W * 0.2), ("B", W * 0.8)):
            ci = char_image(spec, who)
            talking = (sp == who)
            if ci is not None:
                ch = H * 0.62
                s = ch / ci.height
                s *= 1.0 + (0.025 * math.sin(t * 14) if talking else 0.0)
                tile = ci.resize((max(2, int(ci.width * s)), max(2, int(ci.height * s))), Image.BILINEAR)
                if who == "B": tile = ImageOps.mirror(tile)
                bob = math.sin(t * 6) * H * 0.008
                im.paste(tile, (int(cx - tile.width / 2), int(H * 0.93 - tile.height + bob)), tile)
            else:
                drawn_character(im, cx, H * 0.62, COL[who], t, talking, W, H)
        nm = names.get(sp, sp)
        d = ImageDraw.Draw(im); s = shape(str(nm)); f = font(H * 0.04)
        d.text((W * (0.2 if sp == "A" else 0.8) - d.textlength(s, font=f) / 2, H * 0.94), s, font=f, fill=(240, 240, 240))
    for L in sc.get("layers", []) or []:
        draw_layer(im, L, t, W, H)
    if text.strip():
        d = ImageDraw.Draw(im)
        F = font(H * 0.058)
        maxw = W * (0.5 if sp in ("A", "B") else 0.86)
        lines = wrap(text, F, maxw, d)
        lh = int(H * 0.058 * 1.5)
        bh = lh * len(lines) + 30; bw = max([d.textlength(shape(l), font=F) for l in lines] + [40]) + 50
        a = min(1.0, t / 0.5)
        bx = (W - bw) / 2
        by = (H * 0.95 - bh) if (photo is not None or spec.get("compose") or spec.get("subs")) else (H * 0.14 + (1 - a) * 25)
        d.rounded_rectangle([bx, by, bx + bw, by + bh], radius=26, fill=(255, 255, 255))
        for k, l in enumerate(lines):
            s = shape(l); w = d.textlength(s, font=F)
            d.text(((W - w) / 2, by + 15 + k * lh), s, font=F, fill=(25, 25, 35))
    return im

# ---------------- الأوامر ----------------
def cmd_video(spec, out):
    if spec.get("font"): set_font(spec["font"])
    if spec.get("format") == "vertical": spec.setdefault("w", 720); spec.setdefault("h", 1280)
    W = int(spec.get("w", 960)); H = int(spec.get("h", 540)); FPS = int(spec.get("fps", 24))
    scenes = spec.get("scenes") or []
    if not scenes: sys.exit("no scenes")
    dur = [max(1.5, float(s.get("sec", 4))) for s in scenes]
    audio = find_media(spec.get("audio")) if spec.get("audio") else None
    if audio:
        try:
            d = float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                                               "-of", "csv=p=0", audio]).decode().strip())
            tot = sum(dur)
            if d > tot: dur = [x * d / tot for x in dur]
        except Exception:
            audio = None
    cmd = ["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-"]
    if audio: cmd += ["-i", audio]
    cmd += ["-c:v", "libx264", "-preset", "veryfast", "-pix_fmt", "yuv420p", "-movflags", "+faststart"]
    if audio: cmd += ["-c:a", "aac", "-shortest"]
    cmd += [out]
    pipe = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    prev = [None]
    def emit(img):
        prev[0] = img; pipe.stdin.write(img.tobytes())
    title = spec.get("title", "")
    if title:
        bg = gradient((20, 24, 44), (60, 30, 20), W, H)
        for i in range(int(FPS * 2)):
            a = min(1.0, i / (FPS * 0.8)); im = bg.copy(); d = ImageDraw.Draw(im)
            s = shape(title); f = font(H * 0.09); w = d.textlength(s, font=f)
            d.text(((W - w) / 2, H * 0.4 + (1 - a) * 30), s, font=f, fill=tuple(int(255 * a) for _ in range(3)))
            emit(im)
    black = Image.new("RGB", (W, H), (0, 0, 0))
    for si, (sc, secs) in enumerate(zip(scenes, dur)):
        photo = None
        if sc.get("image"):
            p = load_img(sc["image"], None, key=("raw", sc["image"]))
            if p is not None: photo = p.convert("RGB")
        n = int(secs * FPS)
        for i in range(n):
            t = i / FPS
            im = render_frame(spec, sc, t, secs, W, H, photo, black, si)
            if prev[0] is not None and i < FPS * 0.4:
                im = Image.blend(prev[0], im, (i + 1) / (FPS * 0.4))
            emit(im)
    pipe.stdin.close(); pipe.wait()
    if pipe.returncode != 0 or not os.path.exists(out):
        sys.exit("ffmpeg failed")
    print("OK", out, os.path.getsize(out))

def cmd_image(spec, out):
    if spec.get("font"): set_font(spec["font"])
    W = int(spec.get("w", 1024)); H = int(spec.get("h", 576))
    sc = (spec.get("scenes") or [spec])[0]
    photo = None
    if sc.get("image"):
        p = load_img(sc["image"], None, key=("raw", sc["image"]))
        if p is not None: photo = p.convert("RGB")
    secs = float(sc.get("sec", 3))
    im = render_frame(spec, sc, secs, secs, W, H, photo, Image.new("RGB", (W, H), (0, 0, 0)))
    im.save(out)
    print("OK", out, os.path.getsize(out))

def cmd_edit(spec):
    f = find_media(spec.get("src"))
    if not f: sys.exit("source not found: %s" % spec.get("src"))
    im = Image.open(f).convert("RGBA")
    im = apply_ops(im, spec.get("ops"))
    out = os.path.expanduser(spec.get("out") or "edited.png")
    if not os.path.isabs(out) and not out.startswith("~"): out = os.path.join(HOME, out)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    if out.lower().endswith((".jpg", ".jpeg")): im = im.convert("RGB")
    im.save(out)
    print("OK", out, "%dx%d" % im.size)

def cmd_pieces(spec):
    """يفصل شيت شخصية/عناصر إلى قطع مستقلة (مكوّنات متصلة) ويحفظ كل قطعة PNG شفاف."""
    f = find_media(spec.get("src"))
    if not f: sys.exit("source not found: %s" % spec.get("src"))
    im = cutout(Image.open(f).convert("RGBA"))
    W, H = im.size
    sc = min(1.0, 500.0 / max(W, H))
    m = im.getchannel("A").resize((max(1, int(W * sc)), max(1, int(H * sc)))).point(lambda v: 255 if v > 40 else 0)
    gap = int(spec.get("gap", 3))
    md = m.filter(ImageFilter.MaxFilter(2 * gap + 1)) if gap > 0 else m
    w, h = md.size; px = md.load(); seen = bytearray(w * h); boxes = []
    for y0 in range(h):
        for x0 in range(w):
            if px[x0, y0] and not seen[y0 * w + x0]:
                st = [(x0, y0)]; seen[y0 * w + x0] = 1; x1 = x2 = x0; y1 = y2 = y0; n = 0
                while st:
                    x, y = st.pop(); n += 1
                    x1 = min(x1, x); x2 = max(x2, x); y1 = min(y1, y); y2 = max(y2, y)
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        a, b = x + dx, y + dy
                        if 0 <= a < w and 0 <= b < h and px[a, b] and not seen[b * w + a]:
                            seen[b * w + a] = 1; st.append((a, b))
                boxes.append((n, x1, y1, x2, y2))
    minA = float(spec.get("min_area", 0.002)) * w * h
    boxes = sorted([b for b in boxes if b[0] >= minA], key=lambda b: (b[2] // max(1, h // 6), b[1]))[:int(spec.get("max", 24))]
    pre = spec.get("out") or "out/piece"
    if not os.path.isabs(pre) and not pre.startswith("~"): pre = os.path.join(HOME, pre)
    os.makedirs(os.path.dirname(pre), exist_ok=True)
    rows = []
    for k, (n, x1, y1, x2, y2) in enumerate(boxes, 1):
        box = (int(x1 / sc), int(y1 / sc), int((x2 + 1) / sc), int((y2 + 1) / sc))
        p = "%s_%d.png" % (pre, k); autocrop(im.crop(box)).save(p)
        rows.append("%s  %dx%d  at(x,y,w,h fractions)=%.2f,%.2f,%.2f,%.2f" % (os.path.relpath(p, HOME), box[2] - box[0], box[3] - box[1], box[0] / W, box[1] / H, (box[2] - box[0]) / W, (box[3] - box[1]) / H))
    print("OK %d pieces" % len(rows)); print("\n".join(rows))

def cmd_info(path):
    f = find_media(path)
    if not f: sys.exit("not found: %s" % path)
    im = Image.open(f)
    w, h = im.size
    rgba = im.convert("RGBA")
    has_alpha = rgba.getchannel("A").getextrema()[0] < 250
    small = rgba.convert("RGB"); small.thumbnail((160, 160))
    q = small.quantize(5).convert("RGB")
    cols = sorted(q.getcolors(), reverse=True)
    dom = ", ".join("#%02x%02x%02x(%d%%)" % (c[0], c[1][0], c[1][1], c[1][2]) if False else "#%02x%02x%02x(%d%%)" % (c[1][0], c[1][1], c[1][2], 100 * c[0] // (q.width * q.height)) for c in cols)
    lum = sum(ImageOps.grayscale(small).getdata()) / (small.width * small.height)
    sub = autocrop(cutout(rgba))
    bb = rgba.getchannel("A").point(lambda v: 255 if v > 12 else 0).getbbox()
    cut = cutout(rgba); cb = cut.getchannel("A").point(lambda v: 255 if v > 12 else 0).getbbox()
    lines = ["size %dx%d, mode %s, transparent background: %s" % (w, h, im.mode, "yes" if has_alpha else "no"),
             "dominant colors: " + dom, "brightness: %.0f/255" % lum]
    if cb:
        lines.append("subject box (fractions x,y,w,h): %.2f,%.2f,%.2f,%.2f" % (cb[0] / w, cb[1] / h, (cb[2] - cb[0]) / w, (cb[3] - cb[1]) / h))
    if shutil.which("tesseract"):
        try:
            t = subprocess.check_output(["tesseract", f, "stdout", "-l", "ara+eng"], stderr=subprocess.DEVNULL, timeout=60).decode().strip()
            lines.append("text found (OCR): " + (t[:600] if t else "none"))
        except Exception:
            lines.append("OCR failed")
    else:
        lines.append("OCR unavailable (install: pkg install tesseract)")
    print("\n".join(lines))

if __name__ == "__main__":
    a = sys.argv
    if len(a) < 3: sys.exit("usage: dg_media.py video|image|edit|info ...")
    if a[1] == "info":
        cmd_info(a[2])
    else:
        spec = json.load(open(a[2], encoding="utf-8"))
        if a[1] == "video": cmd_video(spec, a[3])
        elif a[1] == "image": cmd_image(spec, a[3])
        elif a[1] == "edit": cmd_edit(spec)
        elif a[1] == "pieces": cmd_pieces(spec)
        else: sys.exit("unknown command")
