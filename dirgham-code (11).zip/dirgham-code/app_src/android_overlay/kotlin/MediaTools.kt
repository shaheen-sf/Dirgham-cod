package com.dirgham.code

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.coroutines.resume

/**
 * أدوات الوسائط: تحليل/تعديل الصور، رسم أشكال، توليد صور (إنترنت)، تحويل نص لصوت، جرد Termux وطلب الحزم.
 * المعالجة الثقيلة تجري في Termux عبر dg_media.py (Pillow/ffmpeg)؛ لا شيء هنا يدّعي ما لم يحدث.
 */
object MediaTools {
    private val PKG = Regex("^[a-z0-9][a-z0-9+._-]{0,40}$")

    private suspend fun tx(ctx: Context, cmd: String, ms: Long = 60_000L) = TermuxBridge.runCapture(ctx, cmd, ms)

    fun rel(p: String): String? {
        val c = p.trim().trimStart('/')
        if (c.isEmpty() || c.contains("..") || c.contains("'") || c.contains("\n")) return null
        if (!Regex("^[A-Za-z0-9._/ \\-\\u0600-\\u06FF]{1,160}$").matches(c)) return null
        return c
    }

    /** يجهّز بايثون/Pillow(/ffmpeg) وينسخ dg_media.py إلى Termux. يعيد null عند النجاح أو رسالة ERROR. */
    suspend fun prepare(ctx: Context, ffmpeg: Boolean): String? {
        if (!LocalBridge.connected()) return "ERROR: media tools need the Termux bridge connected (Settings -> Termux)."
        val need = "python3 -c 'import PIL' 2>&1 && " + (if (ffmpeg) "command -v ffmpeg >/dev/null && " else "") + "echo deps-ok"
        if (!tx(ctx, need).contains("deps-ok")) {
            if (!Confirm.ask("تثبيت أدوات الوسائط في Termux", "python + python-pillow" + (if (ffmpeg) " + ffmpeg" else "") + " + arabic-reshaper")) return "ERROR: the user declined installing the packages."
            Bus.emit("progress", "تثبيت أدوات الوسائط في Termux…")
            val r = tx(ctx, "pkg install -y python python-pillow " + (if (ffmpeg) "ffmpeg" else "") + " 2>&1 | tail -3; pip install arabic-reshaper python-bidi 2>&1 | tail -2; $need", 900_000L)
            if (!r.contains("deps-ok")) return "ERROR: package install failed: " + Tools.clip(r, 400)
        }
        val dir = LocalBridge.inDir ?: return "ERROR: inputs dir not ready"
        File(dir, "dg_media.py").writeBytes(Base64.decode(VideoScript.B64, Base64.DEFAULT))
        val r = tx(ctx, "mkdir -p ~/dirgham/tools ~/dirgham/out ~/dirgham/video && curl -fsS -o ~/dirgham/tools/dg_media.py '${LocalBridge.url("file/dg_media.py")}' && echo ready")
        return if (r.contains("ready")) null else "ERROR: could not deploy the media script: " + Tools.clip(r, 200)
    }

    private suspend fun pushSpec(ctx: Context, spec: JSONObject): String? {
        val dir = LocalBridge.inDir ?: return "ERROR: inputs dir not ready"
        File(dir, "dg_spec.json").writeText(spec.toString(), Charsets.UTF_8)
        val r = tx(ctx, "curl -fsS -o ~/dirgham/video/spec.json '${LocalBridge.url("file/dg_spec.json")}' && echo ok")
        return if (r.contains("ok")) null else "ERROR: could not send the spec: " + Tools.clip(r, 200)
    }

    suspend fun run(ctx: Context, cmd: String, spec: JSONObject?, ffmpeg: Boolean, ms: Long): String {
        prepare(ctx, ffmpeg)?.let { return it }
        if (spec != null) pushSpec(ctx, spec)?.let { return it }
        return tx(ctx, "cd ~/dirgham && python3 -W ignore tools/dg_media.py $cmd 2>&1 | tail -12", ms)
    }

    suspend fun imageInfo(ctx: Context, path: String): String {
        val p = rel(path) ?: return "ERROR: bad path"
        val full = if (p.contains('/')) p else "inputs/$p"
        return Tools.clip(run(ctx, "info '$full'", null, false, 120_000L))
    }

    suspend fun imageEdit(ctx: Context, a: JSONObject): String {
        val src = rel(a.optString("src")) ?: return "ERROR: give src (file name)"
        val out = rel(a.optString("out").ifBlank { "out/edited.png" }) ?: return "ERROR: bad out"
        val ops = a.optJSONArray("ops") ?: return "ERROR: give ops, e.g. [{\"op\":\"cutout\"},{\"op\":\"autocrop\"},{\"op\":\"resize\",\"h\":600}] (ops: crop[box x,y,w,h fractions], autocrop, cutout, resize, fit, rotate, flip, brightness, contrast, blur, rounded, gray)"
        val spec = JSONObject().put("src", src).put("out", out).put("ops", ops)
        val r = run(ctx, "edit ~/dirgham/video/spec.json", spec, false, 180_000L)
        return if (r.contains("OK")) "Edited image saved as $out. $r" else "ERROR: " + Tools.clip(r, 300)
    }

    suspend fun makeImage(ctx: Context, a: JSONObject): String {
        val out = rel(a.optString("out").ifBlank { "out/image.png" }) ?: return "ERROR: bad out"
        val spec = JSONObject().put("w", a.optInt("w", 1024)).put("h", a.optInt("h", 576))
        a.optJSONObject("characters")?.let { spec.put("characters", it) }
        spec.put("names", a.optJSONObject("names") ?: JSONObject())
        val sc = JSONObject().put("sec", 3).put("speaker", a.optString("speaker", "narrator"))
            .put("text", a.optString("text")).put("plain", a.optBoolean("plain", false))
        if (a.has("bg")) sc.put("bg", a.optString("bg"))
        if (a.has("image")) sc.put("image", a.optString("image"))
        sc.put("layers", a.optJSONArray("layers") ?: JSONArray())
        spec.put("scenes", JSONArray().put(sc))
        val r = run(ctx, "image ~/dirgham/video/spec.json '$out'", spec, false, 180_000L)
        return if (r.contains("OK")) "Image saved as $out. Deliver it with send_file. $r" else "ERROR: " + Tools.clip(r, 300)
    }


    suspend fun splitPieces(ctx: Context, a: JSONObject): String {
        val src = rel(a.optString("src")) ?: return "ERROR: give src (file name of the sheet image)"
        val out = rel(a.optString("out").ifBlank { "out/piece" }) ?: return "ERROR: bad out"
        val spec = JSONObject().put("src", src).put("out", out).put("min_area", a.optDouble("min_area", 0.002)).put("gap", a.optInt("gap", 3))
        val r = run(ctx, "pieces ~/dirgham/video/spec.json", spec, false, 240_000L)
        return if (r.contains("OK")) "Pieces saved (each is a transparent PNG; use them as image layers):\n$r" else "ERROR: " + Tools.clip(r, 300)
    }

    /** تحويل نص لصوت بأمر محلي في Termux يضبطه المستخدم (Piper/sherpa-onnx وغيرها). يعيد مسار الناتج أو null. */
    private suspend fun localTts(ctx: Context, text: String, nameBase: String): String? {
        val cmd = Settings.ttsCmd(ctx)
        if (cmd.isBlank() || !LocalBridge.connected()) return null
        val dir = LocalBridge.inDir ?: return null
        File(dir, "dg_text.txt").writeText(text, Charsets.UTF_8)
        val out = "out/$nameBase.wav"
        val full = cmd.replace("{text}", "video/text.txt").replace("{out}", out)
        Bus.emit("progress", "توليد الصوت بالأمر المحلي…")
        val r = tx(ctx, "mkdir -p ~/dirgham/out ~/dirgham/video && curl -fsS -o ~/dirgham/video/text.txt '${LocalBridge.url("file/dg_text.txt")}' && cd ~/dirgham && rm -f '$out' && ($full) 2>&1 | tail -3; [ -s '$out' ] && echo MADE", 600_000L)
        if (r.contains("MADE")) return out
        Bus.emit("status", "الأمر المحلي للصوت فشل: " + clip2(r))
        return null
    }
    private fun clip2(s: String) = Tools.clip(s.trim(), 200)

    private suspend fun localImage(ctx: Context, prompt: String, outName: String, w: Int, h: Int): String? {
        val cmd = Settings.imgCmd(ctx)
        if (cmd.isBlank() || !LocalBridge.connected()) return null
        val dir = LocalBridge.inDir ?: return null
        File(dir, "dg_prompt.txt").writeText(prompt, Charsets.UTF_8)
        val out = "out/$outName"
        val full = cmd.replace("{prompt}", "video/prompt.txt").replace("{out}", out).replace("{w}", "$w").replace("{h}", "$h")
        Bus.emit("progress", "توليد الصورة بالأمر المحلي (قد يطول)…")
        val r = tx(ctx, "mkdir -p ~/dirgham/out ~/dirgham/video && curl -fsS -o ~/dirgham/video/prompt.txt '${LocalBridge.url("file/dg_prompt.txt")}' && cd ~/dirgham && rm -f '$out' && ($full) 2>&1 | tail -3; [ -s '$out' ] && echo MADE", 1_800_000L)
        if (r.contains("MADE")) return out
        Bus.emit("status", "الأمر المحلي للصور فشل: " + clip2(r))
        return null
    }

    /** يرسم HTML (مع CSS/خطوط/عربي سليم من المتصفح) إلى صورة PNG عبر WebView داخل التطبيق. تجريبي. */
    suspend fun htmlToImage(ctx: Context, a: JSONObject): String {
        var html = a.optString("html")
        if (html.isBlank()) {
            val p = rel(a.optString("path")) ?: return "ERROR: give html (full page text) or path"
            html = if (LocalBridge.connected()) tx(ctx, "cat ~/dirgham/'$p'", 30_000L) else File(File(ctx.filesDir, "workspace"), p).takeIf { it.isFile }?.readText().orEmpty()
        }
        if (html.isBlank()) return "ERROR: empty html"
        val w = a.optInt("w", 1080).coerceIn(200, 2400); val h = a.optInt("h", 1080).coerceIn(200, 3000)
        val out = rel(a.optString("out").ifBlank { "out/design.png" }) ?: return "ERROR: bad out"
        val bytes = withContext(Dispatchers.Main) {
            suspendCancellableCoroutine<ByteArray?> { cont ->
                var done = false
                fun fin(b: ByteArray?) { if (!done) { done = true; cont.resume(b) } }
                try {
                    val wv = WebView(ctx.applicationContext)
                    wv.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
                    wv.settings.javaScriptEnabled = true
                    wv.setBackgroundColor(0)
                    wv.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(h, View.MeasureSpec.EXACTLY))
                    wv.layout(0, 0, w, h)
                    wv.webViewClient = object : WebViewClient() {
                        override fun onPageFinished(v: WebView, url: String?) {
                            Handler(Looper.getMainLooper()).postDelayed({
                                try {
                                    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                                    v.draw(Canvas(bmp))
                                    val bo = java.io.ByteArrayOutputStream()
                                    bmp.compress(Bitmap.CompressFormat.PNG, 100, bo)
                                    v.destroy(); fin(bo.toByteArray())
                                } catch (_: Exception) { fin(null) }
                            }, 900)
                        }
                    }
                    wv.loadDataWithBaseURL("https://dirgham.local/", html, "text/html", "utf-8", null)
                } catch (_: Exception) { fin(null) }
            }
        } ?: return "ERROR: the WebView could not render the page"
        if (bytes.size < 3000) return "ERROR: the rendered image is empty (the page may be blank)"
        return "Rendered HTML to ${stage(ctx, bytes, out.substringAfterLast('/'))} (${bytes.size / 1024} KB). Check it by image_info, then use it or deliver with send_file."
    }

    suspend fun inventory(ctx: Context): String {
        if (!LocalBridge.connected()) return "Termux bridge not connected."
        val r = tx(ctx, "for c in python3 pip ffmpeg ffprobe node git curl tesseract whisper-cli sox magick convert espeak-ng piper yt-dlp unzip zip 7z rsync jq; do command -v \$c >/dev/null && echo -n \"\$c \"; done; echo; echo PKGS:; pkg list-installed 2>/dev/null | cut -d/ -f1 | grep -v '^Listing' | tr '\\n' ' ' | head -c 1800; echo; echo PIP:; pip list 2>/dev/null | tail -n +3 | cut -d' ' -f1 | tr '\\n' ' ' | head -c 600; echo; echo DISK:; df -h ~ 2>/dev/null | tail -1", 90_000L)
        return Tools.clip("Installed commands (first line), then packages:\n$r", 3200)
    }

    suspend fun requestPackage(ctx: Context, pkgs: String, reason: String): String {
        if (!LocalBridge.connected()) return "ERROR: Termux bridge not connected."
        val list = pkgs.split(Regex("[,\\s]+")).filter { it.isNotBlank() }
        if (list.isEmpty() || list.size > 8 || list.any { !PKG.matches(it) }) return "ERROR: give 1-8 valid Termux package names"
        if (!Confirm.ask("طلب تثبيت حزم في Termux", list.joinToString(" ") + "\nالسبب: " + reason.take(200))) return "ERROR: the user declined installing " + list.joinToString(" ")
        Bus.emit("progress", "تثبيت ${list.joinToString(" ")}…")
        val r = tx(ctx, "pkg install -y ${list.joinToString(" ")} 2>&1 | tail -4; for p in ${list.joinToString(" ")}; do pkg list-installed 2>/dev/null | grep -q \"^\$p/\" && echo \"INSTALLED \$p\" || echo \"MISSING \$p\"; done", 900_000L)
        return Tools.clip(r, 600)
    }

    /** ينقل ملفًا مولَّدًا داخل التطبيق إلى ~/dirgham/out (إن كان Termux متصلًا) أو يتركه في مساحة العمل. */
    private suspend fun stage(ctx: Context, bytes: ByteArray, name: String): String {
        val n = LocalBridge.cleanName(name)
        if (LocalBridge.connected()) {
            val dir = LocalBridge.inDir
            if (dir != null) {
                File(dir, n).writeBytes(bytes)
                val enc = java.net.URLEncoder.encode(n, "UTF-8")
                val r = tx(ctx, "mkdir -p ~/dirgham/out && curl -fsS -o ~/dirgham/out/'$n' '${LocalBridge.url("file/$enc")}' && echo staged", 120_000L)
                if (r.contains("staged")) return "out/$n"
            }
        }
        val ws = File(ctx.filesDir, "workspace/out").also { it.mkdirs() }
        File(ws, n).writeBytes(bytes)
        return "out/$n"
    }

    private fun http(url: String, method: String, headers: Map<String, String>, body: ByteArray?, ms: Int): ByteArray {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 20_000; c.readTimeout = ms
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        if (body != null) { c.doOutput = true; c.outputStream.use { it.write(body) } }
        val code = c.responseCode
        val st = if (code in 200..299) c.inputStream else c.errorStream
        val data = st?.use { it.readBytes() } ?: ByteArray(0)
        if (code !in 200..299) throw RuntimeException("HTTP $code " + String(data.take(200).toByteArray()))
        return data
    }

    suspend fun generateImage(ctx: Context, a: JSONObject): String = withContext(Dispatchers.IO) {
        val prompt = a.optString("prompt").trim()
        if (prompt.isEmpty()) return@withContext "ERROR: give prompt (English works best)"
        val w0 = a.optInt("w", 1024).coerceIn(256, 1536); val h0 = a.optInt("h", 576).coerceIn(256, 1536)
        localImage(ctx, prompt, (a.optString("out").ifBlank { "out/generated.png" }).substringAfterLast('/'), w0, h0)?.let { return@withContext "Image generated by the local command: $it. Use it by file name or deliver with send_file." }
        if (!Confirm.ask("توليد صورة عبر الإنترنت", "سيُرسل الوصف إلى خدمة Pollinations:\n" + prompt.take(200))) return@withContext "ERROR: the user declined."
        val w = a.optInt("w", 1024).coerceIn(256, 1536); val h = a.optInt("h", 576).coerceIn(256, 1536)
        val out = rel(a.optString("out").ifBlank { "out/generated.jpg" }) ?: return@withContext "ERROR: bad out"
        Bus.emit("progress", "توليد الصورة (قد يستغرق دقيقة)…")
        try {
            val enc = java.net.URLEncoder.encode(prompt, "UTF-8").replace("+", "%20")
            val bytes = http("https://image.pollinations.ai/prompt/$enc?width=$w&height=$h&nologo=true&seed=${(System.nanoTime() % 100000)}", "GET", emptyMap(), null, 120_000)
            val ok = bytes.size > 2000 && ((bytes[0].toInt() == 0xFF && bytes[1].toInt() == 0xD8) || (bytes[0].toInt() == 0x89 && bytes[1].toInt() == 0x50))
            if (!ok) return@withContext "ERROR: the service did not return an image."
            val where = stage(ctx, bytes, out.substringAfterLast('/'))
            "Image generated and saved as $where (${bytes.size / 1024} KB). Use it in make_video/make_image via its file name, or deliver with send_file."
        } catch (e: Exception) { "ERROR: image generation failed (needs internet): ${e.message}" }
    }

    private suspend fun systemTts(ctx: Context, text: String, file: File): String? = suspendCancellableCoroutine { cont ->
        var done = false
        fun fin(v: String?) { if (!done) { done = true; cont.resume(v) } }
        var tts: TextToSpeech? = null
        tts = TextToSpeech(ctx.applicationContext) { st ->
            val t = tts
            if (st != TextToSpeech.SUCCESS || t == null) { fin("no engine"); return@TextToSpeech }
            val av = t.isLanguageAvailable(Locale("ar"))
            if (av < TextToSpeech.LANG_AVAILABLE) { t.shutdown(); fin("no Arabic voice installed in Android (Settings > Text-to-speech)"); return@TextToSpeech }
            t.language = Locale("ar")
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) { t.shutdown(); fin(null) }
                @Deprecated("x") override fun onError(id: String?) { t.shutdown(); fin("synthesis error") }
            })
            val r = t.synthesizeToFile(text, Bundle(), file, "dg1")
            if (r != TextToSpeech.SUCCESS) { t.shutdown(); fin("synthesis refused") }
        }
        cont.invokeOnCancellation { try { tts?.shutdown() } catch (_: Exception) {} }
    }

    suspend fun tts(ctx: Context, a: JSONObject): String = withContext(Dispatchers.IO) {
        val text = a.optString("text").trim().take(4000)
        if (text.isEmpty()) return@withContext "ERROR: give text"
        val key = Settings.elevenKey(ctx)
        run {
            val nb = (a.optString("out").ifBlank { "out/voice" }).substringAfterLast('/').substringBeforeLast('.')
            localTts(ctx, text, nb)?.let { return@withContext "Voice created by the local TTS command: $it. Use it as \"audio\" in make_video or deliver with send_file." }
        }
        val nameBase = (a.optString("out").ifBlank { "out/voice" }).substringAfterLast('/').substringBeforeLast('.')
        if (key.isNotBlank()) {
            try {
                val want = (a.optString("voice").ifBlank { Settings.elevenVoice(ctx) }).trim()
                var id = want
                if (want.isEmpty() || want.contains(' ') || want.length != 20) {
                    val vs = JSONObject(String(http("https://api.elevenlabs.io/v1/voices", "GET", mapOf("xi-api-key" to key), null, 30_000))).optJSONArray("voices") ?: JSONArray()
                    var pick: JSONObject? = null
                    for (i in 0 until vs.length()) { val v = vs.getJSONObject(i); if (want.isNotEmpty() && v.optString("name").contains(want, true)) { pick = v; break } }
                    if (pick == null && vs.length() > 0) pick = vs.getJSONObject(0)
                    id = pick?.optString("voice_id") ?: return@withContext "ERROR: no ElevenLabs voices on this account"
                }
                Bus.emit("progress", "توليد الصوت عبر ElevenLabs…")
                val body = JSONObject().put("text", text).put("model_id", "eleven_multilingual_v2").toString().toByteArray(Charsets.UTF_8)
                val mp3 = http("https://api.elevenlabs.io/v1/text-to-speech/$id?output_format=mp3_44100_128", "POST",
                    mapOf("xi-api-key" to key, "Content-Type" to "application/json", "Accept" to "audio/mpeg"), body, 180_000)
                val where = stage(ctx, mp3, "$nameBase.mp3")
                return@withContext "Voice created with ElevenLabs: $where (${mp3.size / 1024} KB). Use it as \"audio\" in make_video or deliver with send_file."
            } catch (e: Exception) { Bus.emit("status", "ElevenLabs فشل (${e.message?.take(80)}) — أجرّب صوت الأندرويد") }
        }
        Bus.emit("progress", "توليد الصوت بمحرك الأندرويد…")
        val tmp = File(ctx.cacheDir, "tts_$nameBase.wav")
        val err = systemTts(ctx, text, tmp)
        if (err != null || !tmp.exists() || tmp.length() < 1000) return@withContext "ERROR: Android TTS failed: ${err ?: "empty file"}. Set an ElevenLabs key in Settings for a professional Arabic voice."
        val where = stage(ctx, tmp.readBytes(), "$nameBase.wav"); tmp.delete()
        "Voice created with the Android system voice: $where. (For a more natural Arabic voice add an ElevenLabs key in Settings.)"
    }


    /** تفريغ صوتي بالتوقيت عبر ElevenLabs Scribe (عربي وغيره). يعيد (مقاطع [بداية، نهاية، نص]، رسالة خطأ). */
    suspend fun transcribeTimed(ctx: Context, name: String): Pair<List<Triple<Double, Double, String>>, String?> = withContext(Dispatchers.IO) {
        val key = Settings.elevenKey(ctx)
        if (key.isBlank()) return@withContext Pair(emptyList(), "لا يوجد مفتاح ElevenLabs (الإعدادات ← الوسائط) لتفريغ الصوت بالتوقيت")
        val f = File(File(ctx.filesDir, "workspace/inputs"), LocalBridge.cleanName(name))
        if (!f.isFile) return@withContext Pair(emptyList(), "ملف الصوت غير موجود في مساحة التطبيق: $name")
        try {
            Bus.emit("progress", "تفريغ الصوت إلى نص بالتوقيت (ElevenLabs Scribe)…")
            val b = "----dg" + System.nanoTime()
            fun part(k: String, v: String) = "--$b\r\nContent-Disposition: form-data; name=\"$k\"\r\n\r\n$v\r\n"
            val head = (part("model_id", "scribe_v1") + part("timestamps_granularity", "word") + part("tag_audio_events", "false") +
                "--$b\r\nContent-Disposition: form-data; name=\"file\"; filename=\"audio\"\r\nContent-Type: application/octet-stream\r\n\r\n").toByteArray()
            val tail = "\r\n--$b--\r\n".toByteArray()
            val c = URL("https://api.elevenlabs.io/v1/speech-to-text").openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.connectTimeout = 20_000; c.readTimeout = 600_000; c.doOutput = true
            c.setRequestProperty("xi-api-key", key)
            c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$b")
            c.setFixedLengthStreamingMode(head.size + f.length() + tail.size)
            c.outputStream.use { o -> o.write(head); f.inputStream().use { it.copyTo(o) }; o.write(tail) }
            val code = c.responseCode
            val body = (if (code in 200..299) c.inputStream else c.errorStream)?.use { String(it.readBytes()) } ?: ""
            if (code !in 200..299) return@withContext Pair(emptyList(), "ElevenLabs رفض الطلب (HTTP $code): " + body.take(160))
            val words = JSONObject(body).optJSONArray("words") ?: return@withContext Pair(emptyList(), "لم يرجع نص من الخدمة")
            val chunks = ArrayList<Triple<Double, Double, String>>()
            var cur = ArrayList<String>(); var cs = -1.0; var ce = 0.0
            fun flush() { if (cur.isNotEmpty()) chunks.add(Triple(cs, ce, cur.joinToString(" "))); cur = ArrayList(); cs = -1.0 }
            for (i in 0 until words.length()) {
                val w = words.getJSONObject(i)
                if (w.optString("type") != "word") continue
                val txt = w.optString("text").trim(); if (txt.isEmpty()) continue
                val s = w.optDouble("start", 0.0); val e = w.optDouble("end", s)
                if (cur.isNotEmpty() && (s - ce > 0.8 || e - cs > 4.2 || cur.size >= 7)) flush()
                if (cs < 0) cs = s
                cur.add(txt); ce = e
                if (Regex("[.!?؟۔،,]$").containsMatchIn(txt) && e - cs > 1.2) flush()
            }
            flush()
            // دمج المقاطع القصيرة جدًا (< 1.5 ث) مع التي تليها
            val merged = ArrayList<Triple<Double, Double, String>>()
            for (ch in chunks) {
                val last = merged.lastOrNull()
                if (last != null && (last.second - last.first) < 1.5) merged[merged.size - 1] = Triple(last.first, ch.second, last.third + " " + ch.third)
                else merged.add(ch)
            }
            if (merged.isEmpty()) Pair(emptyList(), "لم أتعرّف على كلام في الصوت") else Pair(merged, null)
        } catch (e: Exception) { Pair(emptyList(), "تعذّر تفريغ الصوت: ${e.message}") }
    }

    suspend fun transcribe(ctx: Context, path: String): String {
        run {
            val nm = path.substringAfterLast('/')
            if (Settings.elevenKey(ctx).isNotBlank() && File(File(ctx.filesDir, "workspace/inputs"), LocalBridge.cleanName(nm)).isFile) {
                val (ch, err) = transcribeTimed(ctx, nm)
                return if (err != null) "ERROR: $err" else ch.joinToString("\n") { "[%.1f-%.1f] %s".format(it.first, it.second, it.third) }
            }
        }
        val p = rel(path) ?: return "ERROR: bad path"
        if (!LocalBridge.connected()) return "ERROR: Termux bridge not connected."
        val full = if (p.contains('/')) p else "inputs/$p"
        val r = tx(ctx, "cd ~/dirgham; B=\$(command -v whisper-cli || command -v whisper-cpp); M=\$(ls ~/dirgham/models/ggml-*.bin ~/.whisper/ggml-*.bin 2>/dev/null | head -1); " +
            "if [ -z \"\$B\" ] || [ -z \"\$M\" ]; then echo NOENGINE; else ffmpeg -y -loglevel error -i '$full' -ar 16000 -ac 1 /data/data/com.termux/files/usr/tmp/dg.wav && \$B -m \"\$M\" -f /data/data/com.termux/files/usr/tmp/dg.wav -nt 2>/dev/null | head -c 3000; fi", 900_000L)
        if (r.contains("NOENGINE")) return "ERROR: no speech-to-text engine in Termux (needs whisper.cpp binary 'whisper-cli' plus a ggml-*.bin model in ~/dirgham/models). Tell the user, do not guess the content of the audio."
        return Tools.clip(r.ifBlank { "ERROR: transcription produced no text" }, 3000)
    }
}
